package nbcu.framework.utils.others;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class DateFunctions {

	public enum TIMEZONES {
		EST, IST
	};

	public enum TIMETYPE {
		HOURS, MINUTES
	};

	public enum DATECOMPARECONDITIONS {
		LESSTHAN, GREATERTHAN, EQUALTO, LESSTHANOREQUALTO, GREATERTHANOREQUALTO
	};

	/**
	 * To get current date with given date format
	 * 
	 * @param dateFormat - date format
	 * @return - current date
	 * @throws Exception
	 */
	public static String getCurrentDate(String dateFormat) throws Exception {
		String currentDate = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);
			Date date = new Date();
			currentDate = fsimpleDateFormat.format(date);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return currentDate;
	}

	/**
	 * To get current date and time of given time zone
	 * 
	 * @param dateFormat - date format
	 * @param timeZone   - time zone
	 * @return
	 * @throws Exception
	 */
	public static String getCurrentDateAndTimeByTimeZone(String dateFormat, TIMEZONES timeZone) throws Exception {
		String currentDate = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);
			switch (timeZone) {
			case EST:
				fsimpleDateFormat.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
				// fsimpleDateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
				break;
			case IST:
				break;
			}
			Date date = new Date();
			currentDate = fsimpleDateFormat.format(date);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return currentDate;
	}

	/**
	 * To convert date string to date
	 * 
	 * @param dateString            - date string
	 * @param inputDateStringFormat - date format of date string
	 * @return - date
	 * @throws Exception
	 */
	public static Date convertDateStringToDate(String dateString, String inputDateStringFormat) throws Exception {
		Date convertedDate = null;
		try {
			convertedDate = new SimpleDateFormat(inputDateStringFormat).parse(dateString);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return convertedDate;
	}

	/**
	 * Convert date string from one format to another format
	 * 
	 * @param dateString - Date string
	 * @param fromFormat - current format
	 * @param toFormat   - expected format
	 * @return - converted date string
	 * @throws Exception
	 */
	public static String convertDateStringToAnotherFormat(String dateString, String fromFormat, String toFormat)
			throws Exception {
		String convertedDate = "";
		try {
			Date currentDate = new SimpleDateFormat(fromFormat).parse(dateString);
			SimpleDateFormat toSimpledateFormat = new SimpleDateFormat(toFormat);
			convertedDate = toSimpledateFormat.format(currentDate);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return convertedDate;
	}

	/**
	 * To generate add/subtract no of days from current date
	 * 
	 * @param dateFormat - date format
	 * @param days       - no of days to add or subtract
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusDateFromCurrentDate(String dateFormat, String days, TIMEZONES timeZone)
			throws Exception {
		String updatedDate = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);

			// Generate current date
			switch (timeZone) {
			case EST:
				fsimpleDateFormat.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
				// fsimpleDateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
				break;
			case IST:
				break;
			}
			Date currentDate = new Date();

			// Add or minus date
			Calendar calender = Calendar.getInstance();
			calender.setTime(currentDate);
			calender.add(Calendar.DATE, Integer.parseInt(days));
			updatedDate = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedDate;

	}

	/**
	 * To generate add/subtract no of hours from current time
	 * 
	 * @param timeFormat
	 * @param timeType
	 * @param hoursOrMinutesCount
	 * @param timeZone
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusTimeFromCurrentTime(String timeFormat, TIMETYPE timeType, String hoursOrMinutesCount,
			TIMEZONES timeZone) throws Exception {
		String updatedTime = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(timeFormat);

			// Generate current date
			switch (timeZone) {
			case EST:
				fsimpleDateFormat.setTimeZone(TimeZone.getTimeZone("America/Chicago"));
				// fsimpleDateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York"));
				break;
			case IST:
				break;
			}
			Date currentDate = new Date();

			// Add or minus date
			Calendar calender = Calendar.getInstance();
			calender.setTime(currentDate);
			switch (timeType) {
			case HOURS:
				calender.add(Calendar.HOUR, Integer.parseInt(hoursOrMinutesCount));
				break;
			case MINUTES:
				calender.add(Calendar.MINUTE, Integer.parseInt(hoursOrMinutesCount));
				break;

			}
			updatedTime = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedTime;

	}

	/**
	 * To generate add/subtract no of hours from given time
	 * 
	 * @param time                - time
	 * @param timeFormat          - format
	 * @param timeType
	 * @param hoursOrMinutesCount
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusTimeFromGivenTime(String time, String timeFormat, TIMETYPE timeType,
			String hoursOrMinutesCount) throws Exception {
		String updatedTime = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(timeFormat);
			Date currentDate = convertDateStringToDate(time, timeFormat);

			// Add or minus date
			Calendar calender = Calendar.getInstance();
			calender.setTime(currentDate);
			switch (timeType) {
			case HOURS:
				calender.add(Calendar.HOUR, Integer.parseInt(hoursOrMinutesCount));
				break;
			case MINUTES:
				calender.add(Calendar.MINUTE, Integer.parseInt(hoursOrMinutesCount));
				break;

			}
			updatedTime = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedTime;

	}

	/**
	 * To find day count between two dates
	 * 
	 * @param currentDate
	 * @param bookingDate
	 * @return
	 * @throws Exception
	 */
	public static long findNumberOfDaysBetweenTwoDates(String currentDate, String bookingDate) throws Exception {
		long diff = 0;
		try {
			Date date1 = convertDateStringToDate(currentDate, "MM/dd/yyyy");
			Date date2 = convertDateStringToDate(bookingDate, "MM/dd/yyyy");
			long diffInMillies = Math.abs(date2.getTime() - date1.getTime());
			diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
			if (date1.compareTo(date2) == 1)
				diff = diff * -1;

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return diff;

	}

	/**
	 * To get list of dates between two given dates
	 * 
	 * @param startDate
	 * @param endDate
	 * @param dateFormat
	 * @return
	 * @throws Exception
	 */
	public static List<String> getDateListBetweenDates(String startDate, String endDate, String dateFormat)
			throws Exception {
		List<String> dateList = new ArrayList<>();
		try {
			// Add from date to list
			dateList.add(startDate);

			// Add dates between from and to date
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);
			Date fromDate = convertDateStringToDate(startDate, dateFormat);
			Date toDate = convertDateStringToDate(endDate, dateFormat);
			Calendar cal = Calendar.getInstance();
			cal.setTime(fromDate);
			while (cal.getTime().before(toDate)) {
				cal.add(Calendar.DATE, 1);
				dateList.add(fsimpleDateFormat.format(cal.getTime()));
			}

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return dateList;

	}

	/**
	 * To compare two dates based on given condition
	 * 
	 * @param dateString1          - date string 1
	 * @param dateString2          - date string 2
	 * @param dateCompareCondition - condition
	 * @return
	 * @throws Exception
	 */
	public static boolean compareTwoDateWithCondition(String dateString1, String dateString2,
			DATECOMPARECONDITIONS dateCompareCondition) throws Exception {
		boolean compareStatus = false;
		Date date1 = convertDateStringToDate(dateString1, "MM/dd/yyyy");
		Date date2 = convertDateStringToDate(dateString2, "MM/dd/yyyy");
		try {
			switch (dateCompareCondition) {
			case GREATERTHAN:
				if (date1.compareTo(date2) > 1)
					compareStatus = true;
				break;
			case LESSTHAN:
				if (date1.compareTo(date2) < 1)
					compareStatus = true;
				break;
			case EQUALTO:
				if (date1.compareTo(date2) == 1)
					compareStatus = true;
				break;
			case LESSTHANOREQUALTO:
				if ((date1.compareTo(date2) < 1) || (date1.compareTo(date2) == 1))
					compareStatus = true;
				break;
			case GREATERTHANOREQUALTO:
				if ((date1.compareTo(date2) > 1) || (date1.compareTo(date2) == 1))
					compareStatus = true;
				break;
			default:
				break;
			}
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return compareStatus;
	}

	public static void main(String[] args) throws Exception {
		System.out.println(addOrMinusTimeFromGivenTime("7:59AM", "h:mma", TIMETYPE.MINUTES, "1"));
	}

}

package nbcu.framework.factory;

import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.testng.Assert;

import java.net.URL;
import java.time.Duration;

public class WebDrivers {

    /**
     * To get the current thread web driver
     *
     * @return - current thread web driver
     * @throws Exception
     */
    public static WebDriver getNewDriver(String browserName) throws Exception {
        WebDriver webDriver;
        if (ConfigFileReader.getProperty("IsRemote").equalsIgnoreCase("Yes"))
            webDriver = initializeRemoteWebDriver(browserName);
        else
            webDriver = initializeWebDriver(browserName);
        return webDriver;
    }

    /**
     * This method to initialize web browser driver in local machine
     *
     * @param browserName - Name of the browser
     * @return - WebDriver
     */
    public static WebDriver initializeWebDriver(String browserName) {
        WebDriver driver = null;
        try {
            switch (browserName.toUpperCase()) {
                case "CHROME":
                    ChromeOptions chromeOptions = new ChromeOptions();
                    driver = new ChromeDriver(chromeOptions);
                    break;
                case "FIREFOX":
                    FirefoxOptions firefoxOptions = new FirefoxOptions();
                    driver = new FirefoxDriver(firefoxOptions);
                    break;
                case "IE":
                    InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                    driver = new InternetExplorerDriver(ieOptions);
                    break;
                case "EDGE":
                    EdgeOptions edgeOptions = new EdgeOptions();
                    driver = new EdgeDriver(edgeOptions);
                    break;
                case "SAFARI":
                    SafariOptions safariOptions = new SafariOptions();
                    driver = new SafariDriver(safariOptions);
                    break;
                default:
                    Assert.assertTrue(false, "Given browser name is not valid-" + browserName);
                    break;
            }
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.manage().window().maximize();
        } catch (Exception e) {
            System.out.println("Local driver initialize issue");
            e.printStackTrace();
        }
        return driver;
    }

    /**
     * This method to initialize web browser driver in remote machine
     *
     * @param browserName - Name of the browser
     * @return - WebDriver
     */
    public static WebDriver initializeRemoteWebDriver(String browserName) {
        WebDriver driver = null;
        try {
            switch (browserName.toUpperCase()) {
                case "CHROME":
                    ChromeOptions chromeOptions = new ChromeOptions();
                    driver = new RemoteWebDriver(new URL(ConfigFileReader.getProperty("Selenium-Host")), chromeOptions);
                    break;
                case "FIREFOX":
                    FirefoxOptions firefoxOptions = new FirefoxOptions();
                    driver = new RemoteWebDriver(new URL(ConfigFileReader.getProperty("Selenium-Host")), firefoxOptions);
                    break;
                case "IE":
                    InternetExplorerOptions ieOptions = new InternetExplorerOptions();
                    driver = new RemoteWebDriver(new URL(ConfigFileReader.getProperty("Selenium-Host")), ieOptions);
                    break;
                case "EDGE":
                    EdgeOptions edgeOptions = new EdgeOptions();
                    driver = new RemoteWebDriver(new URL(ConfigFileReader.getProperty("Selenium-Host")), edgeOptions);
                    break;
                default:
                    Assert.assertTrue(false, "Given browser name is not valid-" + browserName);
                    break;
            }
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
            driver.manage().window().maximize();
        } catch (Exception e) {
            System.out.println("Remote driver initialize issue");
            e.printStackTrace();
        }

        return driver;
    }
}

package nbcu.automation.ui.pages.feed;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class CreateFeedOrderPage {

	@FindBy(xpath = "//input[contains(@name,'txtAir')]")
	WebElement hitDateTextBox;

	public CreateFeedOrderPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify feed order page is loaded
	 * @throws Exception
	 */
	public void verifyFeedOrderPageLoaded() throws Exception {
		try {
			String parentWindowId = WebAction.getCurrentWindowId();
			WebAction.switchToNewWindow(2, parentWindowId);
			Waits.waitForElement(hitDateTextBox, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}

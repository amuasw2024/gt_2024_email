package nbcu.automation.ui.constants.gtreplatform;

import java.util.HashMap;

public class BookerProfileConstants {

	private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	// Booker name
	public static void setBookerName(String bookerName) {
		constantMap.get().put("Booker Name", bookerName);
	}

	public static String getBookerName() {
		return (String) constantMap.get().get("Booker Name");
	}

	// Booker Division
	public static void setBookerDivision(String bookerDivision) {
		constantMap.get().put("Booker Division", bookerDivision);
	}

	public static String getBookerDivision() {
		return (String) constantMap.get().get("Booker Division");
	}

	// Default view
	public static void setDefaultViewName(String defaultView) {
		constantMap.get().put("Default View", defaultView);
	}

	public static String getDefaultViewName() {
		return (String) constantMap.get().get("Default View");
	}

	// Default division
	public static void setDefaultDivisionName(String defaultDivision) {
		constantMap.get().put("Default Division", defaultDivision);
	}

	public static String getDefaultDivisionName() {
		return (String) constantMap.get().get("Default Division");
	}

	// Email-1
	public static void setEmail1(String email1) {
		constantMap.get().put("Booker Email1", email1);
	}

	public static String getEmail1() {
		return (String) constantMap.get().get("Booker Email1");
	}

	// Email-2
	public static void setEmail2(String email2) {
		constantMap.get().put("Booker Email2", email2);
	}

	public static String getEmail2() {
		return (String) constantMap.get().get("Booker Email2");
	}

	// Email-3
	public static void setEmail3(String email3) {
		constantMap.get().put("Booker Email3", email3);
	}

	public static String getEmail3() {
		return (String) constantMap.get().get("Booker Email3");
	}

	// Email-4
	public static void setEmail4(String email4) {
		constantMap.get().put("Booker Email4", email4);
	}

	public static String getEmail4() {
		return (String) constantMap.get().get("Booker Email4");
	}
}

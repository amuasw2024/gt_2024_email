package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;
import nbcu.automation.ui.pages.gtreplatform.ContributorsPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class ContributorsPageSteps {

	ContributorsPage contributorPage = new ContributorsPage();

	@When("user clicks profile  displays the Division name")
	public void clickSettings() throws Exception {
		contributorPage.clickSettings();
	}

	@And("division name shown in page header with plus circle")
	public void verifyHeaderTextsandIcon() throws Exception {
		contributorPage.verifyContributorName();
	}

	@When("user clicks {string} loads create guest profile page")
	public void clickAddGuestIcon(String plusCircle) throws Exception {
		contributorPage.verifyPlusCircle();
	}

	@And("verify the contributor option is selected")
	public void verifyRadioButton() throws Exception {
		contributorPage.verifyContributorRadio();
	}

	@And("verify user division is checked by default")
	public void divisionIsChecked() throws Exception {
		contributorPage.verifyContributorDivision();
	}

	@When("user enters the Biography details in background section of guest profile")
	public void enterGuestBioGrpahy(DataTable params) throws Exception {
		contributorPage.fillBiogrpahyDetails(CucumberUtils.getValuesFromDataTable(params, "Bio-graphy"));
	}

	@When("user fills organization in Job History RH drawer")
	public void enterCompanyName(DataTable params) throws Exception {
		contributorPage.selectOraganization(CucumberUtils.getValuesFromDataTable(params, "Org/Comp"));
	}

	@And("user fill Expertise details in background section")
	public void fillExpertise(DataTable dataTable) throws Exception {
		contributorPage.selectExpertise(CucumberUtils.getValuesFromDataTable(dataTable, "Expertise"));
	}

	@And("user search for newly created guest contributor")
	public void searchGuestDetails() throws Exception {
		//contributorPage.verifyLastNameOfTheGuest();
		contributorPage.searchCreatedGuest();
	}

	@Then("created guest name are displayed in the card")
	public void verifyGuestNameInTheCard() throws Exception {
		contributorPage.verifyGuestName();
	}

	@And("user verify the guest details in the header")
	public void verifyGuestDetails() {
		contributorPage.verifyCreatedGuestHeader();
	}

	@And("user enables the letter selector filter in header")
	public void verifyEnOrDisAlphabets() throws Exception {
		contributorPage.clickEnabledAlphabets();
	}

	@And("user verifies the ascending and descending order of data letters")
	public void verifyAscendingAndDescendingAlpabets() throws Exception {
		contributorPage.cardsInAscendingOrder();
	}

	@And("user enable the Filter RH drawer using its icon")
	public void enableFilterRHDrawer() throws Exception {
		contributorPage.clickFilterIcon();
		contributorPage.verifyCardViewInRHDrawer();
		contributorPage.jobTitleEnable();
	}

	@And("user enables Expertise filter and expertise details shown in card view")
	public void enableExpertiseFilter() throws Exception {
		contributorPage.clickFilterIcon();
		contributorPage.setExpertiseFilter();
		contributorPage.verifyContactCardExpertiseTags();
	}

	@And("Job title is displayed in contact card")
	public void verifyGuestJobDetails() {
		contributorPage.verfiyContactCardJobTitle();
	}

	@And("user clicks the Filter icon")
	public void clickFilterIcon() throws Exception {
		contributorPage.clickFilterIcon();
	}

	@And("user select the expertises tags from the filter")
	public void selectExpertiseDropDown(DataTable dataTable) throws Exception {
		contributorPage.selectValues(CucumberUtils.getValuesFromDataTable(dataTable, "Expertise-tags"));
	}

	@And("user can verify list of contact cards after applying expertise filter")
	public void contactCardsIsDisplayed() throws Exception {
		contributorPage.clickButton();
	}

	@And("user can remove the applied filter from the expertise section")
	public void removeTheFilter() throws Exception {
		contributorPage.clearedTheApplyExpertiseFitler();
	}

	@And("user view the profile RHdrawer by clicking guest name in contact cards")
	public void verfiyProfileDrawer() throws Exception {
		contributorPage.verifyProfileRHDrawer();
		contributorPage.verfiyGuestBasicDetailsInRHDrawer();
	}

	@Then("user verfiy the {string} of guest details in profile RH drawer")
	public void verifyGuestDetailsInRhDrawer(String sectionWise) throws Exception {
		switch (sectionWise.toUpperCase()) {
		case "BASIC INFO":
			contributorPage.verifyProfileRHDrawer();
		//	contributorPage.verfiyGuestBasicDetailsInRHDrawer();
			break;

		case "CONTACT INFO":
			contributorPage.verifyGuestContactDetailsInRHDrawer();
			contributorPage.verifyGuestContactAddressDetailsInRHDrawer();
			contributorPage.verifyGuestBookersDetailsInRHDrawer();
			break;
		}
	}
	
	@And("user update the contributor type as No")
	public void deselectContributorRadio() throws Exception {
		contributorPage.clickProfileButton();
		//contributorPage.editNewlyCreatedProfile();
		contributorPage.deselectContributorRadio();
	}
	
	@And("updated user should not shown in contributors page")
    public void verfiyGuestDetails() throws Exception {
		contributorPage.guestDetailsNotToDisplay();
	}

    @And("user enters the Add Contact details in Guest profile of contact info section")
    public void selectAdditionalContact(DataTable dataTable) throws Exception {
    	contributorPage.additionalContacts(CucumberUtils.getValuesFromDataTable(dataTable, "Search value"));
    }

}

package nbcu.automation.ui.pages.gtreplatform;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.gtreplatform.CompanyProfileConstants;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class SubsidairyCompanyProfilePage {

	@FindBy(xpath = "//span[text()='Subsidiary']")
	WebElement profileType;

	@FindBy(xpath = "//span[text()='Subsidiary']/preceding::span[1]")
	WebElement selectChildCompany;

	@FindBy(xpath = "//span[contains(@class,'ant-select-selection-search')]/input")
	WebElement parentNameField;

	@FindBy(xpath = "//span[contains(@class,'ant-select-selection-search-input')]/input")
	WebElement subsidiaryNameField;

	String dropDownValues = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownValuesXpath;

	@FindBy(xpath = "//*[@id='rc_select_2']")
	WebElement expertiseInputBox;

	@FindBy(xpath = "//span[text()='Select Expertise(s)']")
	WebElement expertiseDropDownClick;

	String expertiseValues = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> expertiseValuesXpath;

	@FindBy(xpath = "//input[@id='CompanyInfo_ticker']")
	WebElement companyTickerTextBox;

	@FindBy(id = "CompanyInfo_biography")
	WebElement biographyTextArea;
	
	// Phone - Contact Info section
	@FindBy(xpath = "//label[text()='1 - Phone']")
	WebElement phoneLabelText;

	@FindBy(id = "Contact_Phone_0_phone")
	WebElement phoneNo0;

	@FindBy(id = "Contact_Phone_1_phone")
	WebElement phoneNo1;

	@FindBy(id = "Contact_Phone_2_phone")
	WebElement phoneNo2;

	@FindBy(id = "Contact_Phone_3_phone")
	WebElement phoneNo3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Phone_')]/following-sibling::span/button")
	List<WebElement> phoneFavoriteButtons;

	// Email - Contact Info section
	@FindBy(id = "Contact_Email_0_email")
	WebElement email0;

	@FindBy(id = "Contact_Email_1_email")
	WebElement email1;

	@FindBy(id = "Contact_Email_2_email")
	WebElement email2;

	@FindBy(id = "Contact_Email_3_email")
	WebElement email3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Email_')]/following-sibling::span/button")
	List<WebElement> emailFavoriteButtons;

	// Other - Contact Info section
	@FindBy(id = "Contact_Social_0_link")
	WebElement other0;

	@FindBy(id = "Contact_Social_1_link")
	WebElement otherfield1;

	@FindBy(id = "Contact_Misc_0_link")
	WebElement otherfield2;

	@FindBy(id = "Contact_Misc_1_link")
	WebElement otherfield3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Social_') or contains(@id,'Contact_Misc_')]/following-sibling::span/button")
	List<WebElement> othersFavoriteButtons;

	// Address - Contact Info section
	@FindBy(xpath = "//label[text()='Address - 1']")
	WebElement addressLabel;

	@FindBy(id = "Contact_Address_0_address1")
	WebElement addressLine1;

	@FindBy(id = "Contact_Address_0_address2")
	WebElement addressLine2;

	@FindBy(id = "Contact_Address_0_city")
	WebElement addressCity;

	@FindBy(id = "Contact_Address_0_state")
	WebElement addressState;

	@FindBy(id = "Contact_Address_0_zip")
	WebElement addressZip;

	@FindBy(id = "Contact_Address_0_country")
	WebElement addressCountry;

	// Alerts - Contact Info section
	@FindBy(id = "Alerts_notes")
	WebElement alertsDetails;

	// CreateButton -
	@FindBy(xpath = "//span[text()='Create']")
	WebElement createCompanyButton;



	public SubsidairyCompanyProfilePage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * Select the Profile Type as Subsidiary
	 * 
	 * @throws Exception
	 */
	public void selectProfileType(String type) throws Exception {
		String elemText = WebAction.getText(profileType);
		try {
			if (type.equalsIgnoreCase(elemText)) {
				WebAction.clickUsingJs(selectChildCompany);
			} else
				throw new Exception("Subsidiary text not present in profile type");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Enter Parent Company Name
	 * 
	 * @throws Exception
	 */
	public void enterAndSelectParentCompanyName(String name) throws Exception {
		try {
			if (name!=null) {
				WebAction.selectDropDown(parentNameField, name, dropDownValues, dropDownValuesXpath,
						"'" + name + "' no present in the search field");
			} else
				throw new Exception("Name not entered into the field");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Enter Subsidiary Company Name
	 * 
	 * @throws Exception
	 */
	public void enterSubsidiaryName(String subName) throws Exception {
		try {
			if (subName!=null) {
				WebAction.click(subsidiaryNameField);
				WebAction.sendKeys(subsidiaryNameField, subName);
			} else
				throw new Exception("Name not entered into the field");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter the Ticker details
	 * 
	 * @throws Exception
	 */
	public void fillTickerDetails(String ticker) throws Exception {
//		CompanyConstants.setCompanyTicker(ticker); // set Method
		try {
			if (ticker!=null) {
				WebAction.sendKeys(companyTickerTextBox, ticker);
				WebAction.keyPress(companyTickerTextBox, "ENTER");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select value from Expertise drop down
	 * 
	 * @throws Exception
	 */
	public void selectExpertise(String expertise) throws Exception {
		try {
			Thread.sleep(5000);
			WebAction.clickUsingJs(expertiseDropDownClick);
			if (expertise!=null) {
				System.out.println(expertise);
				// CompanyConstants.setCompanyExpertise(expertise);
				Thread.sleep(5000);
				WebAction.selectDropDown(expertiseInputBox, expertise, expertiseValues, expertiseValuesXpath,
						"'" + expertise + "' value is not present in the expertise drop down");

			}
			WebAction.clickUsingJs(biographyTextArea);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter biography in background section
	 * 
	 * @throws Exception
	 */
	public void fillBiogrpahyDetails(String biography) throws Exception {
		try {
			CompanyProfileConstants.setCompanyBiography(biography); // set Method
			if (biography!=null) {
				WebAction.click(biographyTextArea);
				WebAction.sendKeys(biographyTextArea, biography);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter Multiple Phone number in contact info section
	 * @throws Exception 
	 * 
	 */
	public void fillPhoneNumberDetails(String Phone1, String Phone2, String Phone3, String Phone4) throws Exception {
		try {
			CompanyProfileConstants.setCompanyPhone0(Phone1);
			CompanyProfileConstants.setCompanyPhone1(Phone2);
			CompanyProfileConstants.setCompanyPhone2(Phone3);
			CompanyProfileConstants.setCompanyPhone3(Phone4);
			WebAction.scrollIntoView(phoneLabelText);
			WebAction.sendKeys(phoneNo0, Phone1);
			WebAction.sendKeys(phoneNo1, Phone2);
			WebAction.sendKeys(phoneNo2, Phone3);
			WebAction.sendKeys(phoneNo3, Phone4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Favorite phone-no in Contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void selectFavoritePhone(String phone) throws Exception {
		try {
			WebAction.scrollIntoView(phoneNo0);
			int phoneFavoriteIndex = Integer.parseInt(phone.substring(0, 1)) - 1;
			WebAction.clickUsingJs(phoneFavoriteButtons.get(phoneFavoriteIndex));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter Multiple Email id's in contact info section
	 * @throws Exception 
	 * 
	 */
	public void fillEmailDetails(String Email1, String Email2, String Email3, String Email4) throws Exception {
		try {
			CompanyProfileConstants.setCompanyEmail0(Email1);
			CompanyProfileConstants.setCompanyEmail1(Email2);
			CompanyProfileConstants.setCompanyEmail2(Email3);
			CompanyProfileConstants.setCompanyEmail3(Email4);
			WebAction.scrollIntoView(phoneLabelText);
			WebAction.sendKeys(email0, Email1);
			WebAction.sendKeys(email1, Email2);
			WebAction.sendKeys(email2, Email3);
			WebAction.sendKeys(email3, Email4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Favorite email in Contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void selectFavoriteEmail(String email) throws Exception {
		try {
			int emailFavoriteIndex = Integer.parseInt(email.substring(0, 1)) - 1;
			WebAction.scrollIntoView(emailFavoriteButtons.get(emailFavoriteIndex));
			WebAction.clickUsingJs(emailFavoriteButtons.get(emailFavoriteIndex));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter other social links in contact info section
	 * @throws Exception 
	 * 
	 */
	public void fillSocialMiscDetails(String other1, String other2, String other3, String other4) throws Exception {
		try {
			CompanyProfileConstants.setCompanyTwitter(other1);
			CompanyProfileConstants.setCompanyLinkedIn(other2);
			CompanyProfileConstants.setCompanyVideo(other3);
			CompanyProfileConstants.setCompanyWebsite(other4);
			WebAction.scrollIntoView(phoneLabelText);
			WebAction.sendKeys(other0, other1);
			WebAction.sendKeys(otherfield1, other2);
			WebAction.sendKeys(otherfield2, other3);
			WebAction.sendKeys(otherfield3, other4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Favorite social in Contact info section
	 * 
	 * @throws Exception
	 */
	public void selectFavoriteSocialMisc(String other) throws Exception {
		int otherFavoriteIndex = 0;
		try {
			switch (other.toUpperCase()) {
			case "TWITTER":
				otherFavoriteIndex = 0;
				break;
			case "LINKEDIN":
				otherFavoriteIndex = 1;
				break;
			case "VIDEO":
				otherFavoriteIndex = 2;
				break;
			case "WEBSITE":
				otherFavoriteIndex = 3;
				break;
			}
			WebAction.clickUsingJs(othersFavoriteButtons.get(otherFavoriteIndex));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter Address details in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillAddressDetails(String address1, String address2, String city, String state, String zip,
			String country) throws Exception {

		CompanyProfileConstants.setAddressField1(address1);
		CompanyProfileConstants.setAddressField2(address2);
		CompanyProfileConstants.setAddressCityField(city);
		CompanyProfileConstants.setAddressStateField(state);
		CompanyProfileConstants.setAddressZipField(zip);
		CompanyProfileConstants.setAddressCountryField(country);

		try {
			WebAction.scrollIntoView(addressLabel);
			WebAction.sendKeys(addressLine1, address1);
			WebAction.sendKeys(addressLine2, address2);
			WebAction.sendKeys(addressCity, city);
			if (state!=null) {
				WebAction.selectDropDown(addressState, state, dropDownValues, dropDownValuesXpath, "'" + state + "' value is not present in the drop down");
				
			}
			WebAction.sendKeys(addressZip, zip);
			if (country!=null) {
				WebAction.selectDropDown(addressCountry, country, dropDownValues, dropDownValuesXpath,
						"'" + country + "' value is not present in the drop down");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter Alerts in contact info section
	 * @throws Exception 
	 * 
	 */
	public void fillAlertsDetails(String alertInfo) throws Exception {
		try {
			CompanyProfileConstants.setCompanyAlerts(alertInfo);
			WebAction.sendKeys(alertsDetails, alertInfo);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Create button once entering all fields
	 * 
	 * @throws Exception
	 */
	public void clickButton(String buttonType) throws Exception {
		try {
			switch (buttonType.toUpperCase()) {
			case "CREATE":
				WebAction.click(createCompanyButton);
				break;
			}
			Thread.sleep(10000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}

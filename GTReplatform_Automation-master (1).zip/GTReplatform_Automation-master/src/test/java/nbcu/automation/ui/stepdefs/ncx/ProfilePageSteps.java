package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.ncx.ProfilePage;

public class ProfilePageSteps {

	ProfilePage profilePage = new ProfilePage();

	@Given("verify user captures user profile details in profile page")
	public void verifyHomePageLoaded() throws Exception {
		profilePage.fetchUserDetails();
	}
}

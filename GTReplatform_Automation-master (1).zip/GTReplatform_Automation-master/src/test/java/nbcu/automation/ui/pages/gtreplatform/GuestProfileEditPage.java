package nbcu.automation.ui.pages.gtreplatform;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.comparator.ListOfMapComparator;
import nbcu.automation.ui.constants.gtreplatform.CompanyProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.ProxyConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.CommonUtils;

public class GuestProfileEditPage {

	// Header element
	@FindBy(xpath = "//h2[text()='Guest Profile']")
	WebElement guestProfileHeader;

	// Upload photo
	@FindBy(xpath = "//button[span[text()='Upload Photo']]")
	WebElement uploadPhotoIcon;

	// Tabs
	@FindBy(xpath = "//button[span[text()='Basic Info']]")
	WebElement basicInfoTab;

	@FindBy(xpath = "//button[span[text()='Job Info']]")
	WebElement jobInfoTab;

	// Display Name elements
	@FindBy(id = "BasicInfo_displayName")
	WebElement displayNameTextBox;

	@FindBy(id = "BasicInfo_pronunciation")
	WebElement pronunciationTextBox;

	// Name elements
	@FindBy(id = "BasicInfo_title")
	WebElement titleDropDown;

	@FindBy(id = "BasicInfo_firstName")
	WebElement firstNameTextBox;

	@FindBy(id = "BasicInfo_middleName")
	WebElement middleNameTextBox;

	@FindBy(id = "BasicInfo_lastName")
	WebElement lastNameTextBox;

	@FindBy(id = "BasicInfo_suffix")
	WebElement suffixDropDown;

	// Drop down value xpath
	String dropDownvaluesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownvalues;

	// Ticker element
	@FindBy(id = "BasicInfo_ticker")
	WebElement tickerTextBox;

	// Demographics elements
	@FindBy(xpath = "//span[text()='Self-Identifying']/preceding-sibling::span/input")
	WebElement selfIdefityCheckBox;

	@FindBy(id = "BasicInfo_gender")
	WebElement genderDropdown;

	@FindBy(id = "BasicInfo_ethnicity")
	WebElement ethnicityDropdown;

	@FindBy(xpath = "//span[input[@value='LGBTQIA+']]")
	WebElement lgbtqiaCheckBox;

	@FindBy(xpath = "//span[input[@value='Disabled']]")
	WebElement disabledCheckBox;

	@FindBy(xpath = "//span[input[@value='Veteran']]")
	WebElement veteranCheckBox;

	@FindBy(id = "BasicInfo_languages")
	WebElement languageTextBox;

	// NBC employee elements
	@FindBy(xpath = "//span[text()='NBC Employee']/preceding-sibling::span/input")
	WebElement nbcEmployeeRadioButton;

	@FindBy(id = "BasicInfo_excludeFromReports")
	WebElement excludeFromReportsCheckBox;

	// Contributor elements
	@FindBy(xpath = "//span[text()='Contributor']/preceding-sibling::span/input")
	WebElement contributorRadioButton;

	@FindBy(xpath = "//span[text()='CNBC']/preceding-sibling::span/input")
	WebElement cnbcDivision;

	@FindBy(xpath = "//span[text()='MSNBC']/preceding-sibling::span/input")
	WebElement msnbcDivision;

	@FindBy(xpath = "//span[text()='NBC News']/preceding-sibling::span/input")
	WebElement nbcNewsDivision;

	@FindBy(xpath = "//span[text()='News NOW']/preceding-sibling::span/input")
	WebElement newsNowDivision;

	// Expertise elements
	@FindBy(xpath = "//span[text()='Select Expertise(s)']")
	WebElement expertiseDropDown;

	@FindBy(xpath = "//span[text()='Select Expertise(s)']/preceding-sibling::span/input")
	WebElement expertiseTextBox;

	// Biography elements
	@FindBy(id = "BasicInfo_biography_0")
	WebElement biographyTextBox;

	// Phone contact elements
	@FindBy(id = "Contact_Phone_0_phone")
	WebElement phoneContact1;

	@FindBy(id = "Contact_Phone_1_phone")
	WebElement phoneContact2;

	@FindBy(id = "Contact_Phone_2_phone")
	WebElement phoneContact3;

	@FindBy(id = "Contact_Phone_3_phone")
	WebElement phoneContact4;

	@FindBy(xpath = "//input[@id='Contact_Phone_0_phone']/following-sibling::span/button")
	WebElement phoneContact1Star;

	@FindBy(xpath = "//input[@id='Contact_Phone_1_phone']/following-sibling::span/button")
	WebElement phoneContact2Star;

	@FindBy(xpath = "//input[@id='Contact_Phone_2_phone']/following-sibling::span/button")
	WebElement phoneContact3Star;

	@FindBy(xpath = "//input[@id='Contact_Phone_3_phone']/following-sibling::span/button")
	WebElement phoneContact4Star;

	// Email contact elements
	@FindBy(id = "Contact_Email_0_email")
	WebElement emailContact1;

	@FindBy(id = "Contact_Email_1_email")
	WebElement emailContact2;

	@FindBy(id = "Contact_Email_2_email")
	WebElement emailContact3;

	@FindBy(id = "Contact_Email_3_email")
	WebElement emailContact4;

	@FindBy(xpath = "//input[@id='Contact_Email_0_email']/following-sibling::span/button")
	WebElement emailContact1Star;

	@FindBy(xpath = "//input[@id='Contact_Email_1_email']/following-sibling::span/button")
	WebElement emailContact2Star;

	@FindBy(xpath = "//input[@id='Contact_Email_2_email']/following-sibling::span/button")
	WebElement emailContact3Star;

	@FindBy(xpath = "//input[@id='Contact_Email_3_email']/following-sibling::span/button")
	WebElement emailContact4Star;

	// Social contact elements
	@FindBy(id = "Contact_Social_0_link")
	WebElement twitterContact;

	@FindBy(id = "Contact_Social_1_link")
	WebElement linkedInContact;

	@FindBy(id = "Contact_Misc_0_link")
	WebElement videoLink;

	@FindBy(id = "Contact_Misc_1_link")
	WebElement personalWebSiteLink;

	@FindBy(xpath = "//input[@id='Contact_Social_0_link']/following-sibling::span/button")
	WebElement twitterContactStar;

	@FindBy(xpath = "//input[@id='Contact_Social_1_link']/following-sibling::span/button")
	WebElement linkedInContactStar;

	@FindBy(xpath = "//input[@id='Contact_Misc_0_link']/following-sibling::span/button")
	WebElement videoContactStar;

	@FindBy(xpath = "//input[@id='Contact_Misc_1_link']/following-sibling::span/button")
	WebElement pernalWebSiteContactStar;

	// Address elements
	@FindBy(id = "Contact_Address_0_address1")
	WebElement addressLine1TextBox;

	@FindBy(id = "Contact_Address_0_address2")
	WebElement addressLine2TextBox;

	@FindBy(id = "Contact_Address_0_city")
	WebElement cityTextBox;

	@FindBy(id = "Contact_Address_0_state")
	WebElement stateDropdown;

	@FindBy(id = "Contact_Address_0_zip")
	WebElement zipTextBox;

	@FindBy(id = "Contact_Address_0_country")
	WebElement countryDropdown;

	// Alert elements
	@FindBy(id = "Alerts_notes")
	WebElement alertsTextBox;

	// Proxy contact
	@FindBy(xpath = "//span[text()='Search for Contacts to add...']/preceding-sibling::span/input")
	WebElement additionalContactTextBox;

	// Drop down value xpath
	String additionalDropDownvaluesXpath = "//div[contains(@class,'ant-select-item-option-content')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item-option-content')]")
	List<WebElement> additionalDropDownvalues;

	@FindBy(xpath = "//div[@data-component='components/cards/proxy']")
	List<WebElement> additionalContactPlaceholder;

	// add job elements
	@FindBy(xpath = "//button[span[text()='Add Job']]")
	WebElement addJobButton;

	@FindBy(xpath = "//span[text()='Primary Job']/preceding-sibling::span/input")
	WebElement primaryJobRadioButton;

	@FindBy(xpath = "//label[span[text()='Active']]")
	WebElement activeJobStatus;

	@FindBy(xpath = "//label[span[text()='Inactive']]")
	WebElement inActiveJobStatus;

	@FindBy(xpath = "//label[@title='Start Date']/../following-sibling::div[1]//input")
	WebElement startDateTextBox;

	@FindBy(xpath = "//label[@title='End Date']/../following-sibling::div[1]//input")
	WebElement endDateTextBox;

	@FindBy(xpath = "//input[@placeholder='Job Title']")
	WebElement jobTitleTextBox;

	@FindBy(id = "category")
	WebElement categoryDropdown;

	@FindBy(xpath = "//input[@placeholder='Org/Company']")
	WebElement orgOrCompanyDropdown;

	@FindBy(id = "department")
	WebElement departmentDropdown;

	@FindBy(id = "notes")
	WebElement notesTextBox;

	@FindBy(xpath = "//button[span[text()=' Add Job']]")
	WebElement addJobInRhDrawer;

	// added job elements
	@FindBy(xpath = "//div[contains(@class,'jobHeader')]")
	List<WebElement> addedJobTitle;

	@FindBy(xpath = "//span[contains(@class,'status') and text()='Active' or text()='InActive']")
	List<WebElement> addedJobStatus;

	@FindBy(xpath = "//span[contains(@class,'status')]/span[contains(@class,'primary')]")
	WebElement addedJobPrimaryJob;

	@FindBy(xpath = "//td[div[text()='Start Date:']]/following-sibling::td/div")
	List<WebElement> addedJobStartDate;

	@FindBy(xpath = "//td[div[text()='Category:']]/following-sibling::td/div")
	List<WebElement> addedJobCategory;

	@FindBy(xpath = "//td[div[text()='Org/Company:']]/following-sibling::td/div")
	List<WebElement> addedJobCompanyName;

	@FindBy(xpath = "//td[div[text()='Department:']]/following-sibling::td/div")
	List<WebElement> addedJobDepartment;

	@FindBy(xpath = "//td[div[text()='Notes:']]/following-sibling::td/div")
	List<WebElement> addedJobNotes;

	// create button
	@FindBy(xpath = "//button[span[@aria-label='save']]")
	WebElement createButton;

	// cancel button
	@FindBy(xpath = "//button[span[text()='Cancel']]")
	WebElement cancelButton;

	// Deactivate Account button
	@FindBy(xpath = "//button[span[text()='Deactivate Account']]")
	WebElement deactivateAccountButton;

	// Reactivate Account button
	@FindBy(xpath = "//button[span[text()='Reactivate Account']]")
	WebElement reactivateAccountButton;

	// Deactivate account popup elements
	@FindBy(xpath = "//span[text()='Profile Deactivation']")
	WebElement deactivateAccountPopUpHeader;

	@FindBy(xpath = "//div[@class='ant-modal-confirm-content']")
	WebElement deactivateAccountPopUpContent;

	@FindBy(xpath = "//button[span='No']")
	WebElement popUp_NoButton;

	@FindBy(xpath = "//button[span='Yes']")
	WebElement popUp_YesButton;

	public GuestProfileEditPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify guest profile page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyGuestProfileEditPageDisplayed() throws Exception {
		Waits.waitForElement(uploadPhotoIcon, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * To select Basic Info or Job Info tab
	 * 
	 * @param tabType
	 * @throws Exception
	 */
	public void openBasicOrJobInfoTab(String tabType) throws Exception {
		try {
			if (tabType.equalsIgnoreCase("BASIC INFO")) {
				WebAction.scrollIntoView(basicInfoTab);
				WebAction.clickUsingJs(basicInfoTab);
			} else {
				WebAction.scrollIntoView(jobInfoTab);
				WebAction.clickUsingJs(jobInfoTab);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill display name details of guest profile in basic info section
	 * 
	 * @param displayname
	 * @param Pronunciation
	 * @throws Exception
	 */
	public void fillDisplayNamedetails(String displayName, String pronunciation) throws Exception {
		try {

			WebAction.scrollIntoView(displayNameTextBox);

			if (displayName != null) {
				displayName = displayName + "_" + CommonUtils.generateRandomString(10);
				GuestProfileConstants.setDisplayName(displayName);
				WebAction.sendKeys(displayNameTextBox, displayName);
			}

			if (pronunciation != null) {
				GuestProfileConstants.setPronunciation(pronunciation);
				WebAction.sendKeys(pronunciationTextBox, pronunciation);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill name details of guest profile in basic info section
	 * 
	 * @param title
	 * @param firstName
	 * @param middlename
	 * @param lastName
	 * @param suffix
	 * @throws Exception
	 */
	public void fillNamedetails(String title, String firstName, String middlename, String lastName, String suffix)
			throws Exception {
		try {

			// To scroll
			WebAction.scrollIntoView(pronunciationTextBox);

			// To fill title
			if (title != null)
				WebAction.selectDropDown(titleDropDown, title, dropDownvaluesXpath, dropDownvalues,
						"'" + title + "' value is not present in the title drop down");

			// To fill first name
			WebAction.sendKeys(firstNameTextBox, firstName);

			// To fill middle name
			if (middlename != null)
				WebAction.sendKeys(middleNameTextBox, middlename);

			// To fill last name
			lastName = lastName + "_" + CommonUtils.generateRandomString(10);
			WebAction.sendKeys(lastNameTextBox, lastName);

			// To fill suffix
			if (suffix != null) {
				WebAction.click(suffixDropDown);
				WebAction.selectDropDown(suffixDropDown, suffix, dropDownvaluesXpath, dropDownvalues,
						"'" + suffix + "' value is not present in the suffix drop down");
			}

			// form full name
			String fullName = firstName + " " + lastName;
			GuestProfileConstants.setFullNameWithoutTitleAndSuffix(fullName);
			System.out.println("Profile FullName:" + fullName);
			if (title != null)
				fullName = title + " " + fullName;

			if (suffix != null)
				fullName = fullName + " " + suffix;

			GuestProfileConstants.setFullName(fullName);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill ticker details of guest profile in basic info section
	 * 
	 * @param displayname
	 * @param Pronunciation
	 * @throws Exception
	 */
	public void fillTickerDetails(DataTable params) throws Exception {
		try {
			List<Map<String, String>> tickers = CucumberUtils.getValuesFromDataTableAsList(params);
			String tickerList = "";
			for (int i = 0; i < tickers.size(); i++) {
				tickerList = tickerList + tickers.get(i).get("Ticker") + ", ";
				WebAction.sendKeys(tickerTextBox, tickers.get(i).get("Ticker"));
				WebAction.keyPress(tickerTextBox, "ENTER");
			}

			if (tickers.size() > 0) {
				tickerList = tickerList.substring(0, tickerList.length() - 2);
				GuestProfileConstants.setTicker(tickerList);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill demographics details
	 * 
	 * @param selfIdentify
	 * @param selfIdentityDescription
	 * @param gender
	 * @param ethnicity
	 * @param other
	 * @param language
	 * @throws Exception
	 */
	public void fillDemographicsDetail(String selfIdentify, String gender, String ethnicity, String other,
			String language) throws Exception {
		try {

			// To fill self identify
			if (selfIdentify != null) {
				if (selfIdentify.equalsIgnoreCase("YES")) {
					WebAction.clickUsingJs(selfIdefityCheckBox);
					GuestProfileConstants.setSelfIdentifying(selfIdentify);
				} else
					GuestProfileConstants.setSelfIdentifying("No");
			}

			// To fill gender
			WebAction.clickUsingJs(genderDropdown);
			WebAction.selectDropDown(genderDropdown, gender, dropDownvaluesXpath, dropDownvalues,
					"'" + gender + "' value is not present in the gender drop down");
			GuestProfileConstants.setGender(gender);

			// To fill ethnicity
			WebAction.selectDropDown(ethnicityDropdown, ethnicity, dropDownvaluesXpath, dropDownvalues,
					"'" + ethnicity + "' value is not present in the Ehnicity drop down");
			GuestProfileConstants.setEthnicity(ethnicity);

			// To select other check boxs
			if (other != null) {
				GuestProfileConstants.setOther(other);
				String[] otherArr = other.split(",");
				for (String eachOther : otherArr) {
					eachOther = eachOther.trim();
					switch (eachOther.toUpperCase()) {
					case "LGBTQIA+":
						WebAction.click(lgbtqiaCheckBox);
						break;
					case "DISABLED":
						WebAction.click(disabledCheckBox);
						break;
					case "VETERAN":
						WebAction.click(veteranCheckBox);
						break;
					}
				}
			} else if(GuestProfileConstants.getOther()==null)
				GuestProfileConstants.setOther("NA");

			// To fill languages
			if (language != null) {
				GuestProfileConstants.setLanguages(language);
				String[] languageArr = language.split(",");
				for (String eachLanguage : languageArr) {
					eachLanguage = eachLanguage.trim();
					WebAction.sendKeys(languageTextBox, eachLanguage);
					WebAction.keyPress(languageTextBox, "ENTER");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select NBC employee and exclude from reports
	 * 
	 * @param nbcEmployee        - YES/NO
	 * @param excludeFromReports - YES/NO
	 * @throws Exception
	 */
	public void fillNbcEmployeeDetails(String nbcEmployee, String excludeFromReports) throws Exception {
		try {
			WebAction.scrollIntoView(nbcEmployeeRadioButton);
			if (nbcEmployee.equalsIgnoreCase("YES"))
				WebAction.clickUsingJs(nbcEmployeeRadioButton);

			if (excludeFromReports.equalsIgnoreCase("YES"))
				WebAction.clickUsingJs(excludeFromReportsCheckBox);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill contributor details
	 * 
	 * @param contributor - Contributer Yes/No
	 * @param division    - contributor division
	 * @throws Exception
	 */
	public void fillContributorDetails(String contributor, String division) throws Exception {
		try {
			if (contributor.equalsIgnoreCase("YES")) {
				GuestProfileConstants.setContributors(division);
				WebAction.clickUsingJs(contributorRadioButton);
				String[] divisionList = division.split(",");
				for (String eachDivision : divisionList) {
					switch (eachDivision.trim().toUpperCase()) {
					case "CNBC":
						WebAction.clickUsingJs(cnbcDivision);
						break;
					case "MSNBC":
						WebAction.clickUsingJs(msnbcDivision);
						break;
					case "NBC NEWS":
						WebAction.clickUsingJs(nbcNewsDivision);
						break;
					case "NEWS NOW":
						WebAction.clickUsingJs(newsNowDivision);
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill expertise details
	 * 
	 * @param params
	 * @throws Exception
	 */
	public void fillExpertiseDetails(DataTable params) throws Exception {
		try {
			WebAction.clickUsingJs(expertiseDropDown);
			List<Map<String, String>> expertiseTags = CucumberUtils.getValuesFromDataTableAsList(params);
			GuestProfileConstants.setExpertiseCount(expertiseTags.size());
			for (int i = 0; i < expertiseTags.size(); i++) {
				Thread.sleep(1000);
				String expertiseValue = expertiseTags.get(i).get("Expertise");
				GuestProfileConstants.setExpertise(i, expertiseValue);
				WebAction.selectDropDown(expertiseTextBox, expertiseValue, dropDownvaluesXpath, dropDownvalues,
						"'" + expertiseValue + "' value is not present in expertise drop down field");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill biography details
	 * 
	 * @param biographyText
	 * @throws Exception
	 */
	public void fillBiographyDetails(String biographyText) throws Exception {
		try {
			if (biographyText != null) {
				GuestProfileConstants.setBiography(biographyText);
				WebAction.sendKeys(biographyTextBox, biographyText);
			} else
				GuestProfileConstants.setBiography("NA");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill phone contact details
	 * 
	 * @param office - Office phone number
	 * @param mobile - Mobile phone number
	 * @param phone1 - Phone 1
	 * @param phone2 - Phone 2
	 * @throws Exception
	 */
	public void fillPhoneContactDetails(String office, String mobile, String phone1, String phone2) throws Exception {
		try {
			if (office != null) {
				WebAction.sendKeys(phoneContact1, office);
				GuestProfileConstants.setOfficePhoneNumber(office);
			}
			if (mobile != null) {
				WebAction.sendKeys(phoneContact2, mobile);
				GuestProfileConstants.setMobilePhoneNumber(mobile);
			}
			if (phone1 != null) {
				WebAction.sendKeys(phoneContact3, phone1);
				GuestProfileConstants.setPhone1(phone1);
			}
			if (phone2 != null) {
				WebAction.sendKeys(phoneContact4, phone2);
				GuestProfileConstants.setPhone2(phone2);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select primary phone contact of guest profile
	 * 
	 * @param primaryPhoneContact - primary phone contact
	 * @throws Exception
	 */
	public void selectPrimaryPhoneContact(String primaryPhoneContact) throws Exception {
		try {
			GuestProfileConstants.setPrimaryCompany(primaryPhoneContact);
			if (primaryPhoneContact.equalsIgnoreCase("OFFICE")) {
				WebAction.scrollIntoView(phoneContact1);
				WebAction.clickUsingJs(phoneContact1Star);
			} else if (primaryPhoneContact.equalsIgnoreCase("MOBILE")) {
				WebAction.scrollIntoView(phoneContact2Star);
				WebAction.clickUsingJs(phoneContact2Star);
			} else if (primaryPhoneContact.equalsIgnoreCase("1-PHONE")) {
				WebAction.scrollIntoView(phoneContact3Star);
				WebAction.clickUsingJs(phoneContact3Star);
			} else if (primaryPhoneContact.equalsIgnoreCase("2-PHONE")) {
				WebAction.scrollIntoView(phoneContact4Star);
				WebAction.clickUsingJs(phoneContact4Star);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill email contact details
	 * 
	 * @param email1 - Email contact 1
	 * @param email2 - Email contact 2
	 * @param email3 - Email contact 3
	 * @param email4 - Email contact 4
	 * @throws Exception
	 */
	public void fillEmailContactDetails(String email1, String email2, String email3, String email4) throws Exception {
		try {
			if (email1 != null) {
				WebAction.sendKeys(emailContact1, email1);
				GuestProfileConstants.setEmailAddress(0, email1);
			}
			if (email2 != null) {
				WebAction.sendKeys(emailContact2, email2);
				GuestProfileConstants.setEmailAddress(1, email2);
			}
			if (email3 != null) {
				WebAction.sendKeys(emailContact3, email3);
				GuestProfileConstants.setEmailAddress(2, email3);
			}
			if (email4 != null) {
				WebAction.sendKeys(emailContact4, email4);
				GuestProfileConstants.setEmailAddress(3, email4);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select primary email contact of guest profile
	 * 
	 * @param primaryEmailContact - Primary email contact
	 * @throws Exception
	 */
	public void selectPrimaryEmailContact(String primaryEmailContact) throws Exception {
		try {
			if (primaryEmailContact != null) {
				GuestProfileConstants.setPrimaryCompany(primaryEmailContact);
				if (primaryEmailContact.equalsIgnoreCase("1-EMAIL")) {
					WebAction.clickUsingJs(emailContact1Star);
				} else if (primaryEmailContact.equalsIgnoreCase("2-EMAIL")) {
					WebAction.clickUsingJs(emailContact2Star);
				} else if (primaryEmailContact.equalsIgnoreCase("3-EMAIL")) {
					WebAction.clickUsingJs(emailContact3Star);
				} else if (primaryEmailContact.equalsIgnoreCase("4-EMAIL")) {
					WebAction.clickUsingJs(emailContact4Star);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill other contact details
	 * 
	 * @param twitter  - twitter contact
	 * @param linkedIn - linked in contact
	 * @param video    - video contact
	 * @param webSite  - web site contact
	 * @throws Exception
	 */
	public void fillOtherContactDetails(String twitter, String linkedIn, String video, String webSite)
			throws Exception {
		try {
			if (twitter != null) {
				GuestProfileConstants.setTwitterLink(twitter);
				WebAction.sendKeys(twitterContact, twitter);
			}
			if (linkedIn != null) {
				GuestProfileConstants.setLinkedInLink(linkedIn);
				WebAction.sendKeys(linkedInContact, linkedIn);
			}
			if (video != null) {
				GuestProfileConstants.setVideoLink(video);
				WebAction.sendKeys(videoLink, video);
			}
			if (webSite != null) {
				GuestProfileConstants.setWebSiteLink(webSite);
				WebAction.sendKeys(personalWebSiteLink, webSite);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select primary other contact
	 * 
	 * @param primaryOtherContact - Primary other contact
	 * @throws Exception
	 */
	public void selectPrimaryOtherContact(String primaryOtherContact) throws Exception {
		try {
			GuestProfileConstants.setPrimaryOther(primaryOtherContact);
			if (primaryOtherContact.equalsIgnoreCase("TWITTER")) {
				WebAction.clickUsingJs(twitterContactStar);
			} else if (primaryOtherContact.equalsIgnoreCase("LINKEDIN")) {
				WebAction.clickUsingJs(linkedInContactStar);
			} else if (primaryOtherContact.equalsIgnoreCase("VIDEO")) {
				WebAction.clickUsingJs(videoContactStar);
			} else if (primaryOtherContact.equalsIgnoreCase("WEBSITE")) {
				WebAction.clickUsingJs(pernalWebSiteContactStar);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill address contact details
	 * 
	 * @param addressLine1 - Address line1
	 * @param addressLine2 - Address line2
	 * @param city         - city
	 * @param state        - state
	 * @param zip          - zip code
	 * @param country      - country
	 * @throws Exception
	 */
	public void fillAdrressDetails(String addressLine1, String addressLine2, String city, String state, String zip,
			String country) throws Exception {
		try {
			WebAction.scrollIntoView(addressLine1TextBox);
			if (addressLine1 != null) {
				GuestProfileConstants.setAddressLine1(addressLine1);
				WebAction.sendKeys(addressLine1TextBox, addressLine1);
			}
			if (addressLine2 != null) {
				GuestProfileConstants.setAddressLine2(addressLine2);
				WebAction.sendKeys(addressLine2TextBox, addressLine2);
			}
			if (city != null) {
				GuestProfileConstants.setCity(city);
				WebAction.sendKeys(cityTextBox, city);
			}
			if (state != null) {
				GuestProfileConstants.setState(state);
				WebAction.selectDropDown(stateDropdown, state, dropDownvaluesXpath, dropDownvalues,
						"'" + state + "' value is not present in state drop down field");
			}
			if (country != null) {
				GuestProfileConstants.setCountry(country);
				WebAction.selectDropDown(countryDropdown, country, dropDownvaluesXpath, dropDownvalues,
						"'" + country + "' value is not present in country drop down field");
			}
			if (zip != null) {
				GuestProfileConstants.setZipCode(zip);
				WebAction.sendKeys(zipTextBox, zip);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill alert details of guest profile
	 * 
	 * @param alert - alert text
	 * @throws Exception
	 */
	public void fillAlertDetails(String alert) throws Exception {
		try {
			if (alert != null) {
				GuestProfileConstants.setAlert(alert);
				WebAction.clearUsingKeys(alertsTextBox);
				WebAction.sendKeys(alertsTextBox, alert);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To add additional contacts in guest profile
	 * 
	 * @param proxyProfileName - proxy profile name
	 * @throws Exception
	 */
	public void addAdditionalContact(DataTable params) throws Exception {
		try {
			// To scroll into additional contact field
			WebAction.scrollIntoView(additionalContactTextBox);

			String createdProfileProfileFullName = ProxyConstants.getFullName();
			List<Map<String, String>> proxyProfileNames = CucumberUtils.getValuesFromDataTableAsList(params);

			// To add proxy contact which created
			if (createdProfileProfileFullName != null) {
				int previousProxyContactCount = additionalContactPlaceholder.size();
				WebAction.selectDropDown(additionalContactTextBox, createdProfileProfileFullName + " (Proxy)",
						dropDownvaluesXpath, dropDownvalues, "'" + createdProfileProfileFullName
								+ "' proxy contact is not present in additional contacts drop down");
				previousProxyContactCount = previousProxyContactCount + 1;
				Assert.assertEquals(proxyProfileNames.size(), previousProxyContactCount,
						"Proxy contact '" + createdProfileProfileFullName + "' is not added in additional contact");
			}
			// To add search and add proxy contact
			else if (proxyProfileNames.size() > 0) {
				for (int i = 0; i < proxyProfileNames.size(); i++) {
					int previousProxyContactCount = additionalContactPlaceholder.size();
					String proxyProfileName = proxyProfileNames.get(i).get("Proxy contact");

					// To select search and select proxy contact
					boolean valuePresent = false;
					WebAction.sendKeys_WithoutClear(additionalContactTextBox, proxyProfileName);
					Waits.waitUntilElementSizeGreater(By.xpath(additionalDropDownvaluesXpath), 0);
					Thread.sleep(800);
					for (WebElement ele : additionalDropDownvalues) {
						String values = WebAction.getText(ele).trim();
						System.out.println("**value**:" + values);
						if (values.contains(proxyProfileName)) {
							WebAction.click(ele);
							valuePresent = true;
							break;
						}
					}

					if (valuePresent == false)
						throw new Exception("'" + proxyProfileName
								+ "' proxy contact is not present in additional contacts drop down");

					// To validate proxy contact is added
					previousProxyContactCount = previousProxyContactCount + 1;
					Assert.assertEquals(additionalContactPlaceholder.size(), previousProxyContactCount,
							"Proxy contact '" + proxyProfileName + "' is not added in additional contact");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To add job
	 * 
	 * @param primaryJob          - Primary job
	 * @param activeOrInactiveJob - Active or Incative job
	 * @param startDate           - Start date
	 * @param endDate             - End date
	 * @param jobTitle            - Job title
	 * @param category            - category
	 * @param companyName         - company name
	 * @param department          - department
	 * @param jobNotes            - Job notes
	 * @throws Exception
	 */
	public void addJob(DataTable params) throws Exception {
		try {
			// sort job details by start date
			List<Map<String, String>> jobDetails = sortJobDetailsByStartDate(params);
			GuestProfileConstants.setGuestJobCount(jobDetails.size());

			for (int i = 0; i < jobDetails.size(); i++) {

				// Click Add job button
				WebAction.click(addJobButton);

				// select primary job
				if (i > 0) {
					String primaryJob = jobDetails.get(i).get("Primary Job");
					if (primaryJob.equalsIgnoreCase("YES")) {
						GuestProfileConstants.setPrimaryJob(i, primaryJob);
						WebAction.click(primaryJobRadioButton);
					}

				} else
					GuestProfileConstants.setPrimaryJob(0, "Yes");

				// select job status
				String jobStatus = jobDetails.get(i).get("Job Status");
				GuestProfileConstants.setGuestJobStatus(i, jobStatus);
				if (jobStatus.equalsIgnoreCase("ACTIVE"))
					WebAction.click(activeJobStatus);
				else
					WebAction.click(inActiveJobStatus);

				// fill start date
				String startDate = jobDetails.get(i).get("Start Date");
				if (startDate != null) {
					WebAction.click(startDateTextBox);
					WebAction.sendKeys(startDateTextBox, startDate);
					GuestProfileConstants.setGuestJobStartDate(i, startDate);
				} else
					GuestProfileConstants.setGuestJobStartDate(i, "NA");

				// fill end date
				String endDate = jobDetails.get(i).get("End Date");
				if (jobStatus.equalsIgnoreCase("INACTIVE")) {
					if (endDate != null)
						WebAction.sendKeys(endDateTextBox, endDate);
				} else
					Assert.assertFalse(WebAction.isEnabled(endDateTextBox), "End date text box is enabled");

				// fill job title
				String jobTitle = jobDetails.get(i).get("Job Title");
				WebAction.sendKeys(jobTitleTextBox, jobTitle);
				GuestProfileConstants.setGuestJobTitle(i, jobTitle);

				// Setting primary job title
				if ((jobDetails.get(i).get("Primary Job").equalsIgnoreCase("Yes")) || (jobDetails.size() == 1))
					GuestProfileConstants.setPrimaryJobTitle(jobTitle);

				// fill category
				String category = jobDetails.get(i).get("Category");
				if (category != null) {
					WebAction.selectDropDown(categoryDropdown, category, dropDownvaluesXpath, dropDownvalues,
							"'" + category + "' is not present in category drop down");
					GuestProfileConstants.setGuestJobCategory(i, category);
				} else
					GuestProfileConstants.setGuestJobCategory(i, "NA");

				// fill company
				String company = CompanyProfileConstants.getCompanyName();
				if (company != null) {
					Thread.sleep(1000);
					WebAction.selectDropDown(orgOrCompanyDropdown, company, dropDownvaluesXpath, dropDownvalues,
							"'" + company + "' is not present in company drop down");
					GuestProfileConstants.setGuestJobCompany(i, company);
				} else {
					company = jobDetails.get(i).get("Org/Company");
					if (company != null) {
						WebAction.selectDropDown(orgOrCompanyDropdown, company, dropDownvaluesXpath, dropDownvalues,
								"'" + company + "' is not present in company drop down");
						GuestProfileConstants.setGuestJobCompany(i, company);
					} else
						GuestProfileConstants.setGuestJobCompany(i, "NA");
				}
				// Setting primary company
				if ((jobDetails.get(i).get("Primary Job").equalsIgnoreCase("Yes")) || (jobDetails.size() == 1)) {
					if (!(GuestProfileConstants.getGuestJobCompany(i).equalsIgnoreCase("NA")))
						GuestProfileConstants.setPrimaryCompany(GuestProfileConstants.getGuestJobCompany(i));
				}

				// fill department
				String department = jobDetails.get(i).get("Department");
				if (department != null) {
					GuestProfileConstants.setGuestJobDepartment(i, department);
					WebAction.sendKeys(departmentDropdown, department);
				} else
					GuestProfileConstants.setGuestJobDepartment(i, "NA");

				// fill job notes
				String jobNotes = jobDetails.get(i).get("Job Notes");
				if (jobNotes != null) {
					GuestProfileConstants.setGuestJobNotes(i, jobNotes);
					WebAction.sendKeys(notesTextBox, jobNotes);
				} else
					GuestProfileConstants.setGuestJobNotes(i, "NA");

				// Click Add job
				WebAction.clickUsingJs(addJobInRhDrawer);

				// Validate added job details
				Waits.waitForElement(addJobButton, WAIT_CONDITIONS.CLICKABLE);
				CommonValidations.verifyTextValue(addedJobTitle.get(i), jobTitle,
						"Guest profile job title is not matching in job info tab");
				CommonValidations.verifyAttributeValue(addedJobStatus.get(i), "innerHTML", jobStatus,
						"Guest profile job status is not matching in job info tab");
				if (startDate != null)
					CommonValidations.verifyTextValue(addedJobStartDate.get(addedJobStartDate.size() - 1), startDate,
							"Guest profile job start date is not matching in job info tab");
				if (category != null)
					CommonValidations.verifyTextValue(addedJobCategory.get(addedJobCategory.size() - 1), category,
							"Guest profile job category is not matching in job info tab");
				if (company != null)
					CommonValidations.verifyTextValue(addedJobCompanyName.get(addedJobCompanyName.size() - 1), company,
							"Guest profile org/company name is not matching in job info tab");
				if (department != null)
					CommonValidations.verifyTextValue(addedJobDepartment.get(addedJobDepartment.size() - 1), department,
							"Guest profile department is not matching in job info tab");
				if (jobNotes != null)
					CommonValidations.verifyTextValue(addedJobNotes.get(addedJobNotes.size() - 1), jobNotes,
							"Guest profile job notes is not matching in job info tab");

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public List<Map<String, String>> sortJobDetailsByStartDate(DataTable params) throws Exception {
		List<Map<String, String>> jobDetails = CucumberUtils.getValuesFromDataTableAsList(params);

		// list of null and non null start date
		List<Map<String, String>> nullStartDateJobDetails = new ArrayList<Map<String, String>>();
		List<Map<String, String>> notANullStartDateJobDetails = new ArrayList<Map<String, String>>();
		try {
			for (int i = 0; i < jobDetails.size(); i++) {
				if (jobDetails.get(i).get("Start Date") == null)
					nullStartDateJobDetails.add(jobDetails.get(i));
				else
					notANullStartDateJobDetails.add(jobDetails.get(i));
			}

			Collections.sort(notANullStartDateJobDetails, new ListOfMapComparator());
			notANullStartDateJobDetails.addAll(nullStartDateJobDetails);

			System.out.println(notANullStartDateJobDetails);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return notANullStartDateJobDetails;
	}

	/**
	 * To click button
	 * 
	 * @param buttonName - button name
	 * @throws Exception
	 */
	public void clickButton(String buttonName) throws Exception {
		try {
			switch (buttonName.toUpperCase()) {
			case "CREATE":
			case "UPDATE":
				WebAction.click(createButton);
				Waits.waitForElementToDisappear(createButton);
				break;
			case "CANCEL":
				WebAction.click(cancelButton);
				break;
			case "DEACTIVATE ACCOUNT":
				WebAction.click(deactivateAccountButton);
				break;
			case "REACTIVATE ACCOUNT":
				WebAction.click(reactivateAccountButton);
				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify deactivate account popup is displayed
	 * 
	 * @param popUpMessage
	 * @throws Exception
	 */
	public void verifyDeActivateAccountPopup(String popUpMessage) throws Exception {
		try {
			Waits.waitForElement(deactivateAccountPopUpHeader, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(deactivateAccountPopUpContent, popUpMessage,
					"Deactivate account popup message is not matched");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Yes/No in popup
	 * 
	 * @param buttonName
	 * @throws Exception
	 */
	public void clickButtonOnPopUp(String buttonName) throws Exception {
		try {
			if (buttonName.equalsIgnoreCase("YES"))
				WebAction.click(popUp_YesButton);
			else if (buttonName.equalsIgnoreCase("NO"))
				WebAction.click(popUp_NoButton);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}

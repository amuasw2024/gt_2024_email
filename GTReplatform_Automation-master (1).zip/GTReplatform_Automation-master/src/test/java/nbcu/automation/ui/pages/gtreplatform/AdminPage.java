package nbcu.automation.ui.pages.gtreplatform;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.gtreplatform.AdminConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.others.CommonUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class AdminPage {

	// Drop down value xpath
	String dropDownvaluesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownvalues;

	// Table rows element
	@FindBy(xpath = "//tbody[@class='ant-table-tbody']/tr")
	List<WebElement> tableRows;

	String tableRowsXpath = "//tbody[@class='ant-table-tbody']/tr";

	// Tab elements
	@FindBy(xpath = "//li[span[text()='Business']]")
	WebElement businessTab;

	@FindBy(xpath = "//li[span[text()='Alerts']]")
	WebElement alertsTab;

	@FindBy(xpath = "//li[span[text()='Shows']]")
	WebElement showsTab;

	@FindBy(xpath = "//li[span[text()='Emails']]")
	WebElement emailsTab;

	@FindBy(xpath = "//li[span[text()='Studios']]")
	WebElement studiosTab;

	@FindBy(xpath = "//li[span[text()='Statuses/Type']]")
	WebElement statusOrTypeTab;

	@FindBy(xpath = "//li[span[text()='Tags']]")
	WebElement tagsTab;

	@FindBy(xpath = "//li[span[text()='Users']]")
	WebElement usersTab;

	@FindBy(xpath = "//li[span[text()='Car Services']]")
	WebElement carServicesTab;

	@FindBy(xpath = "//li[span[text()='Attachments']]")
	WebElement attachmentsTab;

	// common elements
	@FindBy(xpath = "//span[@aria-label='plus-square']")
	WebElement addNewEntryIcon;

	@FindBy(xpath = "//button[text()='Edit']")
	List<WebElement> editLink;

	@FindBy(xpath = "//button[text()='Delete']")
	WebElement deleteLink;

	@FindBy(className = "ant-modal-confirm-title")
	WebElement confirmPopUpTitle;

	@FindBy(className = "ant-modal-confirm-content")
	WebElement confirmPopUpContent;

	@FindBy(xpath = "//button[span[text()='Create']]")
	WebElement createButton;

	@FindBy(xpath = "//div[contains(text(),'same name Exists in DB')]")
	WebElement recordAlreadyExistsMessage;

	@FindBy(xpath = "//button[span[text()='Cancel']]")
	WebElement cancelButton;

	@FindBy(xpath = "//button[span[text()='OK']]")
	WebElement okButton;

	@FindBy(xpath = "//button[span[text()='Update']]")
	WebElement updateButton;

	@FindBy(xpath = "//button[span[text()='Save']]")
	WebElement saveButton;

	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchTextBox;
	
	@FindBy(xpath = "//span[@aria-label='close-circle']")
	WebElement clearSearchTextBox;

	@FindBy(xpath = "//div[text()='No data']")
	WebElement noDataInTable;

	// shows tab elements
	@FindBy(id = "name")
	WebElement showNameTextBox;

	@FindBy(id = "omsName")
	WebElement omsNameTextBox;

	@FindBy(id = "isExcludeFromReports")
	WebElement excludeFromReportsCheckBox;

	@FindBy(xpath = "//span[@aria-label='calendar']")
	List<WebElement> secheduleOrSpecialCalendar;

	@FindBy(xpath = "//input[@value='Sunday']")
	WebElement sundayCheckBox;

	@FindBy(xpath = "//input[@value='Monday']")
	WebElement mondayCheckBox;

	@FindBy(xpath = "//input[@value='Tuesday']")
	WebElement tuesdayCheckBox;

	@FindBy(xpath = "//input[@value='Wednesday']")
	WebElement wednesdayCheckBox;

	@FindBy(xpath = "//input[@value='Thursday']")
	WebElement thursdayCheckBox;

	@FindBy(xpath = "//input[@value='Friday']")
	WebElement fridayCheckBox;

	@FindBy(xpath = "//input[@value='Saturday']")
	WebElement saturdayCheckBox;

	@FindBy(xpath = "//input[@placeholder='Start time']")
	List<WebElement> startTimeTextBox;

	@FindBy(xpath = "//input[@placeholder='End time']")
	List<WebElement> endTimeTextBox;

	// Alerts tab elements
	String editAlertXpath = "//td[text()='<<Division>>']/following-sibling::td[3]//button[text()='Edit']";

	String clearAlertXpath = "//td[text()='<<Division>>']/following-sibling::td[3]//button[text()='Edit']";

	String timeIntervalXpath = "//td[text()='<<Division>>']/following-sibling::td[1]";

	@FindBy(xpath = "//div[@class='ant-modal-body']/header")
	WebElement alertPopUpHeader;

	@FindBy(id = "name")
	WebElement divisionNameTextBox;

	@FindBy(className = "ant-select-clear")
	WebElement clearTimeInterval;

	@FindBy(id = "alertTimeInterval")
	WebElement timeIntervalDropDown;

	@FindBy(id = "alertBuEmails")
	WebElement alertEmailTextBox;

	// Users tab elements
	@FindBy(xpath = "//h3[text()='Pending Users']")
	WebElement tableName;

	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchField;

	String listOfRegisteredSSOs = "//tbody[@class='ant-table-tbody']/tr[contains(@class,'ant-table-row')]";

	@FindBy(xpath = "//th[@title='Division']//span[@role='button']")
	WebElement filterIcon;

	@FindBy(xpath = "//span[text()='All']/../*/input[@type='checkbox']")
	WebElement selectALLCheckBox;

	String ssoDetailsXpath = "//td[@title=\"<<SSO Number>>\"]";

	@FindBy(xpath = "//div[@class='ant-space-item']/button[text()='Approve']")
	WebElement approveBtn;

	@FindBy(xpath = "//button[(@disabled)]//span[text()='Approve']")
	WebElement disableBtn;

	// Car services Tab elements
	@FindBy(id = "description")
	WebElement carServicesNameTextBox;

	@FindBy(id = "phone")
	WebElement carServicesPhoneTextBox;

	@FindBy(id = "country")
	WebElement carServicesCountryDropDown;

	@FindBy(id = "address1")
	WebElement carServicesAddress1TextBox;

	@FindBy(id = "city")
	WebElement carServicesCityTextBox;

	@FindBy(id = "state")
	WebElement carServicesStateDropDown;

	@FindBy(id = "zip")
	WebElement carServicesZipTextBox;

	public AdminPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	public void verifyAdminPageLoaded() throws Exception {
		Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
	}

	/**
	 * To click tab on admin page
	 * 
	 * @param tabName - tab name
	 * @throws Exception
	 */
	public void clickTab(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "BUSINESS":
				WebAction.click(businessTab);
				break;
			case "ALERTS":
				WebAction.click(alertsTab);
				break;
			case "SHOWS":
				WebAction.click(showsTab);
				break;
			case "EMAILS":
				WebAction.click(emailsTab);
				break;
			case "STUDIOS":
				WebAction.click(studiosTab);
				break;
			case "STATUSES/TYPE":
				WebAction.click(statusOrTypeTab);
				break;
			case "TAGS":
				WebAction.click(tagsTab);
				break;
			case "USERS":
				WebAction.click(usersTab);
				break;
			case "CAR SERVICES":
				WebAction.click(carServicesTab);
				break;
			case "ATTACHMENTS":
				WebAction.click(attachmentsTab);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify selected tab is Loaded
	 * 
	 * @param tabName
	 * @throws Exception
	 */
	public void verifyTabLoaded(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "BUSINESS":
				CommonValidations.verifyAttributeValue(businessTab, "class", "selected", "Business tab is not loaded");
				break;
			case "ALERTS":
				CommonValidations.verifyAttributeValue(alertsTab, "class", "selected", "Alers tab is not loaded");
				break;
			case "SHOWS":
				CommonValidations.verifyAttributeValue(showsTab, "class", "selected", "Shows tab is not loaded");
				break;
			case "EMAILS":
				CommonValidations.verifyAttributeValue(emailsTab, "class", "selected", "Emails tab is not loaded");
				break;
			case "STUDIOS":
				CommonValidations.verifyAttributeValue(studiosTab, "class", "selected", "Studios tab is not loaded");
				break;
			case "STATUSES/TYPE":
				CommonValidations.verifyAttributeValue(statusOrTypeTab, "class", "selected",
						"Status/Type tab is not loaded");
				break;
			case "TAGS":
				CommonValidations.verifyAttributeValue(tagsTab, "class", "selected", "Tags tab is not loaded");
				break;
			case "USERS":
				CommonValidations.verifyAttributeValue(usersTab, "class", "selected", "Users tab is not loaded");
				break;
			case "CAR SERVICES":
				CommonValidations.verifyAttributeValue(carServicesTab, "class", "selected",
						"Car services tab is not loaded");
				break;
			case "ATTACHMENTS":
				CommonValidations.verifyAttributeValue(attachmentsTab, "class", "selected",
						"Attachments tab is not loaded");
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click add/edit/delete link
	 * 
	 * @param linkName
	 * @throws Exception
	 */
	public void clickLink(String linkName) throws Exception {
		try {
			switch (linkName.toUpperCase()) {
			case "ADD":
				WebAction.click(addNewEntryIcon);
				break;
			case "EDIT":
				WebAction.click(editLink.get(0));
				break;
			case "DELETE":
				WebAction.click(deleteLink);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click button
	 * 
	 * @param buttonName - button name
	 * @throws Exception
	 */
	public void clickButton(String buttonName, String popUpName) throws Exception {
		try {
			switch (buttonName.toUpperCase()) {
			case "CREATE":
				WebAction.click(createButton);
				
				//To check car services record is already present
				if(popUpName.equalsIgnoreCase("CAR SERVICES")) {
				if (Waits.waitForElementIsDisplayed(recordAlreadyExistsMessage))
					clickButton("CANCEL", popUpName);
				}
					Waits.waitForElement(editLink.get(0), WAIT_CONDITIONS.CLICKABLE);
				break;
			case "UPDATE":
				WebAction.click(updateButton);
				break;
			case "CANCEL":
				WebAction.clickUsingJs(cancelButton);
				break;
			case "SAVE":
				WebAction.click(saveButton);
				break;
			case "OK":
				WebAction.click(okButton);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify pop up displayed to add show
	 * 
	 * @throws Exception
	 */
	public void verifyShowsPopUpDisplayed() throws Exception {
		try {
			Waits.waitForElement(showNameTextBox, WAIT_CONDITIONS.CLICKABLE);
			Assert.assertTrue(WebAction.isDisplayed(showNameTextBox), "Add show pop up is not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill show details in add show pop up
	 * 
	 * @param showName
	 * @param omsName
	 * @param excludeFromReports
	 * @throws Exception
	 */
	public void fillShowDetails(String showName, String omsName, String excludeFromReports) throws Exception {
		try {
			showName = showName + "_" + CommonUtils.generateRandomString(5);
			System.out.println("Show Name:" + showName);
			AdminConstants.setShowName(showName);
			WebAction.sendKeys(showNameTextBox, showName);

			if (omsName != null) {
				AdminConstants.setOmsName(omsName);
				WebAction.sendKeys(omsNameTextBox, omsName);
			}

			if (excludeFromReports != null) {
				AdminConstants.setExcludeFromReports(excludeFromReports);
				if (excludeFromReports.equalsIgnoreCase("YES"))
					WebAction.clickUsingJs(excludeFromReportsCheckBox);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To search any text in search is displayed in the table
	 * 
	 * @throws Exception
	 */
	public void searchInTable(String text) throws Exception {
		String searchText = "";
		try {
			switch (text.toUpperCase()) {
			case "SHOW":
				searchText = AdminConstants.getShowName();
				break;
			case "DIVISION":
				searchText = AdminConstants.getDivision();
				break;
			case "CAR SERVICES":
				searchText = AdminConstants.getCarServicesName();
				break;
			}

			Waits.waitForElement(editLink.get(0), WAIT_CONDITIONS.CLICKABLE);
			Waits.waitForElement(searchTextBox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(searchTextBox, searchText);
			WebAction.keyPress(searchTextBox, "ENTER");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify show is present in the table
	 * 
	 * @throws Exception
	 */
	public void verifyShowPresentInTable() throws Exception {
		try {
			Thread.sleep(4000);
			Waits.waitForElement(editLink.get(0), WAIT_CONDITIONS.CLICKABLE);
			for (WebElement element : tableRows) {
				if (element.isDisplayed()) {
					Waits.waitUntilAttributeValueChanges(element.findElement(By.xpath("td[2]")), "title",
							AdminConstants.getShowName());
					CommonValidations.verifyAttributeValue(element.findElement(By.xpath("td[2]")), "title",
							AdminConstants.getShowName(), "Newly added show is not present in the admin page");

					if (AdminConstants.getExcludeFromReports() != null) {
						if (AdminConstants.getExcludeFromReports().equalsIgnoreCase("YES"))
							CommonValidations.verifyColorOfElement(
									element.findElement(By.xpath("td[5]//span[@aria-label='check-circle']")), "color",
									"orange");
					}

					if (AdminConstants.getOmsName() != null)
						CommonValidations.verifyAttributeValue(element.findElement(By.xpath("td[6]")), "title",
								AdminConstants.getOmsName(), "OMS name is not correct in newly added show");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click schedule or special calendar
	 * 
	 * @throws Exception
	 */
	public void clickScheduleOrSpecials(String buttonType) throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(secheduleOrSpecialCalendar, 0);
			if (buttonType.equalsIgnoreCase("SCHEDULE"))
				WebAction.click(secheduleOrSpecialCalendar.get(0));
			else if (buttonType.equalsIgnoreCase("SPECIALS"))
				WebAction.click(secheduleOrSpecialCalendar.get(1));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify schedule pop up is displayed
	 * 
	 * @throws Exception
	 */
	public void verifySchedulePopUpDisplayed() throws Exception {
		try {
			Waits.waitForElement(saveButton, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To schedule show
	 * 
	 * @param days - days of schedule
	 * @throws Exception
	 */
	public void scheduleShow(String days, String startTime, String endTime) throws Exception {
		try {
			AdminConstants.setScheduleDays(days);
			String[] daysArr = days.split(",");
			for (int i = 0; i < daysArr.length; i++) {
				switch (daysArr[i].trim().toUpperCase()) {
				case "SUNDAY":
					WebAction.clickUsingJs(sundayCheckBox);
					break;
				case "MONDAY":
					WebAction.clickUsingJs(mondayCheckBox);
					break;
				case "TUESDAY":
					WebAction.clickUsingJs(tuesdayCheckBox);
					break;
				case "WEDNESDAY":
					WebAction.clickUsingJs(wednesdayCheckBox);
					break;
				case "THURSDAY":
					WebAction.clickUsingJs(thursdayCheckBox);
					break;
				case "FRIDAY":
					WebAction.clickUsingJs(fridayCheckBox);
					break;
				case "SATURDAY":
					WebAction.clickUsingJs(saturdayCheckBox);
					break;
				}

				AdminConstants.setScheduleStartTime(startTime);
				WebAction.click(startTimeTextBox.get(i));
				WebAction.sendKeys(startTimeTextBox.get(i), startTime);
				WebAction.keyPress(startTimeTextBox.get(i), "ENTER");

				AdminConstants.setScheduleEndTime(endTime);
				WebAction.click(startTimeTextBox.get(i));
				WebAction.sendKeys(endTimeTextBox.get(i), endTime);
				WebAction.keyPress(endTimeTextBox.get(i), "ENTER");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify schedule is updated
	 * 
	 * @param days
	 * @param startTime
	 * @param endTime
	 * @throws Exception
	 */
	public void verifyScheduleUpdatedForShow() throws Exception {
		try {
			Waits.waitForElement(secheduleOrSpecialCalendar.get(0), WAIT_CONDITIONS.CLICKABLE);
			Thread.sleep(2000);
			clickScheduleOrSpecials("schedule");
			Waits.waitForElement(saveButton, WAIT_CONDITIONS.CLICKABLE);

			// verify days
			String days = AdminConstants.getScheduleDays();
			String[] daysArr = days.split(",");
			for (int i = 0; i < daysArr.length; i++) {
				switch (daysArr[i].trim().toUpperCase()) {
				case "SUNDAY":
					Assert.assertTrue(WebAction.isSelected(sundayCheckBox), "Schedule is placed for Sunday");
					break;
				case "MONDAY":
					Assert.assertTrue(WebAction.isSelected(mondayCheckBox), "Schedule is placed for Monday");
					break;
				case "TUESDAY":
					Assert.assertTrue(WebAction.isSelected(tuesdayCheckBox), "Schedule is placed for Tuesday");
					break;
				case "WEDNESDAY":
					Assert.assertTrue(WebAction.isSelected(wednesdayCheckBox), "Schedule is placed for Wednesday");
					break;
				case "THURSDAY":
					Assert.assertTrue(WebAction.isSelected(thursdayCheckBox), "Schedule is placed for Thursday");
					break;
				case "FRIDAY":
					Assert.assertTrue(WebAction.isSelected(fridayCheckBox), "Schedule is placed for Friday");
					break;
				case "SATURDAY":
					Assert.assertTrue(WebAction.isSelected(saturdayCheckBox), "Schedule is placed for Saturday");
					break;
				}

				// verify start time
				String scheduleStartTime = DateFunctions
						.convertDateStringToAnotherFormat(AdminConstants.getScheduleStartTime(), "hh:mma", "h:mma")
						.toLowerCase();
				CommonValidations.verifyAttributeValue(startTimeTextBox.get(i), "value", scheduleStartTime,
						"Start time is not correct for day '" + daysArr[i].trim() + "'");

				// verify end time
				String scheduleEndTime = DateFunctions
						.convertDateStringToAnotherFormat(AdminConstants.getScheduleEndTime(), "hh:mma", "h:mma")
						.toLowerCase();
				CommonValidations.verifyAttributeValue(endTimeTextBox.get(i), "value", scheduleEndTime,
						"End time is not correct for day '" + daysArr[i].trim() + "'");

			}
			clickButton("CANCEL", "SHOW");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify confirm deletion popup is displayed
	 * 
	 * @param deletePopUpContent - delete pop up content
	 * @throws Exception1
	 */
	public void verifyDeleteConfirmationPopUpDisplayed(String deletePopUpContent) throws Exception {
		try {
			Waits.waitForElement(confirmPopUpTitle, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(confirmPopUpTitle, "Deletion Confirmation",
					"Deletion confirmation popup is not displayed");
			CommonValidations.verifyTextValue(confirmPopUpContent, deletePopUpContent,
					"Deletion confirmation popup content is not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify show is deleted in admin page
	 * 
	 * @throws Exception
	 */
	public void verifyShowIsDeleted() throws Exception {
		try {
			Waits.waitForElement(noDataInTable, WAIT_CONDITIONS.VISIBLE);
			WebAction.click(clearSearchTextBox);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify division is present in the table
	 * 
	 * @throws Exception
	 */
	public void verifyDivisionPresentInTable() throws Exception {
		boolean divisionCheck = false;
		try {
			Thread.sleep(4000);
			Waits.waitForElement(editLink.get(0), WAIT_CONDITIONS.CLICKABLE);
			for (WebElement element : tableRows) {
				if (element.isDisplayed()) {
					if (WebAction.getText(element.findElement(By.xpath("td[1]")))
							.equalsIgnoreCase(AdminConstants.getDivision())) {
						divisionCheck = true;
						break;
					}
				}
			}
			Assert.assertTrue(divisionCheck,
					"Division " + AdminConstants.getDivision() + " is not present in the table");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click edit link of division
	 * 
	 * @throws Exception
	 */
	public void clickEditOrClickLinkOfDivision(String linkName, String division) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			if (linkName.equalsIgnoreCase("EDIT")) {
				WebElement editAlertElement = driver
						.findElement(By.xpath(editAlertXpath.replace("<<Division>>", division)));
				WebAction.click(editAlertElement);
			} else if (linkName.equalsIgnoreCase("CLEAR")) {
				WebElement clearAlertElement = driver
						.findElement(By.xpath(clearAlertXpath.replace("<<Division>>", division)));
				WebAction.click(clearAlertElement);
			} else
				Assert.assertTrue(false, "Please provide valid link name");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify alert popup is displayed
	 * 
	 * @throws Exception
	 */
	public void verifyAlertPopUpDisplayed() throws Exception {
		try {
			Waits.waitForElement(alertEmailTextBox, WAIT_CONDITIONS.CLICKABLE);
			CommonValidations.verifyTextValue(alertPopUpHeader, "Alerts", "Alert popup is not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill alert details for division
	 * 
	 * @param timeInterval   - time interval
	 * @param alertEmailList - alert email list
	 * @throws Exception
	 */
	public void fillAlertDetails(String timeInterval, String alertEmailList) throws Exception {
		try {
			Assert.assertFalse(WebAction.isEnabled(divisionNameTextBox),
					"Division text box is editable in alert edit popup");
			String division = AdminConstants.getDivision();
			CommonValidations.verifyAttributeValue(divisionNameTextBox, "value", division,
					"Division '" + division + "' is not deflected in alert popup");

			// Fill time interval
			AdminConstants.setAlertTimeInterval(timeInterval);
			WebAction.mouseOver(timeIntervalDropDown);
			Thread.sleep(1000);
			WebAction.clickUsingJs(clearTimeInterval);
			WebAction.selectDropDown(timeIntervalDropDown, timeInterval, dropDownvaluesXpath, dropDownvalues,
					"'" + timeInterval + "' value is not present in the time interval drop down");

			// Fill alert emails
			AdminConstants.setAlertEmailList(alertEmailList);
			WebAction.clearUsingKeys(alertEmailTextBox);
			WebAction.sendKeys(alertEmailTextBox, alertEmailList);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify alert is updated for division
	 * 
	 * @throws Exception
	 */
	public void verifyAlertUpdatedForDivision(String division) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {

			Waits.waitUntilTextValueChanges(
					driver.findElement(By.xpath(timeIntervalXpath.replace("<<Division>>", division))),
					AdminConstants.getAlertTimeInterval());
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify default users data table is Pending users
	 */
	public void verifyPendingUsers() {
		try {
			String tableTitle = WebAction.getText(tableName).trim();
			if (tableTitle.equalsIgnoreCase("pending users")) {
				Assert.assertTrue(true, "Pending Users default table is loaded in users tab");
			} else
				Assert.assertFalse(false, "Failed to load pending users default table in users tab");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To search for specific registered users by using the SSO details
	 */
	public void toEnterRegisteredUserSSO() throws Exception {
		try {
			boolean value = WebAction.isDisplayed(searchField);
			if (value) {
				System.out.println("Division column filter icon is displayed");
				WebAction.click(filterIcon);
				WebAction.clickUsingJs(selectALLCheckBox);
				Thread.sleep(1000);
				WebAction.click(searchField);
				WebAction.sendKeys(searchField, ConfigFileReader.getProperty("username"));
				WebAction.keyPress(searchField, "enter");
				Thread.sleep(1000);
			} else {
				System.out.println("Failed to display filter icon in division column");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify the registered sso data in pending user table results
	 */

	public void verifySSODetails() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			WebElement verifyColumn = driver.findElement(
					By.xpath(ssoDetailsXpath.replace("<<SSO Number>>", ConfigFileReader.getProperty("username"))));
			String verifySSOName = WebAction.getText(verifyColumn);

			if (verifySSOName.equals(ConfigFileReader.getProperty("username"))) {
				System.out.println(
						"Verified that search results displayed the registered user details in pending user data table");
			} else
				System.out.println("Failed to displayed the registered SSO details in the pending users data table");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To approve the registered SSO user details from pending users table as System
	 * Admin
	 */
	public void clickApproveBtn() throws Exception {
		try {
			boolean value = WebAction.isDisplayed(approveBtn);
			if (value) {
				WebAction.click(approveBtn);
				System.out.println("System Admin approved the newly registered SSO from pending users table");
				if (WebAction.isEnabled(disableBtn)) {
					System.out
							.println("Registered SSO details moved to Manage Users table from the Pending users table");
				}
			} else
				System.out.println("Failed to apppove the newly registered users SSO from pending users table ");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify car services are present
	 * 
	 * @throws Exception
	 */
	public void verifyCarServicesPresentInTable() throws Exception {
		boolean carServicesCheck = false;
		try {
			Thread.sleep(4000);
			Waits.waitForElement(editLink.get(0), WAIT_CONDITIONS.CLICKABLE);
			for (WebElement element : tableRows) {
				if (element.isDisplayed()) {
					if (WebAction.getText(element.findElement(By.xpath("td[1]")))
							.equalsIgnoreCase(AdminConstants.getCarServicesName())) {
						carServicesCheck = true;
						break;
					}
				}
			}
			Assert.assertTrue(carServicesCheck,
					"Car services " + AdminConstants.getCarServicesName() + " is not present in the table");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify car services pop up is displayed
	 * 
	 * @throws Exception
	 */
	public void verifyCarServicesPopUpDisplayed() throws Exception {
		try {
			Waits.waitForElement(carServicesNameTextBox, WAIT_CONDITIONS.CLICKABLE);
			CommonValidations.verifyTextValue(alertPopUpHeader, "Car Services", "Car services popup is not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Fill car service detail
	 * 
	 * @param carServiceName
	 * @param phoneNumber
	 * @param country
	 * @param address
	 * @param city
	 * @param state
	 * @param zipCode
	 * @throws Exception
	 */
	public void fillCarServicesDetails(String carServiceName, String phoneNumber, String country, String address,
			String city, String state, String zipCode) throws Exception {
		try {
			// car service name
			WebAction.sendKeys(carServicesNameTextBox, carServiceName);
			AdminConstants.setCarServicesName(carServiceName);

			// phone number
			if (phoneNumber != null) {
				WebAction.sendKeys(carServicesPhoneTextBox, phoneNumber);
				AdminConstants.setCarServicesPhoneNumber(phoneNumber);
			}

			// Country
			if (country != null) {
				WebAction.selectDropDown(carServicesCountryDropDown, country, dropDownvaluesXpath, dropDownvalues,
						"'" + country + "' value is not present in the country drop down");
				AdminConstants.setCarServicesCountry(country);
			}

			// Address
			if (carServicesAddress1TextBox != null) {
				WebAction.sendKeys(carServicesAddress1TextBox, address);
				AdminConstants.setCarServicesAddressLine1(address);
			}

			// City
			if (city != null) {
				WebAction.sendKeys(carServicesCityTextBox, city);
				AdminConstants.setCarServicesCity(city);
			}

			// State
			if (state != null) {
				WebAction.selectDropDown(carServicesStateDropDown, state, dropDownvaluesXpath, dropDownvalues,
						"'" + state + "' value is not present in the state drop down");
				AdminConstants.setCarServicesState(state);
			}

			// zip code
			if (zipCode != null) {
				WebAction.sendKeys(carServicesZipTextBox, zipCode);
				AdminConstants.setCarServicesZipCode(zipCode);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}

package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import nbcu.automation.ui.pages.gtreplatform.CalloutViewPage;

public class CallOutViewPageSteps {

	CalloutViewPage callOutViewPage = new CalloutViewPage();

	@Then("verify call out view is displayed")
	public void verifyCallOutViewPageDisplayed() throws Exception {
		callOutViewPage.verifyCallOutViewPageLoaded();
	}

	@And("verify {string} and {string} buttons are displayed in the header of call out view page")
	public void verifyEditAndBookButtonsDisplayed(String button1, String button2) throws Exception {
		callOutViewPage.verifyEditAndBookButtonDisplayedInHeader();
	}

	@And("verify guest profile {string} is displayed in the header of call out view page")
	public void verifyEditAndBookButtonsDisplayed(String fieldName) throws Exception {
		callOutViewPage.verifyGuestProfileDetailsInHeader(fieldName);
	}

	@And("verify {string} details in call out view page")
	public void verifyCallOutDetails(String sectionName) throws Exception {
		if (sectionName.equalsIgnoreCase("SHOW"))
			callOutViewPage.verifyShowDetails();
		else if (sectionName.equalsIgnoreCase("SEGMENTS"))
			callOutViewPage.verifySegmentDetails();
		else if (sectionName.equalsIgnoreCase("CALL OUT"))
			callOutViewPage.verifyCallOutDetails();
	}

	@And("user clicks {string} button in header of call out view page")
	public void clickButtonInHeader(String buttonName) throws Exception {
		callOutViewPage.clickButtonInHeader(buttonName);
	}
}

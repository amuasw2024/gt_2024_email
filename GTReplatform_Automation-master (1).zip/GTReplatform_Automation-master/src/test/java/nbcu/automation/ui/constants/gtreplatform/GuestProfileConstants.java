package nbcu.automation.ui.constants.gtreplatform;

import java.util.HashMap;

public class GuestProfileConstants {

	private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	// Guest Profile Display Name
	public static void setDisplayName(String displayName) {
		constantMap.get().put("DisplayName", displayName);
	}

	public static String getDisplayName() {
		return (String) constantMap.get().get("DisplayName");
	}

	// Guest Profile Pronunciation
	public static void setPronunciation(String pronunciation) {
		constantMap.get().put("Pronunciation", pronunciation);
	}

	public static String getPronunciation() {
		return (String) constantMap.get().get("Pronunciation");
	}

	// Guest Profile Full Name
	public static void setFullName(String fullName) {
		constantMap.get().put("Full Name", fullName);
	}

	public static String getFullName() {
		return (String) constantMap.get().get("Full Name");
	}

	// Guest Profile Full Name without title and suffix
	public static void setFullNameWithoutTitleAndSuffix(String fullName) {
		constantMap.get().put("Full Name without title", fullName);
	}

	public static String getFullNameWithoutTitleAndSuffix() {
		return (String) constantMap.get().get("Full Name without title");
	}

	// Guest Profile Biography
	public static void setBiography(String biography) {
		constantMap.get().put("Biography", biography);
	}

	public static String getBiography() {
		return (String) constantMap.get().get("Biography");
	}

	// Guest Profile Self Identifying
	public static void setSelfIdentifying(String selfIdentifying) {
		constantMap.get().put("Self Identifying", selfIdentifying);
	}

	public static String getSelfIdentifying() {
		return (String) constantMap.get().get("Self Identifying");
	}

	// Guest Profile Gender
	public static void setGender(String gender) {
		constantMap.get().put("Gender", gender);
	}

	public static String getGender() {
		return (String) constantMap.get().get("Gender");
	}

	// Guest Profile Ethnicity
	public static void setEthnicity(String ethnicity) {
		constantMap.get().put("Ethnicity", ethnicity);
	}

	public static String getEthnicity() {
		return (String) constantMap.get().get("Ethnicity");
	}

	// Guest Profile Other
	public static void setOther(String other) {
		constantMap.get().put("Other", other);
	}

	public static String getOther() {
		return (String) constantMap.get().get("Other");
	}

	// Guest Profile Languages
	public static void setLanguages(String languages) {
		constantMap.get().put("Languages", languages);
	}

	public static String getLanguages() {
		return (String) constantMap.get().get("Languages");
	}

	// Guest Profile Ticker
	public static void setTicker(String ticker) {
		constantMap.get().put("Ticker", ticker);
	}

	public static String getTicker() {
		return (String) constantMap.get().get("Ticker");
	}

	// Guest Profile Expertise
	public static void setExpertise(int number, String expertise) {
		constantMap.get().put("Expertise_" + number, expertise);
	}

	public static String getExpertise(int number) {
		return (String) constantMap.get().get("Expertise_" + number);
	}

	// Guest Profile Expertise count
	public static void setExpertiseCount(int expertiseCount) {
		constantMap.get().put("Expertise Count", expertiseCount);
	}

	public static int getExpertiseCount() {
		return (int) constantMap.get().get("Expertise Count");
	}

	// Guest Profile Primary Job Title
	public static void setPrimaryJobTitle(String primaryJobTitle) {
		constantMap.get().put("Primary Job Title", primaryJobTitle);
	}

	public static String getPrimaryJobTitle() {
		return (String) constantMap.get().get("Primary Job Title");
	}

	// Guest Profile Primary company
	public static void setPrimaryCompany(String primaryCompany) {
		constantMap.get().put("Primary Company", primaryCompany);
	}

	public static String getPrimaryCompany() {
		return (String) constantMap.get().get("Primary Company");
	}

	// Guest Profile Primary contributor
	public static void setContributors(String contributor) {
		constantMap.get().put("Contributor", contributor);
	}

	public static String getContributors() {
		return (String) constantMap.get().get("Contributor");
	}

	// Guest Profile Alert
	public static void setAlert(String alert) {
		constantMap.get().put("Alert", alert);
	}

	public static String getAlert() {
		return (String) constantMap.get().get("Alert");
	}

	// Guest profile office phone number
	public static void setOfficePhoneNumber(String officePhoneNumber) {
		constantMap.get().put("Office Phone Number", officePhoneNumber);
	}

	public static String getOfficePhoneNumber() {
		return (String) constantMap.get().get("Office Phone Number");
	}

	// Guest profile mobile phone number
	public static void setMobilePhoneNumber(String mobilePhoneNumber) {
		constantMap.get().put("Mobile Phone Number", mobilePhoneNumber);
	}

	public static String getMobilePhoneNumber() {
		return (String) constantMap.get().get("Mobile Phone Number");
	}

	// Guest profile phone1 phone number
	public static void setPhone1(String phone1) {
		constantMap.get().put("1-Phone", phone1);
	}

	public static String getPhone1() {
		return (String) constantMap.get().get("1-Phone");
	}

	// Guest profile phone2 phone number
	public static void setPhone2(String phone2) {
		constantMap.get().put("2-Phone", phone2);
	}

	public static String getPhone2() {
		return (String) constantMap.get().get("2-Phone");
	}

	// Guest profile primary phone
	public static void setPrimaryPhone(String primaryPhone) {
		constantMap.get().put("Primary Phone", primaryPhone);
	}

	public static String getPrimaryPhone() {
		return (String) constantMap.get().get("Primary Phone");
	}

	// Guest profile email address
	public static void setEmailAddress(int number, String emailAddress) {
		constantMap.get().put("Email_" + number, emailAddress);
	}

	public static String getEmailAddress(int number) {
		return (String) constantMap.get().get("Email_" + number);
	}

	// Guest profile primary email
	public static void setPrimaryEmail(String primaryEmail) {
		constantMap.get().put("Primary Email", primaryEmail);
	}

	public static String getPrimaryEmail() {
		return (String) constantMap.get().get("Primary Email");
	}

	// Guest profile twitter link
	public static void setTwitterLink(String twitterLink) {
		constantMap.get().put("Twitter Link", twitterLink);
	}

	public static String getTwitterLink() {
		return (String) constantMap.get().get("Twitter Link");
	}

	// Guest profile linked in link
	public static void setLinkedInLink(String linkedInLink) {
		constantMap.get().put("LinkedIn Link", linkedInLink);
	}

	public static String getLinkedInLink() {
		return (String) constantMap.get().get("LinkedIn Link");
	}

	// Guest profile video link
	public static void setVideoLink(String videoLink) {
		constantMap.get().put("Video Link", videoLink);
	}

	public static String getVideoLink() {
		return (String) constantMap.get().get("Video Link");
	}

	// Guest profile web site link
	public static void setWebSiteLink(String webSiteLink) {
		constantMap.get().put("Web Site Link", webSiteLink);
	}

	public static String getWebSiteLink() {
		return (String) constantMap.get().get("Web Site Link");
	}

	// Guest profile primary other
	public static void setPrimaryOther(String primaryOther) {
		constantMap.get().put("Primary Other", primaryOther);
	}

	public static String getPrimaryOther() {
		return (String) constantMap.get().get("Primary Other");
	}

	// Guest profile address line 1
	public static void setAddressLine1(String addressLine1) {
		constantMap.get().put("Address Line1", addressLine1);
	}

	public static String getAddressLine1() {
		return (String) constantMap.get().get("Address Line1");
	}

	// Guest profile address line 2
	public static void setAddressLine2(String addressLine2) {
		constantMap.get().put("Address Line2", addressLine2);
	}

	public static String getAddressLine2() {
		return (String) constantMap.get().get("Address Line2");
	}

	// Guest profile city
	public static void setCity(String city) {
		constantMap.get().put("City", city);
	}

	public static String getCity() {
		return (String) constantMap.get().get("City");
	}

	// Guest profile state
	public static void setState(String state) {
		constantMap.get().put("State", state);
	}

	public static String getState() {
		return (String) constantMap.get().get("State");
	}

	// Guest profile country
	public static void setCountry(String country) {
		constantMap.get().put("Country", country);
	}

	public static String getCountry() {
		return (String) constantMap.get().get("Country");
	}

	// Guest profile zip code
	public static void setZipCode(String zipCode) {
		constantMap.get().put("Zip Code", zipCode);
	}

	public static String getZipCode() {
		return (String) constantMap.get().get("Zip Code");
	}

	// Guest profile job count
	public static void setGuestJobCount(int count) {
		constantMap.get().put("Job Count", count);
	}

	public static int getGuestJobCount() {
		return (int) constantMap.get().get("Job Count");
	}

	// Guest profile job title
	public static void setGuestJobTitle(int number, String jobTitle) {
		constantMap.get().put("Job Title_" + number, jobTitle);
	}

	public static String getGuestJobTitle(int number) {
		return (String) constantMap.get().get("Job Title_" + number);
	}

	// Guest profile job status
	public static void setGuestJobStatus(int number, String jobStatus) {
		constantMap.get().put("Job Status_" + number, jobStatus);
	}

	public static String getGuestJobStatus(int number) {
		return (String) constantMap.get().get("Job Status_" + number);
	}

	// Guest profile job status
	public static void setPrimaryJob(int number, String primaryJob) {
		constantMap.get().put("Primary Job_" + number, primaryJob);
	}

	public static String getPrimaryJob(int number) {
		return (String) constantMap.get().get("Primary Job_" + number);
	}

	// Guest profile job start date
	public static void setGuestJobStartDate(int number, String jobStartDate) {
		constantMap.get().put("Job Start Date_" + number, jobStartDate);
	}

	public static String getGuestJobStartDate(int number) {
		return (String) constantMap.get().get("Job Start Date_" + number);
	}

	// Guest profile job category
	public static void setGuestJobCategory(int number, String jobCategory) {
		constantMap.get().put("Job Category_" + number, jobCategory);
	}

	public static String getGuestJobCategory(int number) {
		return (String) constantMap.get().get("Job Category_" + number);
	}

	// Guest profile job company
	public static void setGuestJobCompany(int number, String jobCompany) {
		constantMap.get().put("Job Company_" + number, jobCompany);
	}

	public static String getGuestJobCompany(int number) {
		return (String) constantMap.get().get("Job Company_" + number);
	}

	// Guest profile job department
	public static void setGuestJobDepartment(int number, String jobDepartment) {
		constantMap.get().put("Job Department_" + number, jobDepartment);
	}

	public static String getGuestJobDepartment(int number) {
		return (String) constantMap.get().get("Job Department_" + number);
	}

	// Guest profile job notes
	public static void setGuestJobNotes(int number, String jobNotes) {
		constantMap.get().put("Job Notes_" + number, jobNotes);
	}

	public static String getGuestJobNotes(int number) {
		return (String) constantMap.get().get("Job Notes_" + number);
	}
}

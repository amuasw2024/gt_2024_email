package nbcu.automation.ui.constants.gtreplatform;

import java.util.HashMap;

public class CompanyProfileConstants {

	private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	// To get CompanyType
	public static String getCompanyType() {
		return (String) constantMap.get().get("Company Type");
	}

	// To set CompanyType
	public static void setCompanyType(String companyType) {
		constantMap.get().put("Company Type", companyType);
	}

	// To get CompanyName
	public static String getCompanyName() {
		return (String) constantMap.get().get("Company Name");
	}

	// To set CompanyName
	public static void setCompanyName(String companyName) {
		constantMap.get().put("Company Name", companyName);
	}

	// To get CompanyTicker
	public static String getCompanyTicker() {
		return (String) constantMap.get().get("Company Ticker");
	}

	// To set CompanyTicker
	public static void setCompanyTicker(String companyTicker) {
		constantMap.get().put("Company Ticker", companyTicker);
	}

	// To get CompanyExpertise
	public static String getCompanyExpertise() {
		return (String) constantMap.get().get("Company Expertise");
	}

	// To set CompanyExpertise
	public static void setCompanyExpertise(String companyExpertise) {
		constantMap.get().put("Company Expertise", companyExpertise);
	}

	// To get CompanyBiography
	public static String getCompanyBiography() {
		return (String) constantMap.get().get("Company Biography");
	}

	// To set CompanyBiography
	public static void setCompanyBiography(String companyBiography) {
		constantMap.get().put("Company Biography", companyBiography);
	}

	// To get CompanyAlerts
	public static String getCompanyAlerts() {
		return (String) constantMap.get().get("Company Alerts");
	}

	// To set CompanyAlerts
	public static void setCompanyAlerts(String companyAlerts) {
		constantMap.get().put("Company Alerts", companyAlerts);
	}

	// To get CompanyPhone0
	public static String getCompanyPhone0() {
		return (String) constantMap.get().get("Company PhoneNo0");
	}

	// To set CompanyPhone0
	public static void setCompanyPhone0(String companyPhoneNo0) {
		constantMap.get().put("Company PhoneNo0", companyPhoneNo0);
	}

	// To get CompanyPhone1
	public static String getCompanyPhone1() {
		return (String) constantMap.get().get("Company PhoneNo1");
	}

	// To set CompanyPhone1
	public static void setCompanyPhone1(String companyPhoneNo1) {
		constantMap.get().put("Company PhoneNo1", companyPhoneNo1);
	}

	// To get CompanyPhone2
	public static String getCompanyPhone2() {
		return (String) constantMap.get().get("Company PhoneNo2");
	}

	// To set CompanyPhone2
	public static void setCompanyPhone2(String companyPhoneNo2) {
		constantMap.get().put("Company PhoneNo2", companyPhoneNo2);
	}

	// To get CompanyPhone3
	public static String getCompanyPhone3() {
		return (String) constantMap.get().get("Company PhoneNo3");
	}

	// To set CompanyPhone3
	public static void setCompanyPhone3(String companyPhoneNo3) {
		constantMap.get().put("Company PhoneNo3", companyPhoneNo3);
	}

	// To get CompanyEmail0
	public static String getCompanyEmail0() {
		return (String) constantMap.get().get("Company Email0");
	}

	// To set CompanyEmail0
	public static void setCompanyEmail0(String companyEmail0) {
		constantMap.get().put("Company Email0", companyEmail0);
	}

	// To get CompanyEmail1
	public static String getCompanyEmail1() {
		return (String) constantMap.get().get("Company Email1");
	}

	// To set CompanyEmail1
	public static void setCompanyEmail1(String companyEmail1) {
		constantMap.get().put("Company Email1", companyEmail1);
	}

	// To get CompanyEmail2
	public static String getCompanyEmail2() {
		return (String) constantMap.get().get("Company Email2");
	}

	// To set CompanyEmail2
	public static void setCompanyEmail2(String companyEmail2) {
		constantMap.get().put("Company Email2", companyEmail2);
	}

	// To get CompanyEmail3
	public static String getCompanyEmail3() {
		return (String) constantMap.get().get("Company Email3");
	}

	// To set CompanyEmail3
	public static void setCompanyEmail3(String companyEmail3) {
		constantMap.get().put("Company Email3", companyEmail3);
	}

	// To get CompanyTwitter
	public static String getCompanyTwitter() {
		return (String) constantMap.get().get("Company Twitter");
	}

	// To set CompanyTwitter
	public static void setCompanyTwitter(String companyTwitter) {
		constantMap.get().put("Company Twitter", companyTwitter);
	}

	// To get CompanyTwitter
	public static String getCompanyLinkedIn() {
		return (String) constantMap.get().get("Company LinkedIn");
	}

	// To set CompanyTwitter
	public static void setCompanyLinkedIn(String companyLinkedIn) {
		constantMap.get().put("Company LinkedIn", companyLinkedIn);
	}

	// To get CompanyTwitter
	public static String getCompanyVideo() {
		return (String) constantMap.get().get("Company Video");
	}

	// To set CompanyTwitter
	public static void setCompanyVideo(String companyVideo) {
		constantMap.get().put("Company Video", companyVideo);
	}

	// To get CompanyTwitter
	public static String getCompanyWebsite() {
		return (String) constantMap.get().get("Company Website");
	}

	// To set CompanyTwitter
	public static void setCompanyWebsite(String companyWebsite) {
		constantMap.get().put("Company Website", companyWebsite);
	}

	public static String getCompanyAddressField1() {
		return (String) constantMap.get().get("Company AdField1");
	}

	// To set CompanyTwitter
	public static void setAddressField1(String companyAdField1) {
		constantMap.get().put("Company AdField1", companyAdField1);
	}

	public static String getCompanyAddressField2() {
		return (String) constantMap.get().get("Company AdField2");
	}

	// To set CompanyTwitter
	public static void setAddressField2(String companyAdField2) {
		constantMap.get().put("Company AdField2", companyAdField2);
	}

	public static String getCompanyCity() {
		return (String) constantMap.get().get("Company City");
	}

	public static void setAddressCityField(String companyCity) {
		constantMap.get().put("Company City", companyCity);
	}

	public static String getCompanyState() {
		return (String) constantMap.get().get("Company State");
	}

	public static void setAddressStateField(String companyState) {
		constantMap.get().put("Company State", companyState);
	}

	public static String getCompanyZip() {
		return (String) constantMap.get().get("Company Zip");
	}

	public static void setAddressZipField(String companyZip) {
		constantMap.get().put("Company Zip", companyZip);
	}

	public static String getCompanyCountry() {
		return (String) constantMap.get().get("Company Country");
	}

	public static void setAddressCountryField(String companyCountry) {
		constantMap.get().put("Company Country", companyCountry);
	}

	
	
	
}

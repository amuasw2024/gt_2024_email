package nbcu.automation.ui.pages.gtreplatform;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.gtreplatform.CompanyProfileConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.CommonUtils;

public class CompanyProfilePage {

	@FindBy(xpath = "//h2[contains(text(),'Company')]")
	WebElement companyProfileHeader;

	@FindBy(xpath = "//input[@value='parent']")
	WebElement parentCompanyCheckBox;

	@FindBy(xpath = "//input[@value='subsidiary']")
	WebElement subsidiaryCompanyCheckBox;

	@FindBy(xpath = "//span[contains(@class,'ant-radio ant-radio-checked')]")
	WebElement selectedRadioCompany;

	@FindBy(xpath = "//*[@placeholder='Enter the parent company name']")
	WebElement companyNameTextBox;

	@FindBy(xpath = "//input[@id='CompanyInfo_ticker']")
	WebElement companyTickerTextBox;

	@FindBy(xpath = "//span[text()='Select Expertise(s)']")
	WebElement expertiseDropdown;

	@FindBy(xpath = "//span[text()='Select Expertise(s)']/preceding-sibling::span/input")
	WebElement expertiseInputBox;

	@FindBy(xpath = "//ul[@class='styles__list__l7x6j']/li")
	WebElement parkingLots;

	@FindBy(xpath = "//span[text()='Biography']")
	WebElement biographyTitle;

	@FindBy(id = "CompanyInfo_biography")
	WebElement biographyTextArea;

	// Phone - Contact Info section
	@FindBy(xpath = "//label[text()='1 - Phone']")
	WebElement phoneLabelText;

	@FindBy(id = "Contact_Phone_0_phone")
	WebElement phoneNo0;

	@FindBy(id = "Contact_Phone_1_phone")
	WebElement phoneNo1;

	@FindBy(id = "Contact_Phone_2_phone")
	WebElement phoneNo2;

	@FindBy(id = "Contact_Phone_3_phone")
	WebElement phoneNo3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Phone_')]/following-sibling::span/button")
	List<WebElement> phoneFavoriteButtons;

	// Email - Contact Info section
	@FindBy(id = "Contact_Email_0_email")
	WebElement email0;

	@FindBy(id = "Contact_Email_1_email")
	WebElement email1;

	@FindBy(id = "Contact_Email_2_email")
	WebElement email2;

	@FindBy(id = "Contact_Email_3_email")
	WebElement email3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Email_')]/following-sibling::span/button")
	List<WebElement> emailFavoriteButtons;

	// Other - Contact Info section
	@FindBy(id = "Contact_Social_0_link")
	WebElement other0;

	@FindBy(id = "Contact_Social_1_link")
	WebElement otherfield1;

	@FindBy(id = "Contact_Misc_0_link")
	WebElement otherfield2;

	@FindBy(id = "Contact_Misc_1_link")
	WebElement otherfield3;

	@FindBy(xpath = "//*[contains(@id,'Contact_Social_') or contains(@id,'Contact_Misc_')]/following-sibling::span/button")
	List<WebElement> othersFavoriteButtons;

	// Address - Contact Info section
	@FindBy(xpath = "//label[text()='Address - 1']")
	WebElement addressLabel;

	@FindBy(id = "Contact_Address_0_address1")
	WebElement addressLine1;

	@FindBy(id = "Contact_Address_0_address2")
	WebElement addressLine2;

	@FindBy(id = "Contact_Address_0_city")
	WebElement addressCity;

	@FindBy(id = "Contact_Address_0_state")
	WebElement addressState;

	String dropDownValuesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownValues;

	@FindBy(id = "Contact_Address_0_zip")
	WebElement addressZip;

	@FindBy(id = "Contact_Address_0_country")
	WebElement addressCountry;

	// Alerts - Contact Info section
	@FindBy(id = "Alerts_notes")
	WebElement alertsDetails;

	// CreateButton -
	@FindBy(xpath = "//span[text()='Create']")
	WebElement createCompanyButton;

	String dropdropDownvaluesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropdropDownvalues;

	@FindBy(xpath = "(//span[@class='ant-select-arrow'])[1]")
	WebElement expertise;

	@FindBy(xpath = "//button[@type='button']/span[text()='Cancel']")
	WebElement cancelButton;

	@FindBy(xpath = "//*[contains(@class,'header__name')]")
	List<WebElement> companyName;

	@FindBy(xpath = "//*[contains(@class,'header__type')]")
	List<WebElement> profileType;

	@FindBy(xpath = "//*[contains(@class,'header__ticker')]")
	List<WebElement> profileTicker;

	@FindBy(xpath = "//li[span[text()='Edit']]")
	List<WebElement> editButton;

	@FindBy(xpath = "//li[span[text()='History']]")
	List<WebElement> historyButton;

	@FindBy(xpath = "//li[span[text()='Share']]")
	List<WebElement> shareButton;

	@FindBy(xpath = "//li[span[text()='Copy']]")
	List<WebElement> copyButton;

	@FindBy(xpath = "//li[span[text()='Merge']]")
	List<WebElement> mergeButton;

	@FindBy(xpath = "//span[text()='Basic Info']")
	WebElement basicButton;

	@FindBy(xpath = "//span[text()='Background']")
	WebElement backGroundText;

	@FindBy(xpath = "//*[@class='styles__section__ghzmJ']/h3")
	WebElement sectionHeader;

	@FindBy(xpath = "//*[@class='styles__section__ghzmJ']//p")
	WebElement verifyBioValue;

	@FindBy(xpath = "//*[@class='styles__list__l7x6j']/li")
	WebElement verifyExpValue;

	@FindBy(xpath = "//*[@class='styles__section__aeGXf']/p")
	WebElement verifyTickValue;

	@FindBy(xpath = "//*[@class='styles__list__wWs5e']//tbody/tr")
	List<WebElement> generalInfo;

	@FindBy(xpath = "(//*[@class='styles__list__wWs5e']//tbody//td)")
	List<WebElement> tableData;

	@FindBy(xpath = "//div[@class='ant-col']//div[@role='alert']")
	WebElement alertSection;

	@FindBy(xpath = "//div[@role='alert']/span")
	WebElement verifyAlerts;

	// Contact info section - Phone Tab
	@FindBy(xpath = "//div[@class='styles__tabs__Bj89H']/descendant::li/span")
	List<WebElement> verifyTab;

	@FindBy(xpath = "//div[@class='styles__content__lpxOO']//tr")
	List<WebElement> contactInfoTable;

	@FindBy(xpath = "//div[@class='styles__content__lpxOO']//tr//td[2]")
	List<WebElement> contactInfoTableData;

	@FindBy(xpath = "(//span[@aria-label='ellipsis'])[2]")
	WebElement ellipses;

	@FindBy(xpath = "//span[text()='Address']")
	List<WebElement> contactInfoAdrsTab;

	@FindBy(xpath = "(//div[@class='styles__content__lpxOO']//td[1]/div)[1]")
	WebElement addressText;

	@FindBy(xpath = "(//span[text()='Edit'])[2]")
	WebElement editButtonHeader;

	@FindBy(xpath = "(//span[text()='Edit'])[1]")
	WebElement editButtonHeader2;

	@FindBy(xpath = "//span[text()='Deactivate Account']")
	WebElement deactivateAccount;

	@FindBy(xpath = "//span[@class='ant-modal-confirm-title']")
	WebElement popUpHeadMsg;

	@FindBy(xpath = "//button[span[text()='Yes']]")
	WebElement yesBtn;

	@FindBy(xpath = "//button[span[text()='No']]")
	WebElement noBtn;

	@FindBy(xpath = "//span[@class='styles__text__juggt']")
	WebElement profileName;

	@FindBy(xpath = "//span[text()='Reactivate Account']")
	WebElement reactAcntBtn;

	@FindBy(xpath = "//li//span[contains(@class,'anticon anticon-close')]")
	WebElement closeExpertise;

	@FindBy(xpath = "//button[span[text()='Update']]")
	WebElement updateButtonEditPage;

	// Color code test
	@FindBy(xpath = "//*[@class='ant-btn ant-btn-round ant-btn-primary ant-btn-lg']")
	WebElement tabInfoButtons;

	public CompanyProfilePage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify company profile page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyCompanyProfilePageDisplayed() throws Exception {
		Waits.waitForElement(companyProfileHeader, WAIT_CONDITIONS.VISIBLE);
	}

	/**
	 * To verify info button are highlighted in blue color
	 * 
	 * @throws Exception
	 */
	public void headerInfoTab(String color) throws Exception {
		try {
			Waits.waitForElement(tabInfoButtons, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyColorOfElement(tabInfoButtons, "background color", color);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify parent type as "Parent Company"
	 * 
	 * @throws Exception
	 */
	public void verifyCompanyType(String parentType) throws Exception {
		try {
			CompanyProfileConstants.setCompanyType(parentType); // set Method
			boolean aleadyChecked = WebAction.isSelected(parentCompanyCheckBox);
			if (!aleadyChecked)
				throw new Exception("Parent Company is not selected by default");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter the Parent company name
	 * 
	 * @throws Exception
	 */
	public String fillParentCompanyName(String parentCompanyName) throws Exception {
		try {
			int randomNumber = CommonUtils.generateRamdomNumberForGivenRange(1, 1000000000);
			parentCompanyName = parentCompanyName + "_" + randomNumber;
			CompanyProfileConstants.setCompanyName(parentCompanyName); // set Method
			Thread.sleep(1000);
			WebAction.clickUsingJs(companyNameTextBox);
			Thread.sleep(1000);
			WebAction.sendKeys_WithTimeGap(companyNameTextBox, parentCompanyName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return parentCompanyName;
	}

	/**
	 * Enter the Ticker details
	 * 
	 * @throws Exception
	 */
	public void fillTickerDetails(String ticker) throws Exception {
		CompanyProfileConstants.setCompanyTicker(ticker); // set Method
		WebAction.scrollIntoView(companyTickerTextBox);
		try {
			if (ticker != null) {
				WebAction.clear(companyTickerTextBox);
				WebAction.sendKeys(companyTickerTextBox, ticker);
				WebAction.keyPress(companyTickerTextBox, "ENTER");
			}
			WebAction.clickUsingJs(biographyTextArea);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select value from Expertise drop down
	 * 
	 * @throws Exception
	 */
	public void selectExpertise(String expertise) throws Exception {
		try {
			Thread.sleep(1000);
			WebAction.clickUsingJs(expertiseDropdown);
			if (expertise != null) {

				CompanyProfileConstants.setCompanyExpertise(expertise);
				WebAction.selectDropDown(expertiseInputBox, expertise, dropDownValuesXpath, dropDownValues,
						"'" + expertise + "' value is not present in the expertise drop down");
			}
			WebAction.clickUsingJs(biographyTextArea);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter biography in background section
	 * 
	 * @throws Exception
	 */
	public void fillBiogrpahyDetails(String biography) throws Exception {
		try {
			CompanyProfileConstants.setCompanyBiography(biography); // set Method
			if (biography != null) {
				WebAction.clickUsingJs(biographyTextArea);
				WebAction.sendKeys(biographyTextArea, biography);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter Multiple Phone number in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillPhoneNumberDetails(String Phone1, String Phone2, String Phone3, String Phone4) throws Exception {
		try {
			CompanyProfileConstants.setCompanyPhone0(Phone1);
			CompanyProfileConstants.setCompanyPhone1(Phone2);
			CompanyProfileConstants.setCompanyPhone2(Phone3);
			CompanyProfileConstants.setCompanyPhone3(Phone4);
			WebAction.scrollIntoView(phoneLabelText);
			WebAction.sendKeys(phoneNo0, Phone1);
			WebAction.sendKeys(phoneNo1, Phone2);
			WebAction.sendKeys(phoneNo2, Phone3);
			WebAction.sendKeys(phoneNo3, Phone4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Favorite phone-no in Contact info section
	 * 
	 * @throws Exception
	 */
	public void selectFavoritePhone(String phone) throws Exception {
		try {
			WebAction.scrollIntoView(phoneNo0);
			int phoneFavoriteIndex = Integer.parseInt(phone.substring(0, 1)) - 1;
			WebAction.clickUsingJs(phoneFavoriteButtons.get(phoneFavoriteIndex));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter Multiple Email id's in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillEmailDetails(String Email1, String Email2, String Email3, String Email4) throws Exception {
		try {
			CompanyProfileConstants.setCompanyEmail0(Email1);
			CompanyProfileConstants.setCompanyEmail1(Email2);
			CompanyProfileConstants.setCompanyEmail2(Email3);
			CompanyProfileConstants.setCompanyEmail3(Email4);
			WebAction.scrollIntoView(phoneLabelText);
			WebAction.sendKeys(email0, Email1);
			WebAction.sendKeys(email1, Email2);
			WebAction.sendKeys(email2, Email3);
			WebAction.sendKeys(email3, Email4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Favorite email in Contact info section
	 * 
	 * @throws Exception
	 */
	public void selectFavoriteEmail(String email) throws Exception {
		try {
			int emailFavoriteIndex = Integer.parseInt(email.substring(0, 1)) - 1;
			WebAction.scrollIntoView(emailFavoriteButtons.get(emailFavoriteIndex));
			WebAction.clickUsingJs(emailFavoriteButtons.get(emailFavoriteIndex));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter other social links in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillSocialMiscDetails(String other1, String other2, String other3, String other4) throws Exception {
		try {
			CompanyProfileConstants.setCompanyTwitter(other1);
			CompanyProfileConstants.setCompanyLinkedIn(other2);
			CompanyProfileConstants.setCompanyVideo(other3);
			CompanyProfileConstants.setCompanyWebsite(other4);
			WebAction.scrollIntoView(phoneLabelText);
			WebAction.sendKeys(other0, other1);
			WebAction.sendKeys(otherfield1, other2);
			WebAction.sendKeys(otherfield2, other3);
			WebAction.sendKeys(otherfield3, other4);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Favorite social in Contact info section
	 * 
	 * @throws Exception
	 */
	public void selectFavoriteSocialMisc(String other) throws Exception {
		int otherFavoriteIndex = 0;
		try {
			switch (other.toUpperCase()) {
			case "TWITTER":
				otherFavoriteIndex = 0;
				break;
			case "LINKEDIN":
				otherFavoriteIndex = 1;
				break;
			case "VIDEO":
				otherFavoriteIndex = 2;
				break;
			case "WEBSITE":
				otherFavoriteIndex = 3;
				break;
			}
			WebAction.clickUsingJs(othersFavoriteButtons.get(otherFavoriteIndex));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter Address details in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillAddressDetails(String address1, String address2, String city, String state, String zip,
			String country) throws Exception {

		CompanyProfileConstants.setAddressField1(address1);
		CompanyProfileConstants.setAddressField2(address2);
		CompanyProfileConstants.setAddressCityField(city);
		CompanyProfileConstants.setAddressStateField(state);
		CompanyProfileConstants.setAddressZipField(zip);
		CompanyProfileConstants.setAddressCountryField(country);

		try {
			WebAction.scrollIntoView(addressLabel);
			WebAction.sendKeys(addressLine1, address1);
			WebAction.sendKeys(addressLine2, address2);
			WebAction.sendKeys(addressCity, city);
			if (state != null) {
				WebAction.selectDropDown(addressState, state, dropDownValuesXpath, dropDownValues,
						"'" + state + "' value is not present in the drop down");
			}
			WebAction.sendKeys(addressZip, zip);
			if (country != null) {
				WebAction.clickUsingJs(addressCountry);
				WebAction.selectDropDown(addressCountry, country, dropDownValuesXpath, dropDownValues,
						"'" + country + "' value is not present in the drop down");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Enter Alerts in contact info section
	 * 
	 * @throws Exception
	 * 
	 */
	public void fillAlertsDetails(String alertInfo) throws Exception {
		try {
			CompanyProfileConstants.setCompanyAlerts(alertInfo);
			WebAction.sendKeys(alertsDetails, alertInfo);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click Create button once entering all fields
	 * 
	 * @throws Exception
	 */
	public void clickButton(String buttonType) throws Exception {
		try {
			switch (buttonType.toUpperCase()) {
			case "CREATE":
				WebAction.click(createCompanyButton);
				Waits.waitForElementToDisappear(createCompanyButton);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * View Company Profile page displayed
	 * 
	 * @throws Exception
	 */
	public void viewCompanyProfile() throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(editButton, 0);
			Waits.waitForElement(editButton.get(0), WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Parent Company Name in view page
	 * 
	 */
	public void parentCompanyName() {
		String compName = CompanyProfileConstants.getCompanyName();
		try {
			for (WebElement company : companyName) {
				if (company.isDisplayed()) {
					CommonValidations.verifyTextValue(company, compName, "Company name in header is not matching");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify profileType in view page
	 *
	 */
	public void profileTypeOfCompany() {
		try {
			String companyProfileType = CompanyProfileConstants.getCompanyType();
			for (WebElement profile : profileType) {
				if (profile.isDisplayed()) {
					CommonValidations.verifyTextValue(profile, companyProfileType,
							"Company profile type in header is not matching");
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Ticker in view page
	 *
	 * @throws Exception
	 */
	public void companyTicker() throws Exception {
		String tick = CompanyProfileConstants.getCompanyTicker();
		try {
			String[] tickerArray = tick.split(",");
			for (WebElement ticker : profileTicker) {
				if (ticker.isDisplayed()) {
					String ele = WebAction.getText(ticker);
					String[] arrEle = ele.split(" ");
					if (tickerArray.length == arrEle.length) {
						for (int i = 0; i < arrEle.length; i++) {
							tickerArray[i].equalsIgnoreCase(arrEle[i]);

						}
					} else
						throw new Exception("Company ticker not matched in view page");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Header icons in company view page
	 * 
	 * @throws Exception
	 */
	public void headerIcons(String headButton, DataTable params) throws Exception {
		try {
			List<Map<String, String>> headerButtons = CucumberUtils.getValuesFromDataTableAsList(params);
			for (int i = 0; i < headerButtons.size(); i++) {
				String buttonName = headerButtons.get(i).get("HeadButton");
				switch (buttonName.toUpperCase()) {
				case "EDIT":
					Assert.assertTrue(WebAction.isDisplayed(editButton.get(0)),
							"Edit button is missing in company profile header");
					break;
				case "SHARE":
					Assert.assertTrue(WebAction.isDisplayed(shareButton.get(0)),
							"Share button is missing in company profile header");
					break;
				case "COPY":
					Assert.assertTrue(WebAction.isDisplayed(copyButton.get(0)),
							"Copy button is missing in company profile header");
					break;
				case "HISTORY":
					Assert.assertTrue(WebAction.isDisplayed(historyButton.get(0)),
							"History button is missing in company profile header");
					break;
				case "MERGE":
					Assert.assertTrue(WebAction.isDisplayed(mergeButton.get(0)),
							"Merge button is missing in company profile header");
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Basic Info tab is enabled
	 * 
	 * @throws Exception
	 */
	public void defEnabledTab() throws Exception {
		try {
			boolean tabBasic = WebAction.isDisplayed(basicButton);
			if (tabBasic) {
				WebAction.click(basicButton);

			} else {
				throw new Exception("Basic Info button not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Background section is displayed
	 * 
	 * @throws Exception
	 */
	public void backIsDisplayed() throws Exception {
		try {
			String sectionName = WebAction.getText(backGroundText);
			if (sectionName.length() == 0)
				throw new Exception("Background section name not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Biography displayed in background section
	 * 
	 * @throws Exception
	 */
	public void verifyBiography() throws Exception {
		try {
			// String headerText = WebAction.getText(sectionHeader);
			String bio = CompanyProfileConstants.getCompanyBiography();
			String bioText = WebAction.getText(verifyBioValue);
			if (bioText.length() > 0 && (!bioText.equals("NA"))) {
				CommonValidations.verifyTextValue(verifyBioValue, bio, "Company biography is not matching");

			} else if (bioText.equals("NA"))
				;
			else
				throw new Exception("Biography displayed as blank value");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Expertise displayed in background section
	 * 
	 * @throws Exception
	 */
	public void verifyExpertise() throws Exception {
		try {
			// String headerText = WebAction.getText();
			String exp = CompanyProfileConstants.getCompanyExpertise(); // get Method
			String expText = WebAction.getText(verifyExpValue);
			if (expText.length() > 0) {
				CommonValidations.verifyTextValue(verifyExpValue, exp, "Company expertise is not matching");

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Ticker displayed in background section
	 * 
	 * @throws Exception
	 */
	public void verifyTicker() throws Exception {
		try {
			String ticText = WebAction.getText(verifyTickValue);
			if (ticText.length() > 0) {
				String ticArray[] = ticText.split(" ");
				String tic = CompanyProfileConstants.getCompanyTicker(); // get Method
				String feaArray[] = tic.split(",");
				if (ticArray.length == feaArray.length) {
					for (int i = 0; i < ticArray.length; i++) {
						ticArray[i].equalsIgnoreCase(feaArray[i]);

					}
				} else
					throw new Exception("Company ticker not matched in view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify General Info in background section
	 * 
	 * @throws Exception
	 */
	public void verifyType() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String comType = CompanyProfileConstants.getCompanyType(); // get Method
			String value = CompanyProfileConstants.getCompanyName(); // get Method
			List<String> values = new ArrayList<String>();
			int no_of_rows = generalInfo.size();
			Outer: for (int i = 0; i < no_of_rows; i++) {
				int no_of_columns = tableData.size();
				for (int j = 0; j < no_of_columns; j++) {
					String xpath = "(//*[@class='styles__list__wWs5e']//tbody//tr[" + (i + 1) + "]//td)[" + (j + 2)
							+ "]";
					By columnValues = By.xpath(xpath);
					String type = driver.findElement(columnValues).getText();
					values.add(type);
					continue Outer;
				}

			}
			if (values.get(0).equalsIgnoreCase(comType) && values.get(1).equalsIgnoreCase(value)) {
			} else
				throw new Exception("General Info type not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Alerts details from contact info section
	 * 
	 * @throws Exception
	 */
	public void verifyAlerts() throws Exception {
		try {
			boolean alertPlace = WebAction.isDisplayed(alertSection);
			String alertContent = CompanyProfileConstants.getCompanyAlerts(); // get Method
			if (alertPlace) {
				// String text = WebAction.getText(verifyAlerts);
				CommonValidations.verifyTextValue(verifyAlerts, alertContent, "Company alert is not matching");
			} else
				throw new Exception("Alert Section not displayed");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Phone numbers from contact info section
	 * 
	 * @throws Exception
	 */
	public void verifyPhoneNumbers() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String phoneTabDate1 = CompanyProfileConstants.getCompanyPhone0();
		String phoneTabDate2 = CompanyProfileConstants.getCompanyPhone1();
		String phoneTabDate3 = CompanyProfileConstants.getCompanyPhone2();
		String phoneTabDate4 = CompanyProfileConstants.getCompanyPhone3();
		List<String> phoneNumbers = new ArrayList<String>();

		try {
			boolean phoneTab = WebAction.isDisplayed(verifyTab.get(0));
			WebAction.clickUsingJs(verifyTab.get(0));
			if (phoneTab) {
				int tableSize = contactInfoTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = contactInfoTableData.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='styles__content__lpxOO']//tr[" + (i + 1) + "]//td[" + (j + 2)
								+ "]";
						By value = By.xpath(xpath);
						String phone = driver.findElement(value).getText();
						phoneNumbers.add(phone);
						continue Outer;
					}
				}
			}
			if (phoneTabDate1.equalsIgnoreCase(phoneNumbers.get(0))
					&& phoneTabDate2.equalsIgnoreCase(phoneNumbers.get(1))
					&& phoneTabDate3.equalsIgnoreCase(phoneNumbers.get(2))
					&& phoneTabDate4.equalsIgnoreCase(phoneNumbers.get(3)))
				;
			else {
				Assert.assertFalse(false, "Phone numbers not matched in view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Email Address from contact info section
	 * 
	 * @throws Exception
	 */
	public void verifyEmailIds() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String emailTabData1 = CompanyProfileConstants.getCompanyEmail0();
		String emailTabData2 = CompanyProfileConstants.getCompanyEmail1();
		String emailTabData3 = CompanyProfileConstants.getCompanyEmail2();
		String emailTabData4 = CompanyProfileConstants.getCompanyEmail3();

		List<String> noOfEmailIds = new ArrayList<String>();
		try {
			boolean emailTab = WebAction.isDisplayed(verifyTab.get(1));
			WebAction.clickUsingJs(verifyTab.get(1));
			if (emailTab) {
				int tableSize = contactInfoTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = contactInfoTableData.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='styles__content__lpxOO']//tr[" + (i + 1) + "]//td[" + (j + 2)
								+ "]";
						By value = By.xpath(xpath);
						String emailId = driver.findElement(value).getText();
						noOfEmailIds.add(emailId);
						continue Outer;
					}
				}

			}
			if (emailTabData1.equalsIgnoreCase(noOfEmailIds.get(0))
					&& emailTabData2.equalsIgnoreCase(noOfEmailIds.get(1))
					&& emailTabData3.equalsIgnoreCase(noOfEmailIds.get(2))
					&& emailTabData4.equalsIgnoreCase(noOfEmailIds.get(3)))
				;

			else {
				// AllureUtility.captureScreenshot("Email id's not matched in view page");
				Assert.assertTrue(false, "Email id's are not matched in view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Others from contact info section
	 * 
	 * @throws Exception
	 */
	public void verfiyOtherLinks() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String twitterTabData1 = CompanyProfileConstants.getCompanyTwitter();
		String linkedInTabData2 = CompanyProfileConstants.getCompanyLinkedIn();
		String videoTabData3 = CompanyProfileConstants.getCompanyVideo();
		String websiteTabData4 = CompanyProfileConstants.getCompanyWebsite();

		List<String> otherSocialLinks = new ArrayList<String>();
		try {
			boolean othersTab = WebAction.isDisplayed(verifyTab.get(2));
			WebAction.clickUsingJs(verifyTab.get(2));
			if (othersTab) {
				int tableSize = contactInfoTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = contactInfoTableData.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='styles__content__lpxOO']//tr[" + (i + 1) + "]//td[" + (j + 2)
								+ "]";
						By values = By.xpath(xpath);
						String links = driver.findElement(values).getText();
						otherSocialLinks.add(links);
						continue Outer;
					}
				}

			}
			if (videoTabData3.equalsIgnoreCase(otherSocialLinks.get(0))
					&& twitterTabData1.equalsIgnoreCase(otherSocialLinks.get(1))
					&& linkedInTabData2.equalsIgnoreCase(otherSocialLinks.get(2))
					&& websiteTabData4.equalsIgnoreCase(otherSocialLinks.get(3)))
				;
			else {
				// AllureUtility.captureScreenshot("Other Social Links not matched in view
				// page");
				Assert.assertTrue(false, "Other Social Links not matched in view page");

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Ellipses in contact info section
	 * 
	 * @throws Exception
	 */
	public void clickingAddressTab() throws Exception {
		try {
			boolean isElipsePresent = WebAction.isDisplayed(ellipses);
			if (isElipsePresent)
				WebAction.mouseOver(ellipses);
			Thread.sleep(3000);
			for (WebElement element : contactInfoAdrsTab) {
				if (element.isDisplayed()) {
					WebAction.click(element);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Address tab displayed from contact info section
	 * 
	 * @throws Exception
	 */
	public void verifyCompanyAddressDetails() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String addressField1 = CompanyProfileConstants.getCompanyAddressField1();
		String addressField2 = CompanyProfileConstants.getCompanyAddressField2();
		String addressCity = CompanyProfileConstants.getCompanyCity();
		String addressState = CompanyProfileConstants.getCompanyState();
		String addressZip = CompanyProfileConstants.getCompanyZip();
		String addressCountry = CompanyProfileConstants.getCompanyCountry();
		List<String> addressFields = new ArrayList<String>();
		try {
			String addTxt = WebAction.getText(addressText);
			if (addTxt.length() > 0) {
				int tableSize = contactInfoTable.size();
				Outer: for (int i = 0; i < tableSize; i++) {
					int tableDataSize = contactInfoTableData.size();
					for (int j = 0; j < tableDataSize; j++) {
						String xpath = "//div[@class='styles__content__lpxOO']//tr[" + (i + 1) + "]//td[" + (j + 2)
								+ "]";
						By values = By.xpath(xpath);
						String address = driver.findElement(values).getText();
						addressFields.add(address);
						continue Outer;
					}
				}
			}
			if (addressField1.equalsIgnoreCase(addressFields.get(0))
					&& addressField2.equalsIgnoreCase(addressFields.get(1))
					&& addressCity.equalsIgnoreCase(addressFields.get(2))
					&& addressState.equalsIgnoreCase(addressFields.get(3))
					&& addressZip.equalsIgnoreCase(addressFields.get(4))
					&& addressCountry.equalsIgnoreCase(addressFields.get(5)))
				;
			else {
				Assert.assertTrue(false, "Address not matched in view page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Edit button in Header of company view page
	 * 
	 * @throws Exception
	 */
	public void clickEditButton() throws Exception {
		try {
			boolean isPresent = WebAction.isDisplayed(editButtonHeader);
			if (isPresent) {
				Waits.waitForElement(editButtonHeader, WAIT_CONDITIONS.VISIBLE);
				WebAction.click(editButtonHeader);
			} else {
				Waits.waitForElement(editButtonHeader2, WAIT_CONDITIONS.VISIBLE);
				Thread.sleep(5000);
				WebAction.click(editButtonHeader2);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Deactivate account in header of company edit page
	 * 
	 * @throws Exception
	 */
	public void clickDeactivateButton() throws Exception {
		// String btnName = WebAction.getText(deactivateAccount);
		try {
			boolean isButn = WebAction.isDisplayed(deactivateAccount);
			if (isButn) {
				WebAction.click(deactivateAccount);
			} else
				throw new Exception("Not able to click deactivate button");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Yes on Profile De-activation pop-up
	 * 
	 */

	public void clickPopUp(String messageTxt) throws Exception {
		String txtMsg = WebAction.getText(popUpHeadMsg);
		try {
			if (txtMsg.equalsIgnoreCase(messageTxt)) {
				WebAction.click(yesBtn);
			} else
				WebAction.click(noBtn);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify profile deactivated message displayed
	 * 
	 */
	public void verifyProfileDeactivatedText(String deactText) {
		String companyName = CompanyProfileConstants.getCompanyName();
		try {
			String highLight = WebAction.getText(profileName);
			String[] spl = highLight.split("-");
			if (companyName.equalsIgnoreCase(spl[0].trim()) && deactText.equalsIgnoreCase(spl[1].trim())) {
			} else {
				Assert.assertTrue(false, "Failed to match the company name");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Reactivate the company profile
	 * 
	 * @throws Exception
	 */
	public void clickReactivateAccount() throws Exception {
		try {
			boolean reaBtn = WebAction.isDisplayed(reactAcntBtn);
			if (reaBtn) {
				WebAction.click(reactAcntBtn);
			} else
				throw new Exception("Failed to display reactivate account button");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To update the Expertise value for company profile
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "(//ul[@class='styles__list__l7x6j']/preceding::div[@class='ant-select-selection-overflow'])[2]")
	WebElement expertises;

	@FindBy(xpath = "//input[@id='rc_select_2']")
	WebElement inputid;

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')][1]")
	WebElement selectvalue;

	public void updateExpertise(String expValue) throws Exception {
		// boolean isPresent = WebAction.isDisplayed(parkingLots);
		try {
			Thread.sleep(2000);
			WebAction.clickUsingJs(expertiseDropdown);
			if (expValue != null) {
				System.out.println(expertise);

				WebAction.selectDropDown(expertiseInputBox, expValue, dropDownValuesXpath, dropDownValues,
						"'" + expertise + "' value is not present in the expertise drop down");
			}
			WebAction.clickUsingJs(biographyTextArea);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click update button
	 * 
	 * @throws Exception
	 */
	public void clickUpdateButton() throws Exception {
		boolean isPresent = WebAction.isDisplayed(updateButtonEditPage);
		try {
			if (isPresent) {
				WebAction.click(updateButtonEditPage);
			} else
				throw new Exception("Update button not present in edit view page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;

		}
	}
}

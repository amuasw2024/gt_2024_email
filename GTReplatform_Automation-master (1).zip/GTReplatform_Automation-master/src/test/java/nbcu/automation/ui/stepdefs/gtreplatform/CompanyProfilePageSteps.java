package nbcu.automation.ui.stepdefs.gtreplatform;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.CompanyProfilePage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class CompanyProfilePageSteps {

	CompanyProfilePage companyProfilePage = new CompanyProfilePage();

	@Then("verify company profile page is loaded")
	public void verifyCompanyProfilePageLoaded() throws Exception {
		companyProfilePage.verifyCompanyProfilePageDisplayed();
	}

	@And("verify {string} is selected by default in profile type")
	public void verifyParentCompanySelectedByDefault(String parentType) throws Exception {
		companyProfilePage.verifyCompanyType(parentType);
	}

	@And("verify header info buttons displayed in {string} color")
	public void verifyHeaderInfoTabColor(String color) throws Exception {
		companyProfilePage.headerInfoTab(color);
	}
	
	@When("user enters the {string} details in background section of company profile")
	public void fillBackgroundInfoOfComapnyProfile(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "EXPERTISE":
			List<Map<String, String>> expertiseList = CucumberUtils.getValuesFromDataTableAsList(dataTable);
			for (int i = 0; i < expertiseList.size(); i++) {
				companyProfilePage.selectExpertise(expertiseList.get(i).get("Expertise"));
			}
			break;
		case "COMPANY NAME":
			companyProfilePage
					.fillParentCompanyName(CucumberUtils.getValuesFromDataTable(dataTable, "Parent Company Name"));
			break;
		case "BIOGRAPHY":
			companyProfilePage.fillBiogrpahyDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Bio-graphy"));
			break;
		case "TICKER":
			List<Map<String, String>> tickerList = CucumberUtils.getValuesFromDataTableAsList(dataTable);
			for (int i = 0; i < tickerList.size(); i++) {
				companyProfilePage.fillTickerDetails(tickerList.get(i).get("Ticker"));
			}
			break;
		}
	}

	@When("user enters the {string} details in Contact info section of company profile")
	public void fillContactInfoOfComapnyProfile(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "PHONE":
			companyProfilePage.fillPhoneNumberDetails(CucumberUtils.getValuesFromDataTable(dataTable, "1-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "2-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "3-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "4-Phone"));
			break;
		case "EMAIL":
			companyProfilePage.fillEmailDetails(CucumberUtils.getValuesFromDataTable(dataTable, "1-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "2-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "3-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "4-Email"));
			break;
		case "OTHER":
			companyProfilePage.fillSocialMiscDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Twitter"),
					CucumberUtils.getValuesFromDataTable(dataTable, "LinkedIn"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Video"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Website"));
			;
			break;
		case "ADDRESS":
			companyProfilePage.fillAddressDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Address-1"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Address-2"),
					CucumberUtils.getValuesFromDataTable(dataTable, "City"),
					CucumberUtils.getValuesFromDataTable(dataTable, "State"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Zip"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Country"));
			break;
		case "ALERT":
			companyProfilePage.fillAlertsDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Alerts"));
			break;
		}
	}

	@When("user selects {string} favorite in Contact info section of company profile")
	public void selectFavorite(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "PHONE":
			companyProfilePage.selectFavoritePhone(CucumberUtils.getValuesFromDataTable(dataTable, "Phone"));
			break;
		case "EMAIL":
			companyProfilePage.selectFavoriteEmail(CucumberUtils.getValuesFromDataTable(dataTable, "Email"));
			break;
		case "OTHER":
			companyProfilePage.selectFavoriteSocialMisc(CucumberUtils.getValuesFromDataTable(dataTable, "Other"));
			break;
		}
	}

	@When("user clicks on {string} button")
	public void clickButton(String buttonType) throws Exception {
		companyProfilePage.clickButton(buttonType);
	}

	// 11/14/2022 - Loga
	@Then("view company profile page is displayed")
	public void viewCompanyProfile() throws Exception {
		companyProfilePage.viewCompanyProfile();
	}

	@And("verify the {string} is displayed in company page header")
	public void viewCompanyProfileHeader(String headerPart) throws Exception {
		switch (headerPart.toUpperCase()) {
		case "COMPANY NAME":
			companyProfilePage.parentCompanyName();
			break;
		case "PROFILE TYPE":
			companyProfilePage.profileTypeOfCompany();
			break;
		case "TICKER":
			companyProfilePage.companyTicker();
			break;
		}
	}

	@And("verify below {string} is displayed")
	public void viewCompanyHeaderButton(String headersButton, DataTable dataTable) throws Exception {
		companyProfilePage.headerIcons("HeadButton", dataTable);
	}

	@Then("Basic Info tab is enabled")
	public void basicInfoTab() throws Exception {
		companyProfilePage.defEnabledTab();
	}

	@And("verify Background section header is displayed")
	public void backGround() throws Exception {
		companyProfilePage.backIsDisplayed();
	}

	@Then("verify the {string} section is displayed")
	public void verifyBackgroundSection(String sectionName) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "Biography":
			companyProfilePage.verifyBiography();
			break;
		case "Expertise":
			companyProfilePage.verifyExpertise();
			break;
		case "Ticker":
			companyProfilePage.verifyTicker();
			break;
		case "General Info":
			companyProfilePage.verifyType();
			break;
		case "Alerts":
			companyProfilePage.verifyAlerts();
			break;
		}
	}

	@Then("verify the {string} tab displayed in the contact info section")
	public void verifyPhoneNumbersValue(String tabName) throws Exception {
		switch (tabName.toUpperCase()) {
		case "PHONE":
			companyProfilePage.verifyPhoneNumbers();
			break;

		case "EMAIL" :
			companyProfilePage.verifyEmailIds();
			break;
			
		case "OTHER" :
			companyProfilePage.verfiyOtherLinks();
			break;
			
		case "ADDRESS":
			companyProfilePage.clickingAddressTab();
			companyProfilePage.verifyCompanyAddressDetails();
		break;
		}
	}
	
	@And("clicking the ellipses tab should display the Address options")
	public void clickingEllipses() throws Exception {
		companyProfilePage.clickingAddressTab();
	}
	
	@Then("created company displayed successfully")
	public void successCompanyCreation() throws Exception {
		companyProfilePage.verifyCompanyAddressDetails();
	}
	
	
	@And("user {string} the company profile")
	public void clickEditAndDeactCompany(String buttons) throws Exception {
		switch(buttons.toUpperCase()) {
		case "EDIT":
			companyProfilePage.clickEditButton();
			break;
			
		case "DEACTIVATE ACCOUNT":
			companyProfilePage.clickDeactivateButton();
			companyProfilePage.clickPopUp("Profile Deactivation");
			break;
			
		case "REACTIVATE ACCOUNT":	
			companyProfilePage.clickReactivateAccount();
			break;
		case "UPDATE":
			companyProfilePage.clickUpdateButton();
			break;
		}
	}
	
	@Then("verify the {string} message displayed")
	public void verifyDeactivatedMessage(String message) {
		companyProfilePage.verifyProfileDeactivatedText(message);
	}

	@And("user update the {string} information in background section")
	public void updateFieldsInBackgroundSection(String fieldsName, DataTable dataTable) throws Exception {
		switch(fieldsName.toUpperCase()){
		case "TICKER":
			companyProfilePage.fillTickerDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Ticker"));
			break;
		case "EXPERTISE":
			companyProfilePage.updateExpertise(CucumberUtils.getValuesFromDataTable(dataTable, "Expertise"));
			break;
		case "BIOGRAPHY":
			companyProfilePage.fillBiogrpahyDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Biography"));
			break;
		}
	}
	
	
	
}

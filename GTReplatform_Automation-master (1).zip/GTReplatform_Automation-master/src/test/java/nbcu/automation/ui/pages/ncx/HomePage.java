package nbcu.automation.ui.pages.ncx;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class HomePage {

	@FindBy(xpath = "//*[@ng-reflect-data-heading='Ready']//i[@ng-reflect-nz-type='eye']")
	WebElement hideOrUnhideIcon;

	@FindBy(xpath = "//*[@ng-reflect-nz-title='Support']")
	WebElement supportTab;

	@FindBy(xpath = "//li[contains(text(),' Admin')]")
	WebElement adminTab;

	@FindBy(xpath = "//*[@routerlink='ncx/profile']")
	WebElement profileIcon;
	
	@FindBy(xpath = "//p[contains(text(),'Logout')]")
	WebElement logOut;
	
	@FindBy(name = "header")
	WebElement frame;
	
	@FindBy(xpath = "//p[contains(text(),'You have been logged out of this application.')]")
	WebElement logOutConfirmation;
	

	public HomePage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify home page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyHomePageLoaded() throws Exception {
		try {
			Waits.waitForElement(hideOrUnhideIcon, WAIT_CONDITIONS.CLICKABLE);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To open admin page
	 * 
	 * @throws Exception
	 */
	public void openAdminPage() throws Exception {
		try {
			WebAction.click(supportTab);
			WebAction.scrollIntoView(adminTab);
			WebAction.click(adminTab);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To open profile page
	 * @throws Exception
	 */
	public void clickProfile() throws Exception {
		try {
			WebAction.click(profileIcon);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To log out of application
	 * @throws Exception
	 */
	public void logOut() throws Exception {
		try {
			WebAction.click(profileIcon);
			WebAction.mouseOverAndClick(profileIcon, logOut);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To verify application logged out
	 * @throws Exception
	 */
	public void verifyApplicationLoggedOut() throws Exception {
		try {
			WebAction.switchToFrame(frame);
			Waits.waitForElement(logOutConfirmation, WAIT_CONDITIONS.VISIBLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}

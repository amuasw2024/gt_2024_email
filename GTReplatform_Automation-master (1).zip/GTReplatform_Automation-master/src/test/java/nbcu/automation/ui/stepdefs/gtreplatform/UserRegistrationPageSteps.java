package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import nbcu.automation.ui.pages.gtreplatform.AdminPage;
import nbcu.automation.ui.pages.gtreplatform.LandingPage;
import nbcu.automation.ui.pages.gtreplatform.LoginPage;
import nbcu.automation.ui.pages.gtreplatform.RegistrationPage;

public class UserRegistrationPageSteps {

	LoginPage loginPage = new LoginPage();
	RegistrationPage registrationPage = new RegistrationPage();
	LandingPage landingPage = new LandingPage();
	AdminPage adminPage = new AdminPage();

	@And("user logins into application and see the registration page")
	public void loginIntoGtApp() throws Exception {
		loginPage.loginIntoApplication();
		registrationPage.verifyUserRegistrationPage();
		registrationPage.userInformation();
	}

	@And("user able to verify the division selection dropdown is displayed")
	public void divisionSelection() throws Exception {
		registrationPage.verifyDivisionSelection();
	}

	@Then("user able to select the division as {string}")
	public void selectDivisionFromDropDown(String division) throws Exception {
		registrationPage.selectionDivision(division);
	}

	@And("user can select all the shows from {string}")
	public void selectShowsFromDivision(String availableShows) throws Exception {
		registrationPage.selectShowsCheckBoxes();
	}

	@Then("user can select the approvers as {string}")
	public void selectApproverForTheShows(String approverName) throws Exception {
		registrationPage.selectasDontKnow();
	}

	@And("user select the agree checkbox button present in the registration page")
	public void selectAgreeCheckBox() throws Exception {
		registrationPage.checkAgreeBox();
	}

	@Then("user submitting the user registration page by filling mandatory fields")
	public void submittingRegistrForm() throws Exception {
		registrationPage.clickSubmitBtn();
	}

	@And("verify the Thanks pop-up displayed and closed the pop-up with Ok button")
	public void successPrompt() throws Exception {
		registrationPage.successPopup();
	}

	@Then("users click back button to log-out from the user registration page")
	public void logoutRegisteredUsers() throws Exception {
		registrationPage.logoutFromRegistrationPage();
	}

	@And("verify registered user re-directed to logged out page")
	public void logoutPageSeen() throws Exception {
		registrationPage.sessionLogOutPage();
	}

	@And("System administrator user logged into application")
	public void loginAsSystemAdmin()throws Exception {
		loginPage.loginAsAdminUser();
	}
	
	@Then("verify the landing page is loaded for system administrator user")
	public void landingPage() throws Exception {
		landingPage.verifyLandingPageLoaded();
	}
	
	@Then("pending users table is loaded by default in admin page")
	public void verifyPendingUsersTable() {
		adminPage.verifyPendingUsers();
	}
	
	@And("user enters the registered SSO in pending users table search field")
	public void enteredRegisteredSSOInSearchField() throws Exception {
		adminPage.toEnterRegisteredUserSSO();
	}
	
	@Then("verify the registered user details in pending users table search results")
	public void verifyRegisteredSSO() throws Exception {
		adminPage.verifySSODetails();
	}
	
	@And("System admin users able to approve the registered sso from the pending users table")
	public void verifyAdminApproveSSO() throws Exception {
		adminPage.clickApproveBtn();
		
	}
}


package nbcu.automation.ui.pages.gtreplatform;

import static org.testng.Assert.assertTrue;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.gtreplatform.AdminConstants;
import nbcu.automation.ui.constants.gtreplatform.BookerProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.constants.gtreplatform.CompanyProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.ProxyConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.others.DateFunctions.TIMEZONES;

public class LandingPage {

	// Show list in landing page

	String showListInBookedOrSegmentTabXpath = "//h2[contains(@class,'header')]/span[contains(@class,'title')] | //section[contains(@data-component,'booked')]//span[contains(@class,'title')] | //div[text()='No Bookings']";

	// user profile elements
	@FindBy(xpath = "//div[@data-trigger='profile-dropdown']//span[@aria-label='user']")
	WebElement profileDropDown;

	@FindBy(xpath = "//div[@data-trigger='profile-dropdown']/span")
	WebElement profileDropDownStatus;

	@FindBy(xpath = "//p[contains(@class,'name')]")
	WebElement bookerNameElement;

	@FindBy(xpath = "//button[text()='Admin']")
	WebElement adminIcon;

	@FindBy(xpath = "//button[contains(text(),'Profile')]")
	WebElement profileIcon;

	@FindBy(xpath = "//button[text()='Log out']")
	WebElement logOutIcon;

	@FindBy(xpath = "//*[@id='division']/../..")
	WebElement divisionDropdown;

	@FindBy(xpath = "//*[@id='division']/../following-sibling::span")
	WebElement defaultDivisionDropDown;

	// Drop down value xpath
	String dropDownvaluesXpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> dropDownvalues;

	// Add profile icons
	@FindBy(xpath = "//*[@data-trigger='add-user']")
	WebElement addUserIcon;

	@FindBy(xpath = "//li[span[text()='Guest']]")
	WebElement guestProfileIcon;

	@FindBy(xpath = "//span[text()='Company']")
	WebElement companyProfileIcon;

	@FindBy(xpath = "//span[text()='Proxy']")
	WebElement proxyProfileIcon;

	@FindBy(xpath = "//li[span[text()='Report Center']]")
	WebElement reportCenterTab;

	// Landing page headers
	@FindBy(xpath = "//span[contains(@class, 'date')]")
	WebElement calender;

	@FindBy(xpath = "//button[span[text()='Booked']]")
	WebElement bookedTab;

	@FindBy(xpath = "//button[span[text()='Cancelled']]")
	WebElement cancelledTab;

	@FindBy(xpath = "//button[span[text()='Segments']]")
	WebElement segmentsTab;

	@FindBy(xpath = "//span[@aria-label='question-circle']")
	WebElement resourceDrawerIcon;

	@FindBy(xpath = "//button[span[@aria-label='export']]")
	WebElement headerExportIcon;

	// Calender elements

	@FindBy(xpath = "//span[@aria-label='right']")
	WebElement calendarRightArrow;

	@FindBy(xpath = "//span[@aria-label='left']")
	WebElement calendarLeftArrow;

	// Booking tab elements
	String showListInBookedTabXpath = "//section[contains(@data-component,'booked')]//span[contains(@class,'title')] | //div[text()='No Bookings']";

	String bookingTabGuestProfileNameXpath = "//span[contains(@class,'guestUser') and text()=\"<<Guest Name>>\"]";

	String bookingTabShowNameXpath = "//div[text()='<<Show Time>>']/../following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/ancestor::div[contains(@data-component,'guest')]/preceding-sibling::div[contains(@data-component,'header')][1]/h2/span[contains(@class,'title')]";

	String bookingTabGuestJobTitleXpath = "//div[text()='<<Show Time>>']/../following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/../following-sibling::p";

	String bookingTabShowTimeXpath = "//span[contains(@class,'guestUser') and text()=\"<<Guest Name>>\"]/ancestor::div[contains(@class,'info')]/preceding-sibling::div[contains(@class,'time')]/div[text()='<<Show Time>>']";

	String bookingTabGuestMonthlyCountXpath = "//div[text()='<<Show Time>>']/../following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'info')]/ul/li/span[text()='Month:']/following-sibling::span";

	String bookingTabGuestWeeklyCountXpath = "//div[text()='<<Show Time>>']/../following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'info')]/ul/li/span[text()='Month:']/following-sibling::span";

	String bookingTabBookerNameXpath = "//div[text()='<<Show Time>>']/../following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'info')]/ul/li[span[span[@aria-label='user']]]";

	String bookingTabSecondSectionXpath = "//div[text()='<<Show Time>>']/../following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'sec1')]/following-sibling::div[contains(@class,'sec2')]/div/ul/li";

	String bookingTabShowExportIconXpath = "//div[text()='<<Show Time>>']/../following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/ancestor::div[contains(@data-component,'guest')]/preceding-sibling::div[contains(@data-component,'header')][1]/h2/span[contains(@class,'icon')]";

	String bookingTabBookingEllipsisIconXpath = "//div[text()='<<Show Time>>']/../following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'sec1')]/following-sibling::button[span[@aria-label='ellipsis']]";

	@FindBy(xpath = "//span[text()=' Export']")
	List<WebElement> bookingExportIcon;

	String bookingExportIconXpath = "//span[text()=' Export']";

	@FindBy(xpath = "//span[text()=' Cancel Booking']")
	List<WebElement> cancelBookingIcon;

	String cancelBookingIconXpath = "//span[text()=' Cancel Booking']";

	@FindBy(xpath = "//span[text()=' Reactivate Booking']")
	List<WebElement> reactivateBookingIcon;

	String reactivateBookingIconXpath = "//span[text()=' Reactivate Booking']";

	// Segment tab elements
	@FindBy(xpath = "//h2[contains(@class,'header')]/span[contains(@class,'title')]")
	List<WebElement> showListInSegmentTab;

	String showListInSegmentTabXpath = "//h2[contains(@class,'header')]/span[contains(@class,'title')]";

	String segmentTabShowNameXpath = "//h2[contains(@class,'header')]/span[text()='<<Show Name>>']";

	String segmentTabGuestNameXpath = "//div[div[text()='<<Topic Start Time>>']]/following-sibling::div//span[text()='<<Guest Name>>']";

	String segmentTabTopicStartAndEndTimeXpath = "//div[div[text()='<<Topic Start Time>>']]/following-sibling::div//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'info')]/preceding-sibling::div[contains(@class,'time')]/div";

	String segmentTabTopicNameXpath = "//div[div[text()='<<Topic Start Time>>']]/following-sibling::div//span[text()='<<Guest Name>>']/../following-sibling::p";

	String segmentTabStudioAndBookerXpath = "//div[div[text()='<<Topic Start Time>>']]/following-sibling::div//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'sec1')]/following-sibling::div[contains(@class,'sec2')]//li";

	String segmentTabShowExportIconXpath = "//h2[contains(@class,'header')]/span[text()='<<Show Name>>']/ancestor::span/following-sibling::div//span[@aria-label='export']";

	String segmentTabBookingEllipsisIconXpath = "//div[div[text()='<<Topic Start Time>>']]/following-sibling::div//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'sec1')]/following-sibling::button[span[@aria-label='ellipsis']]";

	String addSegmentXpath = "//h2[contains(@class,'header')]/span[text()='<<Show Name>>']/ancestor::div[@class='ant-collapse-header']/following-sibling::div[1]//button[span[text()='Add Segment']]";

	String segmentAddGuestXpath = "//h2[contains(@class,'header')]/span[text()='<<Show Name>>']/ancestor::div[@class='ant-collapse-header']/following-sibling::div[1]//button[span[text()='Add Guest']]";

	// Segment creation RH
	@FindBy(xpath = "//div[text()='Segment Creation']")
	WebElement segmentCreationRhTitle;

	@FindBy(id = "title")
	WebElement segmentName;

	// Cancelled tab elements
	String showListInCancelledTabXpath = "//section[contains(@data-component,'cancelled')]//span[contains(@class,'title')] | //div[text()='No Cancelled Bookings'] | //div[text()='No Cancellationss']";

	String cancelledDateAndByXpath = "//div[text()='<<Show Time>>']/following-sibling::div[contains(@class,'info')]//span[text()='<<Guest Name>>']/ancestor::div[contains(@class,'info')]/ul/li";

	// Global Search
	@FindBy(xpath = "//div[span[@aria-label='search']]")
	WebElement globalSearchIcon;

	@FindBy(xpath = "//div[@class='ant-drawer-header']/following-sibling::div[1]//input[@placeholder='Search']")
	WebElement searchTextBox;

	@FindBy(xpath = "//li[*[text()='Guests']]")
	WebElement guestsTab;

	@FindBy(xpath = "//li[*[text()='Bookers']]")
	WebElement bookersTab;

	@FindBy(xpath = "//li[*[text()='Proxies']]")
	WebElement proxiesTab;

	@FindBy(xpath = "//li[*[text()='Companies']]")
	WebElement companiesTab;

	@FindBy(xpath = "//button[*[text()='See Full Report']]")
	WebElement seeFullReportLink;

	@FindBy(xpath = "//ul[contains(@class,'details')]/button/li[contains(@class,'line1')]/span")
	List<WebElement> globalSearchResults;

	String globalSearchResultsXpath = "//ul[contains(@class,'details')]/button/li[contains(@class,'line1')]/span";

	public LandingPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify home page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyLandingPageLoaded() throws Exception {
		Waits.waitUntilElementSizeGreater(By.xpath(showListInBookedOrSegmentTabXpath), 0);
		Thread.sleep(1000);
		Waits.waitUntilElementSizeGreater(By.xpath(showListInBookedOrSegmentTabXpath), 0);
	}

	/**
	 * To change division of GT replatform application
	 * 
	 * @param division - division
	 * @throws Exception
	 */
	public void changeDivision(String division) throws Exception {
		try {
			AdminConstants.setDivision(division);
			Waits.waitForElement(profileDropDown, WAIT_CONDITIONS.CLICKABLE);
			Thread.sleep(2000);
			WebAction.click(profileDropDown);
			String bookerName = WebAction.getText(bookerNameElement);
			BookerProfileConstants.setBookerName(bookerName);
			WebAction.click(divisionDropdown);
			WebAction.nonEnterebaleSelectDropDown(dropDownvaluesXpath, division,
					"'" + division + "' value is not present in the division drop down");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click icon from profile drop down
	 * 
	 * @param iconName - icon name
	 * @throws Exception
	 */
	public void selectIconFromProfileDropDown(String iconName) throws Exception {
		try {
			Waits.waitForElement(profileDropDown, WAIT_CONDITIONS.CLICKABLE);
			if (WebAction.getAttribute(profileDropDownStatus, "aria-label").equalsIgnoreCase("caret-down"))
				WebAction.click(profileDropDown);
			if (iconName.equalsIgnoreCase("ADMIN"))
				WebAction.click(adminIcon);
			else if (iconName.equalsIgnoreCase("PROFILE"))
				WebAction.click(profileIcon);
			else if (iconName.equalsIgnoreCase("LOG OUT"))
				WebAction.click(logOutIcon);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click add profile/company/profile icon
	 * 
	 * @throws Exception
	 */
	public void clickAddProfile(String profileType) throws Exception {
		WebAction.mouseOver(addUserIcon);
		switch (profileType.toUpperCase()) {
		case "ADD GUEST PROFILE":
			WebAction.click(guestProfileIcon);
			break;
		case "ADD COMPANY PROFILE":
			WebAction.click(companyProfileIcon);
			break;
		case "ADD PROXY PROFILE":
			WebAction.click(proxyProfileIcon);
			break;
		default:
			Assert.assertTrue(false, "Please enter valid profile type");
		}
	}

	/**
	 * To click tabs in home page
	 * 
	 * @param tabName
	 * @throws Exception
	 */
	public void clickHomePageTabs(String tabName) throws Exception {
		switch (tabName.toUpperCase()) {
		case "REPORT CENTER":
			WebAction.click(reportCenterTab);
			break;
		}
	}

	/**
	 * To verify landing page default settings
	 * 
	 * @throws Exception
	 */
	public void verifyLandingPageDefaults() throws Exception {
		try {
			// Calendar should have today's by default
			String expectedDate = DateFunctions.getCurrentDateAndTimeByTimeZone("MM / dd / yyyy", TIMEZONES.EST);
			String actualDate = WebAction.getText(calender);
			CommonValidations.verifyTextValue(calender, expectedDate, actualDate);

			// Verify Booked, Cancelled, Segments, Resource drawer and export tabs are
			// displayed
			Waits.waitForElement(bookedTab, WAIT_CONDITIONS.CLICKABLE);
			Waits.waitForElement(cancelledTab, WAIT_CONDITIONS.CLICKABLE);
			Waits.waitForElement(segmentsTab, WAIT_CONDITIONS.CLICKABLE);
			Waits.waitForElement(resourceDrawerIcon, WAIT_CONDITIONS.CLICKABLE);
			Waits.waitForElement(headerExportIcon, WAIT_CONDITIONS.CLICKABLE);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To change date in calendar in landing page
	 * 
	 * @throws Exception
	 */
	public void changeCalenderDate(String bookingDate) throws Exception {
		try {
			String currentDate = WebAction.getText(calender);
			currentDate = DateFunctions.convertDateStringToAnotherFormat(currentDate, "MM / dd / yyyy", "MM/dd/yyyy");
			int dateDiff = (int) DateFunctions.findNumberOfDaysBetweenTwoDates(currentDate, bookingDate);
			// System.out.println(dateDiff);
			if (dateDiff > 0) {
				for (int i = 0; i < dateDiff; i++) {
					Waits.waitForElement(calendarRightArrow, WAIT_CONDITIONS.CLICKABLE);
					Thread.sleep(1000);
					WebAction.click(calendarRightArrow);
					Thread.sleep(1000);
				}
			} else if (dateDiff < 0) {
				for (int i = 0; i > dateDiff; i--) {
					Waits.waitForElement(calendarLeftArrow, WAIT_CONDITIONS.CLICKABLE);
					Thread.sleep(1000);
					WebAction.click(calendarLeftArrow);
					Thread.sleep(1000);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify booking details in landing page
	 * 
	 * @throws Exception
	 */
	public void verifyBookingDisplayedInBookedTab() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(showListInBookedTabXpath), 0);

			// To fetch guest name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();

			// To fetch show time
			String expectedShowTime = "";
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedShowTime = BookingGuestConstants.getShowTime();
			else
				expectedShowTime = BookingGuestConstants.getDuplicateBookingShowTime();

			expectedShowTime = DateFunctions.convertDateStringToAnotherFormat(expectedShowTime, "HH:mm", "hh:mm a");

			// Verify booking placed under show name
			String expectedShowName = BookingGuestConstants.getShowName();
			WebElement showNameElement = driver.findElement(By.xpath(bookingTabShowNameXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			CommonValidations.verifyTextValue(showNameElement, expectedShowName,
					"Booking for guest profile '" + expectedGuestName + "' is not present under show '"
							+ expectedShowName + "' in  booked tab of landing page");

			// Verify show time
			boolean showTimeCheck = false;
			List<WebElement> showTimeElementList = driver.findElements(By.xpath(bookingTabShowTimeXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			for (WebElement element : showTimeElementList) {
				if (WebAction.getText(element).equalsIgnoreCase(expectedShowTime)) {
					showTimeCheck = true;
					break;
				}
			}
			Assert.assertTrue(showTimeCheck, "Booking show time is not correct in booked tab of landing page");

			// verify guest job title and company name
			List<WebElement> jobTitleElement = driver.findElements(By.xpath(bookingTabGuestJobTitleXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));

			// job title
			String expectedJobTitle = GuestProfileConstants.getPrimaryJobTitle();
			CommonValidations.verifyTextValue(jobTitleElement.get(0), expectedJobTitle,
					"Guest profile '" + expectedGuestName + "' job title is not correct in booked tab of landing page");

			// company name
			if (GuestProfileConstants.getPrimaryCompany() != null) {
				String expectedCompanyName = GuestProfileConstants.getPrimaryCompany();
				CommonValidations.verifyTextValue(jobTitleElement.get(1), expectedCompanyName, "Guest profile '"
						+ expectedGuestName + "' company name is not correct in booked tab of landing page");
			}

			// Verify topic name
			String expectedTopicName = BookingGuestConstants.getTopicName();
			List<WebElement> secondSecElements = driver.findElements(By.xpath(bookingTabSecondSectionXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			CommonValidations.verifyTextValue(secondSecElements.get(0), expectedTopicName,
					"Booking topic name is not correct in booked tab of landing page");

			// Verify studio name
			String expectedStudioName = BookingGuestConstants.getStudio();
			CommonValidations.verifyTextValue(secondSecElements.get(1), expectedStudioName,
					"Booking studio name is not correct in booked tab of landing page");

			// Verify guest gender
			String expectedGender = GuestProfileConstants.getGender();
			CommonValidations.verifyTextValue(secondSecElements.get(2), expectedGender,
					"Guest profile gender is not correct in booked tab of landing page");

			// Verify guest ethnicity
			String expectedEthnicity = GuestProfileConstants.getEthnicity();
			CommonValidations.verifyTextValue(secondSecElements.get(2), expectedEthnicity,
					"Guest profile ethnicity is not correct in booked tab of landing page");

			// Verify guest monthly count
			String actualGuestMonthlyCount = WebAction
					.getText(driver.findElement(By.xpath(bookingTabGuestMonthlyCountXpath
							.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime))));
			Assert.assertFalse(actualGuestMonthlyCount.trim().isEmpty(),
					"Guest count profile monthly book count is not displayed in booked tab of landing page");

			// Verify guest weekly count
			String actualGuestWeeklyCount = WebAction
					.getText(driver.findElement(By.xpath(bookingTabGuestWeeklyCountXpath
							.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime))));
			Assert.assertFalse(actualGuestWeeklyCount.trim().isEmpty(),
					"Guest count profile weekly book count is not displayed in booked tab of landing page");

			// Verify booker name
			WebElement bookeNameElement = driver.findElement(By.xpath(bookingTabBookerNameXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			CommonValidations.verifyTextValue(bookeNameElement, BookerProfileConstants.getBookerName(),
					"Booker name of booking is not correct in booked tab of landing page");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To export icon is displayed for booking show
	 * 
	 * @throws Exception
	 */
	public void verifyShowExportIconDisplayedInBookedTab(String tabName) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			// To fetch guest name and show name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();
			String expectedShowName = BookingGuestConstants.getShowName();
			String expectedShowTime = "";
			// To fetch show time
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedShowTime = BookingGuestConstants.getShowTime();
			else
				expectedShowTime = BookingGuestConstants.getDuplicateBookingShowTime();
			expectedShowTime = DateFunctions.convertDateStringToAnotherFormat(expectedShowTime, "HH:mm", "hh:mm a");

			WebElement showExportIcon = driver.findElement(By.xpath(bookingTabShowExportIconXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			// validate export icon is displayed
			Assert.assertTrue(WebAction.isDisplayed(showExportIcon), "Export icon is not displayed for show '"
					+ expectedShowName + "' in " + tabName + " tab of landing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click on show time link in booked tab
	 * 
	 * @throws Exception
	 */
	public void clickOnShowTimeLinkInBookedTab() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String expectedShowTime = "";
			// To fetch show time
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedShowTime = BookingGuestConstants.getShowTime();
			else
				expectedShowTime = BookingGuestConstants.getDuplicateBookingShowTime();

			expectedShowTime = DateFunctions.convertDateStringToAnotherFormat(expectedShowTime, "HH:mm", "hh:mm a");

			// To fetch guest name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();
			Waits.waitForElement(By.xpath(bookingTabShowTimeXpath.replace("<<Guest Name>>", expectedGuestName)
					.replace("<<Show Time>>", expectedShowTime)), WAIT_CONDITIONS.CLICKABLE);
			WebElement showTimeElement = driver.findElement(By.xpath(bookingTabShowTimeXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			Thread.sleep(2000);
			WebAction.clickUsingJs(showTimeElement);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To validate booking has ellipsis icon
	 * 
	 * @throws Exception
	 */
	public void verifyBookingHasEllipsisIconInBookedTab(String tabName) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String expectedShowTime = "";
			// To fetch show time
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedShowTime = BookingGuestConstants.getShowTime();
			else
				expectedShowTime = BookingGuestConstants.getDuplicateBookingShowTime();
			expectedShowTime = DateFunctions.convertDateStringToAnotherFormat(expectedShowTime, "HH:mm", "hh:mm a");

			// To fetch guest name and show name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();

			WebElement bookingEllipsisIcon = driver.findElement(By.xpath(bookingTabBookingEllipsisIconXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			// validate export icon is displayed
			Assert.assertTrue(WebAction.isDisplayed(bookingEllipsisIcon),
					"Ellipsis icon is not present for booking of guest profile '" + expectedGuestName + "' in "
							+ tabName + " tab of landing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click ellipsis, export and cancel booking icon of all tab
	 * 
	 * @param iconName - icon name
	 * @throws Exception
	 */
	public void clickIconInAllTab(String iconName, String tabName) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			// To fetch guest name and show name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();

			// To fetch show time
			String expectedShowTime = "";
			// To fetch show time
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedShowTime = BookingGuestConstants.getShowTime();
			else
				expectedShowTime = BookingGuestConstants.getDuplicateBookingShowTime();
			expectedShowTime = DateFunctions.convertDateStringToAnotherFormat(expectedShowTime, "HH:mm", "hh:mm a");

			// To fetch topic start time
			String expectedTopicStartTime = "";
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedTopicStartTime = BookingGuestConstants.getTopicStartTime();
			else
				expectedTopicStartTime = BookingGuestConstants.getDuplicateBookingTopicStartTime();
			expectedTopicStartTime = DateFunctions.convertDateStringToAnotherFormat(expectedTopicStartTime, "HH:mm",
					"hh:mm a");

			switch (iconName.toUpperCase()) {
			case "ELLIPSIS":
				WebElement ellipsisIcon = null;
				if (tabName.equalsIgnoreCase("BOOKED") || tabName.equalsIgnoreCase("CANCELLED")) {
					WebElement showNameElement = driver.findElement(By.xpath(bookingTabShowNameXpath
							.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
					WebAction.scrollIntoView(showNameElement);
					ellipsisIcon = driver.findElement(By.xpath(bookingTabBookingEllipsisIconXpath
							.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
				}

				else {
					String expectedShowName = BookingGuestConstants.getShowName();
					WebElement showNameElement = driver
							.findElement(By.xpath(segmentTabShowNameXpath.replace("<<Show Name>>", expectedShowName)));
					WebAction.scrollIntoView(showNameElement);
					ellipsisIcon = driver.findElement(
							By.xpath(segmentTabBookingEllipsisIconXpath.replace("<<Guest Name>>", expectedGuestName)
									.replace("<<Topic Start Time>>", expectedTopicStartTime)));
				}
				WebAction.click(ellipsisIcon);
				break;
			case "EXPORT":
				for (WebElement element : bookingExportIcon) {
					if (element.isDisplayed()) {
						WebAction.click(element);
						break;
					}
				}
				break;
			case "CANCEL BOOKING":
				for (WebElement element : cancelBookingIcon) {
					if (element.isDisplayed()) {
						Thread.sleep(2000);
						WebAction.click(element);
						break;

					}
				}
				break;
			case "REACTIVATE BOOKING":
				WebAction.scrollIntoView(driver.findElement(By.xpath(bookingTabShowNameXpath
						.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime))));
				for (WebElement element : reactivateBookingIcon) {
					if (element.isDisplayed()) {
						WebAction.click(element);
						break;
					}
				}
				break;
			default:
				Assert.assertTrue(false, "Please enter valid icon name in " + tabName + " tab");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify options in ellipsis in all tab
	 * 
	 * @throws Exception
	 */
	public void verifyOptionsInEllipsis(String option1, String option2, String tabName) throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(bookingExportIconXpath), 0);
			Assert.assertTrue(bookingExportIcon.size() > 0,
					"Export icon is not displayed when user cliked ellipsis icon in " + tabName
							+ " tab of landing page");
			if (option2.equalsIgnoreCase("CANCEL BOOKING")) {
				Waits.waitUntilElementSizeGreater(By.xpath(cancelBookingIconXpath), 0);
				Assert.assertTrue(cancelBookingIcon.size() > 0,
						"Cancel Booking icon is not displayed when user cliked ellipsis icon in " + tabName
								+ " tab of landing page");
			} else if (option2.equalsIgnoreCase("RESTORE BOOKING")) {
				Waits.waitUntilElementSizeGreater(By.xpath(reactivateBookingIconXpath), 0);
				Assert.assertTrue(reactivateBookingIcon.size() > 0,
						"Reactivate Booking icon is not displayed when user cliked ellipsis icon in " + tabName
								+ " tab of landing page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify recurring booking details in booked and segments tab
	 * 
	 * @throws Exception
	 */
	public void verifyRecurringBookingDetailsInBookedAndSegmentTab() throws Exception {
		try {
			int recurringBookingDatesCount = Integer.parseInt(BookingGuestConstants.getRecurringBookingDatesCount());
			for (int i = 0; i < recurringBookingDatesCount; i++) {
				String recurringDate = BookingGuestConstants.getRecurringBookingDates(i);
				verifyRecurringBookingDetailsInBookedTab(recurringDate);
				verifyRecurringBookingDetailsInSegmentsTab(recurringDate);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify recurring booking in booked tab
	 * 
	 * @param recurringDate - recurring date
	 * @throws Exception
	 */
	public void verifyRecurringBookingDetailsInBookedTab(String recurringDate) throws Exception {
		try {
			clickTabInLandingPage("Booked");
			verifyLandingPageLoaded();
			changeCalenderDate(recurringDate);
			verifyBookingDisplayedInBookedTab();
			verifyShowExportIconDisplayedInBookedTab("Booked");
			verifyBookingHasEllipsisIconInBookedTab("Booked");
			clickIconInAllTab("ellipsis", "Booked");
			verifyOptionsInEllipsis("export", "cancel booking", "booked");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify recurring booking in segments tab
	 * 
	 * @param recurringDate - recurring date
	 * @throws Exception
	 */
	public void verifyRecurringBookingDetailsInSegmentsTab(String recurringDate) throws Exception {
		try {
			clickTabInLandingPage("Segments");
			verifySegmentsTabLoaded();
			changeCalenderDate(recurringDate);
			openShowInSegmentTab();
			verifyBookingDisplayedInSegmentTab();
			verifyShowExportIconDisplayedInSegmentTab();
			clickIconInAllTab("ellipsis", "Segments");
			verifyOptionsInEllipsis("export", "cancel booking", "Segments");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select tab in landing page
	 * 
	 * @param tabType
	 * @throws Exception
	 */
	public void clickTabInLandingPage(String tabType) throws Exception {
		try {
			switch (tabType.toUpperCase()) {
			case "BOOKED":
				WebAction.click(bookedTab);
				break;
			case "CANCELLED":
				WebAction.click(cancelledTab);
				break;
			case "SEGMENTS":
				WebAction.click(segmentsTab);
				break;
			default:
				Assert.assertTrue(false, "Please enter valid tab type in landing page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify default selected tab
	 * 
	 * @param tabType
	 * @throws Exception
	 */
	public void verifyDefaultSelectedTab() throws Exception {
		try {
			String tabType = BookerProfileConstants.getDefaultViewName();
			switch (tabType.toUpperCase()) {
			case "BOOKED":
				CommonValidations.verifyColorOfElement(bookedTab, "color", "blue");
				break;
			case "SEGMENTS":
				CommonValidations.verifyColorOfElement(segmentsTab, "color", "blue");
				break;
			default:
				Assert.assertTrue(false, "Please enter valid tab type in landing page");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify segment tab is loaded successfully
	 * 
	 * @throws Exception
	 */
	public void verifySegmentsTabLoaded() throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(showListInSegmentTabXpath), 0);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To open show in segment tab
	 * 
	 * @throws Exception
	 */
	public void openShowInSegmentTab() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String expectedShowName = "";
		try {
			if (AdminConstants.getShowName() != null)
				expectedShowName = AdminConstants.getShowName();
			else if (BookingGuestConstants.getShowName() != null)
				expectedShowName = BookingGuestConstants.getShowName();
			WebElement showNameElement = driver
					.findElement(By.xpath(segmentTabShowNameXpath.replace("<<Show Name>>", expectedShowName)));
			// WebAction.scrollIntoView(showNameElement);
			WebAction.click(showNameElement);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify booking details in segment tab
	 * 
	 * @throws Exception
	 */
	public void verifyBookingDisplayedInSegmentTab() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			// To fetch guest name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();
			// To fetch show name
			String expectedShowName = "";
			if (AdminConstants.getShowName() != null)
				expectedShowName = AdminConstants.getShowName();
			else if (BookingGuestConstants.getShowName() != null)
				expectedShowName = BookingGuestConstants.getShowName();
			// To fetch expected topic start time
			String expectedTopicStartTime = "";
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedTopicStartTime = BookingGuestConstants.getTopicStartTime();
			else
				expectedTopicStartTime = BookingGuestConstants.getDuplicateBookingTopicStartTime();

			expectedTopicStartTime = DateFunctions.convertDateStringToAnotherFormat(expectedTopicStartTime, "HH:mm",
					"hh:mm a");

			// Verify booking placed under show name
			Waits.waitForElement(By.xpath(segmentTabGuestNameXpath.replace("<<Guest Name>>", expectedGuestName)
					.replace("<<Topic Start Time>>", expectedTopicStartTime)), WAIT_CONDITIONS.VISIBLE);
			WebElement guestNameNameElement = driver
					.findElement(By.xpath(segmentTabGuestNameXpath.replace("<<Guest Name>>", expectedGuestName)
							.replace("<<Topic Start Time>>", expectedTopicStartTime)));
			assertTrue(WebAction.isDisplayed(guestNameNameElement), "Booking for guest profile '" + expectedGuestName
					+ "' is not present under show '" + expectedShowName + "' in segment tab of landing page");

			// Verify topic and company name
			List<WebElement> topicAndCompanyNameElements = driver
					.findElements(By.xpath(segmentTabTopicNameXpath.replace("<<Guest Name>>", expectedGuestName)
							.replace("<<Topic Start Time>>", expectedTopicStartTime)));
			// verify topic name
			String expectedTopicName = BookingGuestConstants.getTopicName();
			CommonValidations.verifyTextValue(topicAndCompanyNameElements.get(0), expectedTopicName,
					"Booking topic name is not correct in segment tab of landing page");

			// verify company name
			String expectedCompanyName = GuestProfileConstants.getPrimaryCompany();
			CommonValidations.verifyTextValue(topicAndCompanyNameElements.get(1), expectedCompanyName,
					"Booking company name is not correct in segment tab of landing page");

			// Verify topic start and end time

			String expectedTopicEndTime = "";
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedTopicEndTime = BookingGuestConstants.getTopicEndTime();
			else
				expectedTopicEndTime = BookingGuestConstants.getDuplicateBookingTopicEndTime();
			expectedTopicEndTime = DateFunctions.convertDateStringToAnotherFormat(expectedTopicEndTime, "HH:mm",
					"hh:mm a");

			List<WebElement> topicStartAndEndTime = driver.findElements(
					By.xpath(segmentTabTopicStartAndEndTimeXpath.replace("<<Guest Name>>", expectedGuestName)
							.replace("<<Topic Start Time>>", expectedTopicStartTime)));
			CommonValidations.verifyTextValue(topicStartAndEndTime.get(0), expectedTopicStartTime,
					"Booking topic start time is not correct in segment tab of landing page");
			CommonValidations.verifyTextValue(topicStartAndEndTime.get(1), expectedTopicEndTime,
					"Booking topic end time is not correct in segment tab of landing page");

			// Verify studio and booker name
			String expectedStudioName = BookingGuestConstants.getStudio();
			List<WebElement> expectedStudioBookerName = driver
					.findElements(By.xpath(segmentTabStudioAndBookerXpath.replace("<<Guest Name>>", expectedGuestName)
							.replace("<<Topic Start Time>>", expectedTopicStartTime)));
			CommonValidations.verifyTextValue(expectedStudioBookerName.get(0), expectedStudioName,
					"Booking studio name is not correct in segment tab of landing page");
			CommonValidations.verifyTextValue(expectedStudioBookerName.get(1), BookerProfileConstants.getBookerName(),
					"Booker name of booking is not correct in segment tab of landing page");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To export icon is displayed for booking show in segments tab
	 * 
	 * @throws Exception
	 */
	public void verifyShowExportIconDisplayedInSegmentTab() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			// To fetch how name
			String expectedShowName = "";
			if (AdminConstants.getShowName() != null)
				expectedShowName = AdminConstants.getShowName();
			else if (BookingGuestConstants.getShowName() != null)
				expectedShowName = BookingGuestConstants.getShowName();

			WebElement showExportIcon = driver
					.findElement(By.xpath(segmentTabShowExportIconXpath.replace("<<Show Name>>", expectedShowName)));
			// validate export icon is displayed
			Assert.assertTrue(WebAction.isDisplayed(showExportIcon),
					"Export icon is not displayed for show '" + expectedShowName + "' in segments tab of landing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To validate booking has ellipsis icon in segments tab
	 * 
	 * @throws Exception
	 */
	public void verifyBookingHasEllipsisIconInSegmentTab() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			// To fetch expected topic start time
			String expectedTopicStartTime = "";
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedTopicStartTime = BookingGuestConstants.getTopicStartTime();
			else
				expectedTopicStartTime = BookingGuestConstants.getDuplicateBookingTopicStartTime();

			expectedTopicStartTime = DateFunctions.convertDateStringToAnotherFormat(expectedTopicStartTime, "HH:mm",
					"hh:mm a");

			// To fetch guest name and show name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();

			WebElement bookingEllipsisIcon = driver.findElement(
					By.xpath(segmentTabBookingEllipsisIconXpath.replace("<<Guest Name>>", expectedGuestName)
							.replace("<<Topic Start Time>>", expectedTopicStartTime)));
			// validate export icon is displayed
			Assert.assertTrue(WebAction.isDisplayed(bookingEllipsisIcon),
					"Ellipsis icon is not present for booking of guest profile '" + expectedGuestName
							+ "' in segments tab of landing page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify add segment or add button is displayed under show
	 * 
	 * @throws Exception
	 */
	public void verifyAddSegmentOrGuestButtonDisplayed(DataTable params) throws Exception {
		String expectedShowName = "";
		try {
			if (AdminConstants.getShowName() != null)
				expectedShowName = AdminConstants.getShowName();
			else if (BookingGuestConstants.getShowName() != null)
				expectedShowName = BookingGuestConstants.getShowName();

			List<Map<String, String>> iconsList = CucumberUtils.getValuesFromDataTableAsList(params);
			for (int i = 0; i < iconsList.size(); i++) {
				String iconName = iconsList.get(i).get("Icon Name");
				if (iconName.equalsIgnoreCase("ADD SEGMENT")) {
					Waits.waitForElement(By.xpath(addSegmentXpath.replace("<<Show Name>>", expectedShowName)),
							WAIT_CONDITIONS.CLICKABLE);
				} else if (iconName.equalsIgnoreCase("ADD GUEST")) {
					Waits.waitForElement(By.xpath(segmentAddGuestXpath.replace("<<Show Name>>", expectedShowName)),
							WAIT_CONDITIONS.CLICKABLE);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Add Segment/Add Guest button in segment tab
	 * 
	 * @throws Exception
	 */
	public void clickAddSegmentOrGuestButton(String buttonName) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String expectedShowName = "";
			if (AdminConstants.getShowName() != null)
				expectedShowName = AdminConstants.getShowName();
			else if (BookingGuestConstants.getShowName() != null)
				expectedShowName = BookingGuestConstants.getShowName();

			if (buttonName.equalsIgnoreCase("ADD SEGMENT")) {
				WebElement addSegmentElement = driver
						.findElement(By.xpath(addSegmentXpath.replace("<<Show Name>>", expectedShowName)));
				Waits.waitUntilElementSizeGreater(By.xpath(addSegmentXpath.replace("<<Show Name>>", expectedShowName)),
						0);
				WebAction.clickUsingJs(addSegmentElement);
			} else if (buttonName.equalsIgnoreCase("ADD GUEST")) {
				WebElement segmentAddGuestElement = driver
						.findElement(By.xpath(segmentAddGuestXpath.replace("<<Show Name>>", expectedShowName)));
				Waits.waitUntilElementSizeGreater(
						By.xpath(segmentAddGuestXpath.replace("<<Show Name>>", expectedShowName)), 0);
				WebAction.clickUsingJs(segmentAddGuestElement);
			} else
				Assert.assertTrue(false, "Please enter valid button name in segment tab");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify add segment RH is displayed
	 * 
	 * @throws Exception
	 */
	public void verifyAddSegmentRhDisplayed() throws Exception {
		try {
			Waits.waitForElement(segmentCreationRhTitle, WAIT_CONDITIONS.VISIBLE);
			Thread.sleep(3000);
			Waits.waitForElement(segmentName, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify cancelled tab is loaded successfully
	 * 
	 * @throws Exception
	 */
	public void verifyCancelledTabLoaded() throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(showListInCancelledTabXpath), 0);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify cancelled booking is displayed in cancelled tab
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings("unused")
	public void verifyBookingDisplayedInCancelledTab() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(showListInCancelledTabXpath), 0);

			// To fetch guest name
			String expectedGuestName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();

			// To fetch show time
			String expectedShowTime = "";
			if (BookingGuestConstants.getIsDuplicateBooking() == null
					|| BookingGuestConstants.getIsDuplicateBooking().equalsIgnoreCase("NO"))
				expectedShowTime = BookingGuestConstants.getShowTime();
			else
				expectedShowTime = BookingGuestConstants.getDuplicateBookingShowTime();
			expectedShowTime = DateFunctions.convertDateStringToAnotherFormat(expectedShowTime, "HH:mm", "hh:mm a");

			// Verify booking placed under show name
			String expectedShowName = BookingGuestConstants.getShowName();

			WebElement showNameElement = driver.findElement(By.xpath(bookingTabShowNameXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			CommonValidations.verifyTextValue(showNameElement, expectedShowName,
					"Cancelled booking for guest profile '" + expectedGuestName + "' is not present under show '"
							+ expectedShowName + "' in  cancelled tab of landing page");

			// Verify show time
			boolean showTimeCheck = false;
			List<WebElement> showTimeElementList = driver.findElements(By.xpath(bookingTabShowTimeXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			for (WebElement element : showTimeElementList) {
				if (WebAction.getText(element).equalsIgnoreCase(expectedShowTime)) {
					showTimeCheck = true;
					break;
				}
			}
			Assert.assertTrue(showTimeCheck,
					"Cancelled booking show time is not correct in cancelled tab of landing page");

			// verify guest job title and company name
			List<WebElement> jobTitleElement = driver.findElements(By.xpath(bookingTabGuestJobTitleXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));

			// verify title
			String expectedJobTitle = GuestProfileConstants.getPrimaryJobTitle();
			CommonValidations.verifyTextValue(jobTitleElement.get(0), expectedJobTitle, "Guest profile '"
					+ expectedGuestName + "' job title is not correct in cancelled tab of landing page");

			String expectedCompanyName = GuestProfileConstants.getPrimaryCompany();
			CommonValidations.verifyTextValue(jobTitleElement.get(1), expectedCompanyName, "Guest profile '"
					+ expectedGuestName + "' company name is not correct in cancelled tab of landing page");

			// Verify topic name
			String expectedTopicName = BookingGuestConstants.getTopicName();
			List<WebElement> secondSecElements = driver.findElements(By.xpath(bookingTabSecondSectionXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			CommonValidations.verifyTextValue(secondSecElements.get(0), expectedTopicName,
					"Cancelled booking topic name is not correct in cancelled tab of landing page");

			// Verify studio name
			String expectedStudioName = BookingGuestConstants.getStudio();
			CommonValidations.verifyTextValue(secondSecElements.get(1), expectedStudioName,
					"Cancelled booking studio name is not correct in cancelled tab of landing page");

			// Verify booking cancellation reason
			String expectedBookingCancellationReason = BookingGuestConstants.getBookingCancellationReason();
			CommonValidations.verifyTextValue(secondSecElements.get(2), expectedBookingCancellationReason,
					"Booking cancellation is not correct in cancelled tab of landing page");

			// Verify booked cancelled date
			List<WebElement> cancelledDateAndBy = driver.findElements(By.xpath(cancelledDateAndByXpath
					.replace("<<Guest Name>>", expectedGuestName).replace("<<Show Time>>", expectedShowTime)));
			/*
			 * CommonValidations.verifyTextValue(cancelledDateAndBy.get(0),
			 * DateFunctions.getCurrentDateAndTimeByTimeZone("MM/dd/yyyy", TIMEZONES.EST),
			 * "Booking cancelled date is not correct in cancelled tab of landing page");
			 */
			// Verify cancelled by name
			/*
			 * CommonValidations.verifyTextValue(cancelledDateAndBy.get(2),
			 * BookerProfileConstants.getBookerName(),
			 * "Booking cancelled by is not correct in cancelled tab of landing page");
			 */
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify default division
	 * 
	 * @throws Exception
	 */
	public void verifyDefaultDivision() throws Exception {
		try {
			WebAction.click(profileDropDown);
			Waits.waitForElement(divisionDropdown, WAIT_CONDITIONS.CLICKABLE);
			CommonValidations.verifyAttributeValue(defaultDivisionDropDown, "title",
					BookerProfileConstants.getDefaultDivisionName(),
					"Default division is not displayed as '" + BookerProfileConstants.getDefaultDivisionName() + "'");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click global search icon
	 * 
	 * @throws Exception
	 */
	public void clickGlobalSearchIcon() throws Exception {
		try {
			WebAction.click(globalSearchIcon);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To search profiles in global search
	 * 
	 * @throws Exception
	 */
	public void searchProfile(String profileType) throws Exception {
		String searchText = "";
		try {
			Waits.waitForElement(searchTextBox, WAIT_CONDITIONS.CLICKABLE);
			if (profileType.equalsIgnoreCase("PROXY"))
				searchText = ProxyConstants.getDisplayName();
			else if (profileType.equalsIgnoreCase("GUEST"))
				searchText = GuestProfileConstants.getDisplayName();
			else if (profileType.equalsIgnoreCase("COMPANY"))
				searchText = CompanyProfileConstants.getCompanyName();
			else
				searchText = "";
			WebAction.sendKeys(searchTextBox, searchText);
			Waits.waitForElement(globalSearchIcon, WAIT_CONDITIONS.CLICKABLE);
			WebAction.keyPress(searchTextBox, "ENTER");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify maximum of 50 results is displayed in global search
	 * 
	 * @throws Exception
	 */
	public void verifyTop50SearchResultsAreDisplayed(String profileType) throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(globalSearchResultsXpath), 0);
			Waits.waitForElement(globalSearchResults.get(0), WAIT_CONDITIONS.CLICKABLE);

			int searchResultCount = 0;
			for (WebElement element : globalSearchResults) {
				if ((profileType.equalsIgnoreCase("PROXY")) || (profileType.equalsIgnoreCase("GUEST"))) {
					if (!WebAction.getText(element).toUpperCase().contains("COMPANY")) {
						searchResultCount++;
					}
				} else
					searchResultCount++;
			}
			System.out.println("Search count:" + searchResultCount);
			if (searchResultCount == 0)
				Assert.assertTrue(false, "Global search result is not displayed");
			if (searchResultCount > 50)
				Assert.assertTrue(false, "Global search result count is greater than 50");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify exact search result
	 * 
	 * @param profileType - Profile type
	 * @throws Exception
	 */
	public void verifyExactSearchResult(String profileType) throws Exception {
		String displayName = "";
		try {

			if (profileType.equalsIgnoreCase("PROXY"))
				displayName = "Proxy Profile Display Name_";
			else if (profileType.equalsIgnoreCase("GUEST"))
				displayName = "Automation Display Name_";
			else if (profileType.equalsIgnoreCase("COMPANY"))
				displayName = CompanyProfileConstants.getCompanyName();
			else
				displayName = "";

			//
			WebElement element = null;
			if (globalSearchResults.size() > 1)
				element = globalSearchResults.get(1);
			else
				element = globalSearchResults.get(0);

			CommonValidations.verifyTextValue(element, displayName,
					"Exact search is not worked as expected for '" + displayName + "'");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click see full report link
	 * 
	 * @throws Exception
	 */
	public void clickSeeFullReportLink() throws Exception {
		try {
			WebAction.click(seeFullReportLink);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select global search tab
	 * 
	 * @throws Exception
	 */
	public void selectGlobalSearchTab(String tabName) throws Exception {
		try {
			if (tabName.equalsIgnoreCase("PROXIES"))
				WebAction.click(proxiesTab);
			else if (tabName.equalsIgnoreCase("COMPANIES"))
				WebAction.click(companiesTab);
			else if (tabName.equalsIgnoreCase("BOOKERS"))
				WebAction.click(bookersTab);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To search and open guest profile with random string
	 * 
	 * @param profileType
	 * @throws Exception
	 */
	public void searchAndOpenGuestProfile() throws Exception {
		String searchText = "";
		try {
			// Search guest profile
			searchText = GuestProfileConstants.getDisplayName().split("_")[1];
			System.out.println("Guest Name:"+searchText);
			WebAction.clickUsingJs(searchTextBox);
			WebAction.sendKeys(searchTextBox, searchText);
			Waits.waitForElement(globalSearchIcon, WAIT_CONDITIONS.CLICKABLE);
			WebAction.keyPress(searchTextBox, "ENTER");

			// Select guest profile
			Waits.waitUntilElementSizeGreater(By.xpath(globalSearchResultsXpath), 0);
			WebAction.click(globalSearchResults.get(0));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}

package nbcu.automation.ui.pages.gtreplatform;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
import nbcu.automation.ui.constants.gtreplatform.CompanyProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
import nbcu.automation.ui.constants.gtreplatform.ProxyConstants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class ReportCenterPage {

	@FindBy(xpath = "//button[text()='Bookings']")
	WebElement bookingsView;

	@FindBy(xpath = "//li[span[text()='Calls']]")
	WebElement callsTab;

	@FindBy(xpath = "//li[span[text()='Bookings']]")
	WebElement bookingsTab;

	@FindBy(xpath = "//li[span[text()='Reports']]")
	WebElement reportsTab;

	@FindBy(xpath = "//span[text()='My Bookings']")
	WebElement myBookingsTab;

	// Calls table elements
	@FindBy(xpath = "//span[contains(text(),'My')]")
	WebElement myCallsTab;

	@FindBy(xpath = "//span[text()='All']/..")
	WebElement allCalls;

	@FindBy(xpath = "//div[@class='ant-table-body']/table/tbody/tr")
	List<WebElement> tableRows;

	String tableRowsXpath = "//div[@class='ant-table-body']/table/tbody/tr";

	@FindBy(xpath = "//button[span[text()='Clear']]")
	WebElement clearButton;

	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchTextBox;

	@FindBy(xpath = "//button[span[@aria-label='search']]")
	WebElement searchIcon;

	@FindBy(xpath = "//button[span[@aria-label='export']]")
	WebElement exportIcon;

	@FindBy(xpath = "//button[span[@aria-label='printer']]")
	WebElement printIcon;

	@FindBy(xpath = "//button[span[@aria-label='setting']]")
	WebElement settingsIcon;

	@FindBy(xpath = "//th[@title='Guest Name']")
	WebElement guestNameColumn;

	@FindBy(xpath = "//span[text()='Status']/ancestor::th")
	WebElement statusColumn;

	@FindBy(xpath = "//span[text()='Call Date']/ancestor::th")
	WebElement callDateColumn;

	@FindBy(xpath = "//span[text()='Call Time']/ancestor::th")
	WebElement callTimeColumn;

	@FindBy(xpath = "//span[text()='Call Status']/ancestor::th")
	WebElement callStatusColumn;

	@FindBy(xpath = "//span[text()='Date']/ancestor::th")
	WebElement dateColumn;

	@FindBy(xpath = "//span[text()='Time']/ancestor::th")
	WebElement timeColumn;

	@FindBy(xpath = "//span[text()='Show']/ancestor::th")
	WebElement showColumn;

	@FindBy(xpath = "//th[@title='Division']")
	WebElement divisionColumn;

	@FindBy(xpath = "//div[@aria-label='Page Size']/div/span[contains(@title,'page')]")
	WebElement numberOfRecordsPerPage;

	@FindBy(xpath = "//button[span[@aria-label='left']]")
	WebElement leftArrow;

	@FindBy(xpath = "//button[span[@aria-label='right']]")
	WebElement rightArrow;

	@FindBy(xpath = "//li[@title='1']")
	WebElement page1;

	@FindBy(xpath = "//span[@class='ant-radio-button ant-radio-button-checked']")
	WebElement Allbookingstab;

	@FindBy(xpath = "//th[@title='Guest']")
	WebElement guestColumn;

	@FindBy(xpath = "//span[text()='Studio']/ancestor::th")
	WebElement studioColumn;

	@FindBy(xpath = "//span[text()='App']/ancestor::th")
	WebElement BookingsAppcolumn;

	@FindBy(xpath = "//span[text()='Topic']/ancestor::th")
	WebElement topicscolumn;

	@FindBy(xpath = "//span[normalize-space()='Reports']")
	WebElement Reportstab;

	@FindBy(xpath = "//span[text()='Company / ORG']/ancestor::th")
	WebElement Companyname;

	@FindBy(xpath = "//span[text()='Job Title']/ancestor::th")
	WebElement Jobtitle;

	@FindBy(xpath = "//span[text()='State']/ancestor::th")
	WebElement State;

	@FindBy(xpath = "//span[text()='CTR']/ancestor::th")
	WebElement CTR;

	@FindBy(xpath = "//span[text()='NBC EMPL']/ancestor::th")
	WebElement NBCorEmpl;

	@FindBy(xpath = "//span[text()='Ethnicity']/ancestor::th")
	WebElement Ethnicity;

	@FindBy(xpath = "//span[text()='SELF-ID']/ancestor::th")
	WebElement SelfId;

	@FindBy(xpath = "//span[text()='Gender']/ancestor::th")
	WebElement Gender;

	@FindBy(xpath = "//span[text()='LGBTQ+']/ancestor::th")
	WebElement LGBTQ;

	@FindBy(xpath = "//span[text()='Disabled']/ancestor::th")
	WebElement Disabled;

	@FindBy(xpath = "//span[text()='Veteran']/ancestor::th")
	WebElement Veteran;

	@FindBy(xpath = "//span[text()='Producer']/ancestor::th")
	WebElement Producer;

	@FindBy(xpath = "//span[text()='Feed Type']/ancestor::th")
	WebElement Feedtype;

	@FindBy(xpath = "//span[text()='Car SVCS']/ancestor::th")
	WebElement Carsvcs;

	@FindBy(xpath = "//tr//td//button")
	List<WebElement> GuestNameColumnValues;

	@FindBy(xpath = "//span[normalize-space()='BOOKED']")
	List<WebElement> Status;

	@FindBy(xpath = "//tr//td[8]")
	List<WebElement> callsShowvalues;

	@FindBy(xpath = "//tr//td[5]")
	List<WebElement> callstatusvalues;

	@FindBy(xpath = "//td[@title='CNBC']")
	List<WebElement> divisionvalues;

	@FindBy(xpath = "//span[@class='ant-input-clear-icon ant-input-clear-icon-has-suffix']")
	WebElement SearchclearIcon;

	@FindBy(xpath = "//tr//td[5]")
	List<WebElement> Topicvalues;

	@FindBy(xpath = "//tr//td[7]")
	List<WebElement> Studiovalues;

	@FindBy(xpath = "//span[normalize-space()='My Bookings']")
	WebElement MyBookingsTab;
	
	//Bookings bookings tab elements
	@FindBy(xpath = "//tr//td[5]")
	List<WebElement> bookingsShowvalues;

	//Booking reports tab elements
	@FindBy(xpath = "//tr//td[3]")
	List<WebElement> Reportsshowvalues;

	@FindBy(xpath = "//tr//td[7]")
	List<WebElement> Reportstopics;

	@FindBy(xpath = "//tr//td[6]")
	List<WebElement> Reportsjobtitle;

	@FindBy(xpath = "//tr//td[8]")
	List<WebElement> Reportsstudiovalues;

	@FindBy(xpath = "//tr//td[18]")
	List<WebElement> Reportsproducername;

	@FindBy(xpath = "//tr//td[9]")
	List<WebElement> Reportsstatename;

	@FindBy(xpath = "//tr//td[3]")
	List<WebElement> Calldate;

	@FindBy(xpath = "//tr//td[4]")
	List<WebElement> Calltime;

	@FindBy(xpath = "//span[@class='ant-tag']")
	WebElement Pendingstatus;

	// Directory Guest Elements
	@FindBy(xpath = "//li[span[text()='Guests']]")
	WebElement guestsTab;

	// Directory Companies Elements
	@FindBy(xpath = "//li[span[text()='Companies']]")
	WebElement companiesTab;

	// Directory Proxies Elements
	@FindBy(xpath = "//li[span[text()='Proxies']]")
	WebElement proxiesTab;

	// Directory Bookers Elements
	@FindBy(xpath = "//li[span[text()='Bookers']]")
	WebElement bookersTab;

	public ReportCenterPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify report center page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyReportCenterPageDisplayed() throws Exception {
		Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
	}

	/**
	 * To select calls/bookings/reports tab in bookings view
	 * 
	 * @param tabName - tab name
	 * @throws Exception
	 */
	public void SelectBookingsTabs(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "CALLS":
				WebAction.click(callsTab);
				Waits.waitForElement(myCallsTab, WAIT_CONDITIONS.CLICKABLE);
				break;
			case "BOOKINGS":
				WebAction.click(bookingsTab);
				Waits.waitForElement(myCallsTab, WAIT_CONDITIONS.CLICKABLE);
				break;
			case "REPORTS":
				WebAction.click(Reportstab);
				break;
			}
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Calls tab is selected by default in bookings
	 * 
	 * @param tabName - tab name CALLS/ALL CALLS
	 * @throws Exception
	 */
	public void verifyCallsTabSelectedByDefault(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "CALLS":
				CommonValidations.verifyAttributeValue(callsTab, "class", "selected",
						"Calls tab is not selected by default in booking view");
				break;
			case "ALL CALLS":
				CommonValidations.verifyAttributeValue(allCalls, "class", "checked",
						"Alls calls is not selected by default in calls tab");
				break;
			}
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify clear button disabled by default
	 * 
	 * @throws Exception
	 */
	public void verifyClearButtonDisabledByDefault() throws Exception {
		try {
			Waits.waitForElement(clearButton, WAIT_CONDITIONS.VISIBLE);
			Assert.assertFalse(WebAction.isEnabled(clearButton), "Clear button is enabled by default");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify global search text box is present
	 * 
	 * @throws Exception
	 */
	public void verifyGlobalSearchTextBoxIsPresent() throws Exception {
		try {
			Assert.assertTrue(WebAction.isDisplayed(searchTextBox), "Global search text box is not present");
			Assert.assertTrue(WebAction.isDisplayed(searchIcon), "Global search icon is not present");
			Waits.waitForElement(searchTextBox, WAIT_CONDITIONS.CLICKABLE);
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Export/Print/Setting icons are enabled
	 * 
	 * @param iconName - Export/Printer/Settings
	 * @throws Exception
	 */
	public void verifyExportPrintAndSettingAreEnabled(String iconName) throws Exception {
		try {
			switch (iconName.toUpperCase()) {
			case "EXPORT":
				Assert.assertTrue(WebAction.isEnabled(exportIcon), "Export icon is disabled");
				Waits.waitForElement(exportIcon, WAIT_CONDITIONS.CLICKABLE);
				break;
			case "PRINTER":
				Assert.assertTrue(WebAction.isEnabled(printIcon), "Printer icon is disabled");
				Waits.waitForElement(printIcon, WAIT_CONDITIONS.CLICKABLE);
				break;
			case "SETTINGS":
				Assert.assertTrue(WebAction.isEnabled(settingsIcon), "Settings icon is disabled");
				Waits.waitForElement(settingsIcon, WAIT_CONDITIONS.CLICKABLE);
				break;
			}
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify column names in Calls tab of booking view
	 * 
	 * @param tableName
	 * @param param     - Data table
	 * @throws Exception
	 */
	public void verifyCallsTableColumns(String tableName, DataTable param) throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
			List<Map<String, String>> columnNames = CucumberUtils.getValuesFromDataTableAsList(param);
			for (int i = 0; i < columnNames.size(); i++) {
				String columnName = columnNames.get(i).get("Column Name");
				switch (columnName.toUpperCase()) {
				case "GUEST NAME":
					Assert.assertTrue(WebAction.isDisplayed(guestNameColumn),
							"Guest Name column is not present in the '" + tableName + "' table");
					break;
				case "STATUS":
					Waits.waitForElement(statusColumn, WAIT_CONDITIONS.VISIBLE);
					Assert.assertTrue(WebAction.isDisplayed(statusColumn),
							"Status column is not present in the '" + tableName + "' table");
					break;
				case "CALL DATE":
					Assert.assertTrue(WebAction.isDisplayed(callDateColumn),
							"Call Date column is not present in the '" + tableName + "' table");
					break;
				case "CALL TIME":
					Assert.assertTrue(WebAction.isDisplayed(callTimeColumn),
							"Call Time column is not present in the '" + tableName + "' table");
					break;
				case "CALL STATUS":
					WebAction.scrollIntoView(callStatusColumn);
					Assert.assertTrue(WebAction.isDisplayed(callStatusColumn),
							"Call Status column is not present in the '" + tableName + "' table");
					break;
				case "DATE":
					WebAction.scrollIntoView(dateColumn);
					Assert.assertTrue(WebAction.isDisplayed(dateColumn),
							"Date column is not present in the '" + tableName + "' table");
					break;
				case "TIME":
					WebAction.scrollIntoView(timeColumn);
					Assert.assertTrue(WebAction.isDisplayed(timeColumn),
							"Time column is not present in the '" + tableName + "' table");
					break;
				case "SHOW":
					WebAction.scrollIntoView(showColumn);
					Assert.assertTrue(WebAction.isDisplayed(showColumn),
							"Show column is not present in the '" + tableName + "' table");
					break;
				case "DIVISION":
					WebAction.scrollIntoView(divisionColumn);
					Assert.assertTrue(WebAction.isDisplayed(divisionColumn),
							"Division column is not present in the '" + tableName + "' table");
					break;
				case "GUEST":
					WebAction.scrollIntoView(guestColumn);
					Assert.assertTrue(WebAction.isDisplayed(guestColumn),
							"Guest column is not present in the '" + tableName + "' table");
					break;

				case "STUDIO":
					WebAction.scrollIntoView(studioColumn);
					Assert.assertTrue(WebAction.isDisplayed(studioColumn),
							"studio column is not present in the '" + tableName + "' table");
					break;

				case "App":
					WebAction.scrollIntoView(BookingsAppcolumn);
					Assert.assertTrue(WebAction.isDisplayed(BookingsAppcolumn),
							"Booking App column is not present in the '" + tableName + "' table");
					break;

				case "TOPICS":
					WebAction.scrollIntoView(topicscolumn);
					Assert.assertTrue(WebAction.isDisplayed(topicscolumn),
							"topics column is not present in the '" + tableName + "' table");
					break;

				case "COMPANY/ORG":
					WebAction.scrollIntoView(Companyname);
					Assert.assertTrue(WebAction.isDisplayed(Companyname),
							"Company column is not present in the '" + tableName + "' table");
					break;

				case "JOB TITLE":
					WebAction.scrollIntoView(Jobtitle);
					Assert.assertTrue(WebAction.isDisplayed(Jobtitle),
							"Jobtitle column is not present in the '" + tableName + "' table");
					break;

				case "STATE":
					WebAction.scrollIntoView(State);
					Assert.assertTrue(WebAction.isDisplayed(State),
							"State column is not present in the '" + tableName + "' table");
					break;

				case "CTR":
					WebAction.scrollIntoView(CTR);
					Assert.assertTrue(WebAction.isDisplayed(CTR),
							"CTR column is not present in the '" + tableName + "' table");
					break;

				case "NBC EMPL":
					WebAction.scrollIntoView(NBCorEmpl);
					Assert.assertTrue(WebAction.isDisplayed(NBCorEmpl),
							"NBC or Empl column is not present in the '" + tableName + "' table");
					break;

				case "ETHNICITY":
					WebAction.scrollIntoView(Ethnicity);
					Assert.assertTrue(WebAction.isDisplayed(Ethnicity),
							"Ethnicity column is not present in the '" + tableName + "' table");
					break;

				case "SELF-ID":
					WebAction.scrollIntoView(SelfId);
					Assert.assertTrue(WebAction.isDisplayed(SelfId),
							"SelfId column is not present in the '" + tableName + "' table");
					break;

				case "GENDER":
					WebAction.scrollIntoView(Gender);
					Assert.assertTrue(WebAction.isDisplayed(Gender),
							"Gender column is not present in the '" + tableName + "' table");
					break;

				case "LGBTQ":
					WebAction.scrollIntoView(LGBTQ);
					Assert.assertTrue(WebAction.isDisplayed(LGBTQ),
							"LGBTQ column is not present in the '" + tableName + "' table");
					break;

				case "DISABLED":
					WebAction.scrollIntoView(Disabled);
					Assert.assertTrue(WebAction.isDisplayed(Disabled),
							"Disabled column is not present in the '" + tableName + "' table");
					break;

				case "VETERAN":
					WebAction.scrollIntoView(Veteran);
					Assert.assertTrue(WebAction.isDisplayed(Veteran),
							"Veteran column is not present in the '" + tableName + "' table");
					break;

				case "PRODUCER":
					WebAction.scrollIntoView(Producer);
					Assert.assertTrue(WebAction.isDisplayed(Producer),
							"Producer column is not present in the '" + tableName + "' table");
					break;

				case "FEED TYPE":
					WebAction.scrollIntoView(Feedtype);
					Assert.assertTrue(WebAction.isDisplayed(Feedtype),
							"Feedtype column is not present in the '" + tableName + "' table");
					break;

				case "CAR SVCS":
					WebAction.scrollIntoView(Carsvcs);
					Assert.assertTrue(WebAction.isDisplayed(Carsvcs),
							"Carsvcs column is not present in the '" + tableName + "' table");
					break;
				}
			}
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify number of records per page is 15/page
	 * 
	 * @throws Exception
	 */
	public void verifyNumberRecordsPerPage(String recordsPerPageselecter) throws Exception {
		try {
			if (recordsPerPageselecter.equalsIgnoreCase("15/page"))
				CommonValidations.verifyAttributeValue(numberOfRecordsPerPage, "title", "15 / page",
						"Number of records per page is not 15/page");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify page 1 is selected by default
	 * 
	 * @throws Exception
	 */
	public void verifyPageisSelected() throws Exception {
		try {
			CommonValidations.verifyAttributeValue(page1, "class", "active", "Page 1 is not selected by default");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify left arrow is disabled
	 * 
	 * @throws Exception
	 */
	public void verifyLeftArrowIsDisabled() throws Exception {
		try {
			Assert.assertFalse(WebAction.isEnabled(leftArrow), "Left arrow is enabled by default");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify right arrow is disabled
	 * 
	 * @throws Exception
	 */
	public void verifyRightArrowIsEnabled() throws Exception {
		try {
			Assert.assertTrue(WebAction.isEnabled(rightArrow), "Right arrow is disabled by default");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click tabs
	 * 
	 * @throws Exception
	 */
	public void clickTabs(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "MY CALLS":
				WebAction.click(myCallsTab);
				break;
			case "ALL CALLS":
				WebAction.click(allCalls);
				break;
			case "BOOKINGS":
				WebAction.click(bookingsTab);
				Waits.waitForElement(myCallsTab, WAIT_CONDITIONS.CLICKABLE);
				break;
			case "MY BOOKINGS":
				WebAction.click(MyBookingsTab);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				break;

			case "REPORTS":
				WebAction.click(Reportstab);
				break;

			}
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyBookingsTabSelectedByDefault(String tabName) throws Exception {
		try {
			switch (tabName.toUpperCase()) {
			case "All Bookings":
				CommonValidations.verifyAttributeValue(Allbookingstab, "class",
						"ant-radio-button ant-radio-button-checked",
						"All tab is not selected by default in booking view");
				break;

			}
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void Validatesearchinbookingspage(String searchtype, String tablename) throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
			if (searchtype.equalsIgnoreCase("Guest name")) {
				String expectedguestname = WebAction.getText(GuestNameColumnValues.get(0));
				System.out.println(expectedguestname);
				searchTextBox.sendKeys(expectedguestname);
				searchIcon.click();
				searchIcon.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(GuestNameColumnValues.get(0), expectedguestname,
						"GUEST NAMES ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equalsIgnoreCase("Division")) {
				String expectedDivsion = WebAction.getText(divisionvalues.get(0));
				System.out.println(expectedDivsion);
				WebAction.sendKeys(searchTextBox, expectedDivsion);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(divisionvalues.get(0), expectedDivsion, "DIVISION NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equalsIgnoreCase("Status")) {
				String expectedStatus = WebAction.getText(Status.get(0));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Status.get(0), expectedStatus, "STATUS NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equalsIgnoreCase("CallStatus")) {
				String expectedStatus = WebAction.getText(callstatusvalues.get(1));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(callstatusvalues.get(1), expectedStatus, "CALL STATUS NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equalsIgnoreCase("Show")) {
				WebElement showValueElement = null;
				if(tablename.toUpperCase().contains("CALLS"))
					showValueElement = callsShowvalues.get(1);
				else if(tablename.toUpperCase().contains("BOOKINGS"))
					showValueElement = bookingsShowvalues.get(1);
				else
					showValueElement = Reportsshowvalues.get(1);
				String expectedShow = WebAction.getText(showValueElement);
				System.out.println(expectedShow);
				searchTextBox.sendKeys(expectedShow);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(showValueElement, expectedShow, "SHOW NAME NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equalsIgnoreCase("Guest")) {
				String expectedguestname = WebAction.getText(GuestNameColumnValues.get(0));
				System.out.println(expectedguestname);
				searchTextBox.sendKeys(expectedguestname);
				searchIcon.click();
				searchIcon.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(GuestNameColumnValues.get(0), expectedguestname, "GUESTS ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equalsIgnoreCase("Topic")) {
				String expectedStatus = WebAction.getText(Topicvalues.get(1));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Topicvalues.get(1), expectedStatus, "TOPIC NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equalsIgnoreCase("Studio")) {
				String expectedStatus = WebAction.getText(Studiovalues.get(1));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Studiovalues.get(1), expectedStatus, "STUDIO NAMES ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equals("show")) {
				String expectedStatus = WebAction.getText(Reportsshowvalues.get(0));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Reportsshowvalues.get(0), expectedStatus,
						"SHOW NAMES ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equals("Topics")) {
				String expectedStatus = WebAction.getText(Reportstopics.get(1));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Reportstopics.get(1), expectedStatus, " ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equals("studio")) {
				String expectedStatus = WebAction.getText(Reportsstudiovalues.get(1));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Reportsstudiovalues.get(1), expectedStatus, " ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equals("Job title")) {
				WebAction.scrollIntoView(Reportsjobtitle.get(1));
				String expectedStatus = WebAction.getText(Reportsjobtitle.get(2));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Reportsjobtitle.get(1), expectedStatus, " ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equals("State")) {
				String expectedStatus = WebAction.getText(Reportsstatename.get(1));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Reportsstatename.get(1), expectedStatus,
						"STATE MANES ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equals("Producer name")) {
				String expectedStatus = WebAction.getText(Reportsproducername.get(1));
				System.out.println(expectedStatus);
				searchTextBox.sendKeys(expectedStatus);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
				CommonValidations.verifyTextValue(Reportsproducername.get(1), expectedStatus,
						" PRODUCER NAMES ARE NOT MATCHED");
				SearchclearIcon.click();
			}

			else if (searchtype.equals("Created Guest name")) {
				String expectedProfileName = GuestProfileConstants.getFullNameWithoutTitleAndSuffix();
				System.out.println(expectedProfileName);
				searchTextBox.sendKeys(expectedProfileName);
				searchIcon.click();
				searchTextBox.sendKeys(Keys.ENTER);
				Waits.waitUntilElementSizeGreater(By.xpath(tableRowsXpath), 0);
			}

		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyplacedCallsTableColumns(String tableName, DataTable param) throws Exception {
		try {
			List<Map<String, String>> columnNames = CucumberUtils.getValuesFromDataTableAsList(param);
			for (int i = 0; i < columnNames.size(); i++) {
				String columnName = columnNames.get(i).get("Column Name");
				switch (columnName.toUpperCase()) {
				case "CALL DATE":
					String expectedcalldate = BookingGuestConstants.getCallOutDate();
					System.out.println(expectedcalldate);
					CommonValidations.verifyTextValue(Calldate.get(1), expectedcalldate, "CALL DATE NOT MATCHED");
					break;

				case "CALL TIME":
					String expectedcalltime = BookingGuestConstants.getCallOutTime();
					String splitexpectedcalltime[] = expectedcalltime.split(":");
					String Expectedtimeinhour = splitexpectedcalltime[0];
					String Expectedtimeinminutes = splitexpectedcalltime[1];
					System.out.println(Expectedtimeinhour);
					System.out.println(Expectedtimeinminutes);
					String splitActualcalltime[] = Calltime.get(1).getText().split(":");
					String Actualcalltimeinhour = splitexpectedcalltime[0];
					String Actualcalltimeinminutes = splitexpectedcalltime[1];
					System.out.println(Actualcalltimeinhour);
					System.out.println(Actualcalltimeinminutes);
					assertEquals(Expectedtimeinhour, Actualcalltimeinhour);
					assertEquals(Expectedtimeinminutes, Actualcalltimeinminutes);
					break;

				case "CALL STATUS":
					String expectedcallStatus = BookingGuestConstants.getCallStatus();
					System.out.println(expectedcallStatus);
					CommonValidations.verifyTextValue(callstatusvalues.get(1), expectedcallStatus,
							"CALL STATUS NOT MATCHED");
					break;

				case "SHOW":
					String expectedshowname = BookingGuestConstants.getShowName();
					System.out.println(expectedshowname);
					CommonValidations.verifyTextValue(callsShowvalues.get(1), expectedshowname, "SHOW NAMES NOT MATCHED");
					break;

				case "STATUS":
					String defaulttag = "PENDING";
					CommonValidations.verifyTextValue(Pendingstatus, defaulttag, "SHOW NAMES NOT MATCHED");
					break;

				}
			}

		} catch (Exception | Error e) {

			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify given tab is selected by default in directory
	 * 
	 * @param tabName
	 * @throws Exception
	 */
	public void verifyDefaultSelectedTabInDirectory(String tabName) throws Exception {
		try {
			Waits.waitForElement(page1, WAIT_CONDITIONS.CLICKABLE);
			switch (tabName.toUpperCase()) {
			case "GUESTS":
				Waits.waitForElement(guestsTab, WAIT_CONDITIONS.CLICKABLE);
				CommonValidations.verifyColorOfElement(guestsTab, "color", "Blue");
				break;
			case "COMPANIES":
				Waits.waitForElement(companiesTab, WAIT_CONDITIONS.CLICKABLE);
				CommonValidations.verifyColorOfElement(companiesTab, "color", "Blue");
				break;
			case "PROXIES":
				Waits.waitForElement(proxiesTab, WAIT_CONDITIONS.CLICKABLE);
				CommonValidations.verifyColorOfElement(proxiesTab, "color", "Blue");
				break;
			case "BOOKERS":
				Waits.waitForElement(bookersTab, WAIT_CONDITIONS.CLICKABLE);
				CommonValidations.verifyColorOfElement(bookersTab, "color", "Blue");
				break;
			}
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify search text is prefilled
	 * 
	 * @throws Exception
	 */
	public void verifySearchTextBoxPrefilled(String profileType) throws Exception {
		String searchText = "";
		try {
			if (profileType.equalsIgnoreCase("PROXY"))
				searchText = ProxyConstants.getDisplayName();
			else if (profileType.equalsIgnoreCase("GUEST"))
				searchText = GuestProfileConstants.getDisplayName();
			else if (profileType.equalsIgnoreCase("COMPANY"))
				searchText = CompanyProfileConstants.getCompanyName();
			else
				searchText = "";
			CommonValidations.verifyAttributeValue(searchTextBox, "value", searchText,
					"Search text '" + searchText + "' is not present in report center directory guest view");
		} catch (Exception | Error e) {
			e.printStackTrace();
			throw e;
		}
	}

}

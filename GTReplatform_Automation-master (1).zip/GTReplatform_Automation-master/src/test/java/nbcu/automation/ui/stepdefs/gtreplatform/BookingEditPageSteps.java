package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.BookingEditPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class BookingEditPageSteps {

	BookingEditPage bookingEditPage = new BookingEditPage();

	@Given("verify booking edit page is loaded")
	public void verifyBookingEditPageLoaded() throws Exception {
		bookingEditPage.verifyBookingEditPageLoaded();
	}

	@Then("user click add booking icon")
	public void verifyBookingFormIcon() throws Exception {
		bookingEditPage.clickBookingIcon();
	}

	@And("verify guest search RH drawer opened with search field")
	public void verifyingRHDrawer() throws Exception {
		bookingEditPage.verifyGuestRhDrawer();
	}

	@When("user searches and add guest profile")
	public void searchGuestProfile(DataTable dataTable) throws Exception {
		bookingEditPage.searchAndAddGuestProfile(CucumberUtils.getValuesFromDataTable(dataTable, "Guest Name"));
	}

	@And("verify guest RH drawer is closed")
	public void verifyGuestRhDrawerClosed() throws Exception {
		bookingEditPage.verifyGuestRhDrawerClosed();
	}

	@And("verify guest profile {string} is displayed in the header of booking edit page")
	public void verifyGuestHeaderDetails(String fieldName) {
		bookingEditPage.verifyGuestProfileDetailsInHeader(fieldName);
	}

	@And("verify Form tab is selected by default")
	public void verifyFormTabSelectedByDefault() {
		bookingEditPage.verifyFormTabSelectedByDefault();
	}

	@Then("verify event type drop down is displayed with {string} default value")
	public void verifyEventTypeDefaultValue(String defaultEventType) throws Exception {
		bookingEditPage.verifyEventTypeDefaultValue(defaultEventType);
	}

	@Then("verify TopicsOrSegments drop down is greyed out by default")
	public void verifyTopicsOrSegmentsDisableByDefault() throws Exception {
		bookingEditPage.verifyTopicsOrSegmentsFieldDisableByDefault();
	}

	@And("user updates show details in form tab")
	@When("user fills show details in form tab")
	public void selectShowName(DataTable dataTable) throws Exception {
		bookingEditPage.fillShowDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Is Duplicate Booking"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show Name"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Event Type"));
	}

	//@And("user clicks New (topic|segment) button")
	@And("user clicks New topic button")
	public void clickNewTopicButton() throws Exception {
		bookingEditPage.clickNewTopicButton();
	}

	//@And("user (fills|updates) (topic|segment) details in (topic|segment) RH drawer")
	@And("user fills topic details in topic RH drawer")
	@And("user fills segment details in segment RH drawer")
	public void addTopic(DataTable dataTable) throws Exception {
		bookingEditPage.addTopic(CucumberUtils.getValuesFromDataTable(dataTable, "Is Duplicate Booking"), CucumberUtils.getValuesFromDataTable(dataTable, "Topic Name"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "End Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Topic Notes"));
	}

	//@And("user click on Add (Topic|Segment) button in (topic|segment) RH drawer")
	@And("user click on Add Topic button in topic RH drawer")
	@And("user click on Add Segment button in segment RH drawer")
	public void clickAddTopicInRhDrawer() throws Exception {
		bookingEditPage.clickAddTopicInRhDrawer();
	}

	//@And("verify (topic|segment) is created successfully and placed in parking lot")
	@And("verify topic is created successfully and placed in parking lot")
	@And("verify segment is created successfully and placed in parking lot")
	public void verifyTopicsAddedSuccessfully() throws Exception {
		bookingEditPage.verifyTopicAddedSuccessfully();
	}

	@And("verify newly added topic is displayed in Topics or segments dropdown")
	public void verifyNewAddedTopicInDropDown() throws Exception {
		bookingEditPage.verifyNewlyAddedTopicInDropDown();
	}

	//@And("select (topic|segment) from topics or segments drop down")
	@And("select segment from topics or segments drop down")
	public void verifyNewAddedTopicInDropDown(DataTable dataTable) throws Exception {
		bookingEditPage.selectSegement(CucumberUtils.getValuesFromDataTable(dataTable, "Segment Name"));
	}

	@Then("verify below form types are displayed under booking type")
	public void bookingTypeOptions(DataTable params) {
		bookingEditPage.verifyFromTypesDisplayed(params);
	}

	@Then("verify {string} field is disabled and prefilled with booker name")
	public void verifyBookedByFieldDisabled(String fieldName) throws Exception {
		if (fieldName.equalsIgnoreCase("BOOKED BY"))
			bookingEditPage.verifyBookedByFieldDisabled();
		else if (fieldName.equalsIgnoreCase("CALLED BY"))
			bookingEditPage.verifyCalledByFieldDisabled();
	}

	@Then("verify {string} date and time fields are disabled and prefilled with current date and time")
	public void verifyBookingDateAndTimePrefilled(String callOutOrBooking) throws Exception {
		bookingEditPage.verifyCallOutOrBookingDateAndTimePrefilled(callOutOrBooking);
	}

	@When("user updates {string} details in booking form")
	@And("user fills {string} details in booking form")
	public void fillBookingDetails(String sectionName, DataTable dataTable) throws Exception {
		if (sectionName.equalsIgnoreCase("BOOKING"))
			bookingEditPage.fillBookingDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Booked For"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Technical Notes"));
		else if (sectionName.equalsIgnoreCase("CALL OUT"))
			bookingEditPage.fillCallOutDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Called For"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Call Out Status"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Call Out Notes"));
		else if (sectionName.equalsIgnoreCase("STUDIO"))
			bookingEditPage.fillStudioDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Studio Type"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Studio"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Studio State"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Other Studio"));
	}

	@And("user adds email address in alerts field of email communication section")
	public void addEmailAddress(DataTable dataTable) throws Exception {
		bookingEditPage.fillEmailAddressInAlert(dataTable);
	}
	
	@And("user adds custom email notification")
	public void addCustomEmailNotification(DataTable dataTable) throws Exception {
		bookingEditPage.selectCustomEmailNotification(dataTable);
	}

	@And("user clicks {string} button")
	public void clickButton(String buttonType) throws Exception {
		bookingEditPage.clickbutton(buttonType);
	}

	@And("verify {string} popup is displayed")
	public void verifyBookedPlacedPopupDisplayed(String expectedMessgae) throws Exception {
		bookingEditPage.verifySuccessPopup(expectedMessgae);
	}

	@And("click {string} in success popup")
	public void clickButtonInPopup(String buttonType) throws Exception {
		bookingEditPage.clickButtonInPopup(buttonType);
	}

	@When("user fill recurring booking details")
	public void fillRecurringDetails(DataTable dataTable) throws Exception {
		bookingEditPage.fillRecurringBookingDetails(CucumberUtils.getValuesFromDataTable(dataTable, "End Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Days"));
	}

	@Then("verify duplicate booking popup is displayed")
	public void verifyDuplicateBookingPopupDisplayed() throws Exception {
		bookingEditPage.verifyDuplicateBookingPopupDisplayed();
	}

	@And("verify existing booking details of guest profile is displayed in duplicate booking popup")
	public void verifyExistingBookingDetails(DataTable dataTable) throws Exception {
		bookingEditPage.verifyDuplicateBookingDetails(
				CucumberUtils.getValuesFromDataTable(dataTable, "Duplicate Booking Popup Title"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Duplicate booking Popup Disclaimer"));
	}

	@And("verify below buttons are displayed in duplicate booking popup")
	public void verifyButtonsInDuplicateBookingPopUp(DataTable dataTable) throws Exception {
		bookingEditPage.verifyButtonsInDuplicateBookingPopup(dataTable);
	}

	@When("user clicks {string} button in duplicate booking popup")
	public void clickButtonInDuplicateBookingPopup(String buttonName) throws Exception {
		bookingEditPage.clickButtonInDuplicateBookingPopup(buttonName);
	}

	@Then("verify exclude info message is displayed in booking edit page")
	public void verifyExcludeInfoMessage(DataTable dataTable) throws Exception {
		bookingEditPage
				.verifyExcludeInfoMessage(CucumberUtils.getValuesFromDataTable(dataTable, "Exclude Info Message"));
	}

}

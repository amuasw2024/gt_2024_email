package nbcu.automation.ui.pages.ncx;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.ncx.NCXProfileConstants;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class AdminPage {

	String usersListXpath = "//tbody/tr[@class='ant-table-row ng-star-inserted']";

	@FindBy(xpath = "//input[@placeholder='Search Users here...']")
	WebElement searchTextBox;

	String editButtonXpath = "//td[span[contains(text(),'<<SSO>>')]]/following-sibling::td[@class='editButtons']/a[text()='Edit']";

	@FindBy(xpath = "//div[contains(text(),'Edit User')]")
	WebElement editUserPopupTitle;

	@FindBy(xpath = "//input[@placeholder='First Name']")
	WebElement userFirstName;

	@FindBy(xpath = "//input[@placeholder='Last Name']")
	WebElement userLastName;

	@FindBy(xpath = "//input[@placeholder='Email Id']")
	WebElement userEmailId;

	@FindBy(xpath = "//input[@placeholder='Job Title']")
	WebElement userJobTitle;

	@FindBy(xpath = "//input[@placeholder='Organization']")
	WebElement userOrganization;

	@FindBy(xpath = "//input[@placeholder='Parent Organization Id']")
	WebElement userParentOrgId;
	
	@FindBy(xpath = "//div[div[contains(text(),'NDI Account Status:')]]/following::div[1]/button[span[text()='Cancel']]")
	WebElement editUserPopupTitleCancelButton;

	public AdminPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify admin page is loaded
	 * 
	 * @throws Exception
	 */
	public void verifyAdminPageLoaded() throws Exception {
		try {
			Waits.waitUntilElementSizeGreater(By.xpath(usersListXpath), 0);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To search SSO
	 * 
	 * @throws Exception
	 */
	public void searchSso() throws Exception {
		try {
			WebAction.sendKeys_WithTimeGap(searchTextBox, ConfigFileReader.getProperty("gt-admin-username"));
			Waits.waitUntilElementSizeGreater(By.xpath(usersListXpath), 0);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click edit link
	 * 
	 * @throws Exception
	 */
	public void clickEditLink() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			WebAction.click(driver.findElement(
					By.xpath(editButtonXpath.replace("<<SSO>>", ConfigFileReader.getProperty("gt-admin-username")))));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify edit user popup is displayed
	 * 
	 * @throws Exception
	 */
	public void verifyEditUserPopup() throws Exception {
		try {
			Waits.waitForElement(editUserPopupTitle, WAIT_CONDITIONS.VISIBLE);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * To fetch user profile details and store in constants
	 * @throws Exception
	 */
	public void fetchUserDetails() throws Exception {
		try {
			String expectedFirstName = WebAction.getAttribute(userFirstName, "ng-reflect-model");
			NCXProfileConstants.setFirstName(expectedFirstName);
			
			String expectedLastName = WebAction.getAttribute(userLastName, "ng-reflect-model");
			NCXProfileConstants.setLastName(expectedLastName);
			
			String expectedEmailId = WebAction.getAttribute(userEmailId, "ng-reflect-model");
			NCXProfileConstants.setEmailId(expectedEmailId);
			
			String expectedJobTitle = WebAction.getAttribute(userJobTitle, "ng-reflect-model");
			NCXProfileConstants.setJobTitle(expectedJobTitle);
			
			String expectedOrganization = WebAction.getAttribute(userOrganization, "ng-reflect-model");
			String expectedParentOrgId = WebAction.getAttribute(userParentOrgId, "ng-reflect-model");
			NCXProfileConstants.setBusinessUnit(expectedParentOrgId+" - "+expectedOrganization);
			
			WebAction.click(editUserPopupTitleCancelButton);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}

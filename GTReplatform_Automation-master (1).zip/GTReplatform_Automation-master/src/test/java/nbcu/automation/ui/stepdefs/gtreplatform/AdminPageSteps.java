package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.AdminPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class AdminPageSteps {

	AdminPage adminPage = new AdminPage();

	@Given("verify admin page is loaded")
	public void openGtApp() throws Exception {
		adminPage.verifyAdminPageLoaded();
	}

	@Given("verify {string} tab is loaded in admin page")
	public void verifyTabLoaded(String tabName) throws Exception {
		adminPage.verifyTabLoaded(tabName);
		adminPage.verifyAdminPageLoaded();
	}

	@Given("user selects {string} tab in admin page")
	public void loginIntoGtApp(String tabName) throws Exception {
		adminPage.clickTab(tabName);
	}

	@Given("user clicks {string} {string} icon")
	public void loginIntoGtApp(String iconName, String tabName) throws Exception {
		adminPage.clickLink(iconName);
	}

	@Given("verify {string} pop up is displayed")
	public void verifyPopUpDisplayed(String popUpName) throws Exception {
		if (popUpName.equalsIgnoreCase("SHOW"))
			adminPage.verifyShowsPopUpDisplayed();
		else if (popUpName.equalsIgnoreCase("SCHEDULE"))
			adminPage.verifySchedulePopUpDisplayed();
		else if (popUpName.equalsIgnoreCase("ALERTS"))
			adminPage.verifyAlertPopUpDisplayed();
		else if (popUpName.equalsIgnoreCase("CAR SERVICES"))
			adminPage.verifyCarServicesPopUpDisplayed();
	}

	@When("user fills {string} details in {string} popup")
	public void fillDetails(String tabName, String popUpName, DataTable dataTable) throws Exception {
		if (tabName.equalsIgnoreCase("SHOW"))
			adminPage.fillShowDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Show Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "OMS Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Exclude From Reports"));
		else if (tabName.equalsIgnoreCase("ALERTS"))
			adminPage.fillAlertDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Time Interval"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Alert Email"));
		else if (tabName.equalsIgnoreCase("CAR SERVICES"))
			adminPage.fillCarServicesDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Phone Number"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Country"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Address Line1"),
					CucumberUtils.getValuesFromDataTable(dataTable, "City"),
					CucumberUtils.getValuesFromDataTable(dataTable, "State"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Zip Code"));

	}

	@And("user clicks {string} button in {string} popup")
	public void clickButton(String buttonName, String popUpName) throws Exception {
		adminPage.clickButton(buttonName, popUpName);
	}

	@And("user searches {string} in the table")
	public void searchDataInTable(String text) throws Exception {
		adminPage.searchInTable(text);
	}

	@Then("verify added {string} is present in the table")
	public void verifyNewEntryAdded(String tabName) throws Exception {
		if (tabName.equalsIgnoreCase("SHOW"))
			adminPage.verifyShowPresentInTable();
		else if (tabName.equalsIgnoreCase("DIVISION"))
			adminPage.verifyDivisionPresentInTable();
		else if(tabName.equalsIgnoreCase("CAR SERVICES"))
			adminPage.verifyCarServicesPresentInTable();
	}

	@When("user clicks {string} icon of {string}")
	public void verifyNewEntryAdded(String iconName, String tabName) throws Exception {
		if (tabName.equalsIgnoreCase("SHOW"))
			adminPage.clickScheduleOrSpecials(iconName);
	}

	@When("user adds {string} to the show")
	public void addScheduleOrSpecials(String scheduleOrSpecials, DataTable dataTable) throws Exception {
		if (scheduleOrSpecials.equalsIgnoreCase("SCHEDULE"))
			adminPage.scheduleShow(CucumberUtils.getValuesFromDataTable(dataTable, "Days"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Start Time"),
					CucumberUtils.getValuesFromDataTable(dataTable, "End Time"));
	}

	@And("verify {string} is updated for show")
	public void verifyScheduleOrSpecialUpdated(String scheduleOrSpecial) throws Exception {
		if (scheduleOrSpecial.equalsIgnoreCase("SCHEDULE"))
			adminPage.verifyScheduleUpdatedForShow();
	}

	@And("verify confirm deletion popup is displayed")
	public void verifyConfirmDeletionPopup(DataTable dataTable) throws Exception {
		adminPage.verifyDeleteConfirmationPopUpDisplayed(CucumberUtils.getValuesFromDataTable(dataTable, "Content"));
	}

	@And("verify {string} is deleted from table")
	public void verifyRecordDeleted(String tabName) throws Exception {
		if (tabName.equalsIgnoreCase("SHOW"))
			adminPage.verifyShowIsDeleted();
	}

	@And("user clicks {string} link of {string} alert")
	public void clickEditOrClearLink(String linkName, String division) throws Exception {
		adminPage.clickEditOrClickLinkOfDivision(linkName, division);
	}

	@Then("verify {string} is updated for {string} division")
	public void verifyAlertUpdated(String sectionName, String division) throws Exception {
		if (sectionName.equalsIgnoreCase("ALERTS"))
			adminPage.verifyAlertUpdatedForDivision(division);
	}
}

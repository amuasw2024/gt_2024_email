package nbcu.automation.ui.stepdefs.gtreplatform;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.gtreplatform.GuestProfileEditPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class GuestProfileEditPageSteps {

	GuestProfileEditPage guestProfilePage = new GuestProfileEditPage();

	@Then("verify Guest profile edit page is loaded")
	public void verifyGuestProfilePageLoaded() throws Exception {
		guestProfilePage.verifyGuestProfileEditPageDisplayed();
	}

	@Given("user opens {string} tab of guest profile")
	public void selectTab(String tabType) throws Exception {
		guestProfilePage.openBasicOrJobInfoTab(tabType);
	}

//@Given("user (fills|updates) {string} details in background section of guest profile")
	@Given("user fills {string} details in background section of guest profile")
	public void fillGuestProfileBackGroundDetails(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "DISPLAY NAME":
			guestProfilePage.fillDisplayNamedetails(CucumberUtils.getValuesFromDataTable(dataTable, "Display Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Pronunciation"));
			break;
		case "NAME":
			guestProfilePage.fillNamedetails(CucumberUtils.getValuesFromDataTable(dataTable, "Title"),
					CucumberUtils.getValuesFromDataTable(dataTable, "First Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Middle Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Last Name"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Suffix"));
			break;
		case "TICKER":
			guestProfilePage.fillTickerDetails(dataTable);
			break;
		case "DEMOGRAPHICS":
			guestProfilePage.fillDemographicsDetail(CucumberUtils.getValuesFromDataTable(dataTable, "Self Identify"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Gender"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Ethnicity"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Other"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Languages"));
			break;
		case "NBC EMPLOYEE":
			guestProfilePage.fillNbcEmployeeDetails(CucumberUtils.getValuesFromDataTable(dataTable, "NBC Employee"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Exclude from reports"));
			break;
		case "CONTRIBUTOR":
			guestProfilePage.fillContributorDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Contributor"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Division"));
			break;
		case "EXPERTISE":
			guestProfilePage.fillExpertiseDetails(dataTable);
			break;
		case "BIOGRAPHY":
			guestProfilePage.fillBiographyDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Biography"));
			break;
		}
	}

	//@Given("user (fills|updates) {string} details in contact info section of guest profile")
	@Given("user fills {string} details in contact info section of guest profile")
	public void fillGuestProfileContactInfoDetails(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "PHONE":
			guestProfilePage.fillPhoneContactDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Office"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Mobile"),
					CucumberUtils.getValuesFromDataTable(dataTable, "1-Phone"),
					CucumberUtils.getValuesFromDataTable(dataTable, "2-Phone"));
			break;
		case "EMAIL":
			guestProfilePage.fillEmailContactDetails(CucumberUtils.getValuesFromDataTable(dataTable, "1-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "2-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "3-Email"),
					CucumberUtils.getValuesFromDataTable(dataTable, "4-Email"));
			break;
		case "OTHER":
			guestProfilePage.fillOtherContactDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Twitter"),
					CucumberUtils.getValuesFromDataTable(dataTable, "LinkedIn"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Video"),
					CucumberUtils.getValuesFromDataTable(dataTable, "WebSite"));
			break;
		case "ADDRESS":
			guestProfilePage.fillAdrressDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Address-1"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Address-2"),
					CucumberUtils.getValuesFromDataTable(dataTable, "City"),
					CucumberUtils.getValuesFromDataTable(dataTable, "State"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Zip"),
					CucumberUtils.getValuesFromDataTable(dataTable, "Country"));
			break;
		case "ALERTS":
			guestProfilePage.fillAlertDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Alert"));
			break;
		}
	}

	//@Given("user (selects|updates) primary {string} contact of guest profile")
	@Given("user selects primary {string} contact of guest profile")
	public void selectPrimaryContact(String sectionName, DataTable dataTable) throws Exception {
		switch (sectionName.toUpperCase()) {
		case "PHONE":
			guestProfilePage
					.selectPrimaryPhoneContact(CucumberUtils.getValuesFromDataTable(dataTable, "Primary Phone"));
			break;
		case "EMAIL":
			guestProfilePage
					.selectPrimaryEmailContact(CucumberUtils.getValuesFromDataTable(dataTable, "Primary Email"));
			break;
		case "OTHER":
			guestProfilePage
					.selectPrimaryOtherContact(CucumberUtils.getValuesFromDataTable(dataTable, "Primary Other"));
			break;
		}
	}

	@Given("user add additional contacts to guest profile")
	public void addAdditionalContacts(DataTable dataTable) throws Exception {
		guestProfilePage.addAdditionalContact(dataTable);
	}

	@Given("user adds job info details for guest profile")
	public void addJobInfo(DataTable dataTable) throws Exception {
		guestProfilePage.addJob(dataTable);
	}

	@Given("user clicks {string} icon in guest profile")
	public void addJobInfo(String buttonType) throws Exception {
		guestProfilePage.clickButton(buttonType);
	}

	@Then("verify deactivate account confirmation pop up is displayed")
	public void verifyDeactivateAccountDisplayed(DataTable dataTable) throws Exception {
		guestProfilePage.verifyDeActivateAccountPopup(
				CucumberUtils.getValuesFromDataTable(dataTable, "Deactivate Account popup message"));
	}

	@When("user clicks on {string} in deactivate account confirmation pop up")
	public void clickButtonOnPopUp(String buttonType) throws Exception {
		guestProfilePage.clickButtonOnPopUp(buttonType);
	}
}

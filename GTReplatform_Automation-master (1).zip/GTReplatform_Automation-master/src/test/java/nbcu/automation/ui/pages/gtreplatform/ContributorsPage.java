package nbcu.automation.ui.pages.gtreplatform;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.gtreplatform.ContributorConstants;
import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;

public class ContributorsPage {

	@FindBy(xpath = "//div[@data-trigger='profile-dropdown']")
	WebElement profileMenu;

	@FindBy(xpath = "//span[@class='ant-select-selection-item']")
	WebElement userDivision;

	@FindBy(xpath = "//span[text()='Contributors']")
	WebElement headerMenu;

	@FindBy(xpath = "//h2")
	WebElement headerText;

	@FindBy(xpath = "//span[@class='anticon anticon-plus-circle']")
	WebElement headerIcon;

	@FindBy(xpath = "//span[contains(@class,'ant-radio ant-radio-checked')]")
	WebElement contributorRadio;

	String divisionCheckBox = "//span[text()='<<DivisionName>>']";

	@FindBy(xpath = "//span[text()='NBC Employee']")
	WebElement NBCEmployee;

	String contriSpan = "ant-radio ant-radio-checked";

	@FindBy(id = "BasicInfo_biography_0")
	WebElement biographyTextArea;

	@FindBy(xpath = "//span[text()='Org/Company']")
	WebElement clickOrgPlaceHolder;

	@FindBy(xpath = "//span[text()='Org/Company']/preceding-sibling::span[1]/input")
	WebElement inputToOrgField;

	String companyOrgName = "//div[contains(@class,'ant-select-dropdown-placement-topLeft ')]/descendant::div[contains(@class,'ant-select-item-option-content')]";

	@FindBy(xpath = "//div[contains(@class,'ant-select-dropdown-placement-topLeft ')]/descendant::div[contains(@class,'ant-select-item-option-content')]")
	List<WebElement> companyOrgList;

	@FindBy(xpath = "//span[text()='Select Expertise(s)']")
	WebElement clickExpertise;

	@FindBy(xpath = "//span[text()='Select Expertise(s)']/preceding-sibling::div//input")
	WebElement enterExpertise;

	@FindBy(xpath = "//div[contains(@class,'ant-select-item ant-select-item-option')]")
	List<WebElement> expertiseDropDownValues;

	String expDropDownValues = "//div[contains(@class,'ant-select-item ant-select-item-option')]";

	@FindBy(xpath = "//input[@data-id='search-box']")
	WebElement searchField;

	@FindBy(xpath = "//li[@class='styles__line1__IVhRc']//span")
	List<WebElement> cardNames;

	@FindBy(xpath = "//span[@class='anticon anticon-font-colors']")
	WebElement letterSelectorIcon;

	@FindBy(xpath = "//ul[@class='styles__list__Mcug7']/li/button")
	List<WebElement> alphaLetterSelectorButtons;

	String getResultCount = "//div[@data-letter='<<Value>>']//span[@class='styles__number__84PdC']";

	@FindBy(xpath = "//span[@class='anticon anticon-sort-ascending']")
	WebElement ascOrDescIcon;

	@FindBy(xpath = "//span[@class='styles__letter___WUr6']")
	WebElement alphaLetters;

	@FindBy(xpath = "//span[@class='styles__letter___WUr6']")
	List<WebElement> listAlphaLetters;

	@FindBy(xpath = "//span[@class='styles__results__gDvVh']/preceding-sibling::span")
	List<WebElement> descAlphaLetters;

	@FindBy(xpath = "//button[span[@class='anticon anticon-filter']]")
	WebElement filterIcon;

	@FindBy(xpath = "//div[text()=' Filter']")
	WebElement drawerName;

	@FindBy(xpath = "//span[text()='Job Title']/preceding-sibling::span/input")
	WebElement selectJobTitleByDefault;

	@FindBy(xpath = "//span[text()='Card View']")
	WebElement cardViewText;

	@FindBy(xpath = "//button[@class='ant-drawer-close']")
	WebElement clickCloseIcon;

	@FindBy(xpath = "//span[text()='Job Title']")
	WebElement jobTitle;

	@FindBy(xpath = "//li[@class='styles__line2__B5W01']/span")
	WebElement guestJobTitles;

	@FindBy(xpath = "//li[@class='styles__line2__B5W01']/span")
	WebElement guestExpertise;

	@FindBy(xpath = "//li[@class='styles__line1__IVhRc']//span")
	WebElement guestNamesInContactCard;

	@FindBy(xpath = "//ul[@class='styles__list__l7x6j']/li")
	WebElement expertiseTags;

	@FindBy(xpath = "//div[@class='ant-drawer-title']")
	WebElement cardViewIsDisplayed;

	@FindBy(xpath = "(//span[text()='Expertise'])[1]")
	WebElement clickExpertiseFilter;

	@FindBy(xpath = "//span[@class='ant-select-selection-placeholder']")
	WebElement expertiseDropDown;

	@FindBy(xpath = "//span[text()='Apply']")
	WebElement appylyButton;

	@FindBy(xpath = "(//ul[@class='header__details__NssiA'])[1]/li")
	List<WebElement> listOfDetails;

	@FindBy(xpath = "//div[@class='ant-col ant-col-xs-24 ant-col-sm-24 ant-col-md-12 ant-col-lg-8']")
	WebElement contactCardsList;

	@FindBy(xpath = "//div[@class='ant-col ant-col-xs-24 ant-col-sm-24 ant-col-md-12 ant-col-lg-8']")
	List<WebElement> expertisedContactCards;

	@FindBy(xpath = "//span[text()='Clear']")
	WebElement clearButton;

	String letterSelector = "//button[span[text()='<<textValue>>']]";

	String dataLetterHead = "//div[@data-letter='<<letterValue>>']";

	String contactCards = ".//div[@class='ant-col ant-col-xs-24 ant-col-sm-24 ant-col-md-12 ant-col-lg-8']";

	String guestCards = "//div[@data-letter='<<letterValue>>']//div[@class='ant-col ant-col-xs-24 ant-col-sm-24 ant-col-md-12 ant-col-lg-8']";

	String contributorCardNames = ".//li[@class='styles__line1__IVhRc']/span";

	public ContributorsPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	public void clickSettings() throws Exception {
		boolean isPresent = WebAction.isDisplayed(profileMenu);
		try {
			if (isPresent) {
				WebAction.click(profileMenu);
				String divName = WebAction.getText(userDivision);
				if (divName.length() > 0) {
				} else
					throw new Exception("Division Name not displayed in settings options");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void clickHeaderMenu() throws Exception {
		Thread.sleep(5000);
		WebAction.clickUsingJs(headerMenu);
		Thread.sleep(500);
		}

	public void verifyContributorName() {
		boolean headerValue = WebAction.isDisplayed(headerText);
		try {
			if (headerValue) {
				String name = WebAction.getText(headerText);
				String[] values = name.split(" ");
				String divisionName = values[0].trim();
				ContributorConstants.setDivision(divisionName);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@FindBy(xpath = "//input[@id='BasicInfo_displayName']")
	WebElement list;
	public void verifyPlusCircle() throws Exception {
		boolean plus = WebAction.isDisplayed(headerIcon);

		try {
			if (plus) {
				WebAction.clickUsingJs(headerIcon);
				WebAction.click(list);
			} else
				throw new Exception("Failed to display the Plus circle icon");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyContributorRadio() throws Exception {
		boolean radioState = WebAction.isDisplayed(contributorRadio);
		String attriValue = WebAction.getAttribute(contributorRadio, "class");
		try {
			if (radioState) {
				boolean space = attriValue.contains(contriSpan);
				System.out.println(space + "Contributor radio button is selected");
			} else
				throw new Exception("Contributor Radio option is not selected by default");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyContributorDivision() throws Exception {
		/*
		 * String checkBoxName = ContributorConstants.getDivision(); WebDriver driver =
		 * DriverFactory.getCurrentDriver();
		 * 
		 * String selectedDivisionCheckBox =
		 * divisionCheckBox.replace("<<DivisionName>>", checkBoxName); /* +
		 * "/preceding-sibling::span[contains(@class,'ant-radio-checked')]";
		 */
		/*
		 * WebElement clicking = driver.findElement(By.xpath(selectedDivisionCheckBox));
		 * WebAction.clickUsingJs(clicking);
		 * System.out.println("Clicking MSNBC check button");
		 */
		/*
		 * WebElement selectedOption =
		 * driver.findElement(By.xpath(selectedDivisionCheckBox)); if
		 * (selectedOption.isSelected()) { Assert.assertTrue(true,
		 * "Division CheckBox is Selected in Guest profile page"); } else AllureUtility.
		 * captureScreenshot("Division Checkbox is not selected in Guest profile page");
		 * Assert.assertFalse(true,
		 * "Division Checkbox is not selected in Guest profile page");
		 */
	}

	public void fillBiogrpahyDetails(String biography) throws Exception {
		try {
			// CompanyConstants.setCompanyBiography(biography); // set Method
			if (biography!=null) {
				WebAction.click(biographyTextArea);
				WebAction.sendKeys(biographyTextArea, biography);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Select the Organization/Company
	 * 
	 * @throws Exception
	 */
	public void selectOraganization(String organValue) throws Exception {
		try {
			WebAction.clickUsingJs(clickOrgPlaceHolder);
			WebAction.selectNonTitleDropDown(inputToOrgField, organValue, companyOrgName, companyOrgList,
					"'" + organValue + "' is not present in search suggestion dropbox");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Select Expertise in Guest Profile throws Exception
	 **/
	public void selectExpertise(String value) throws Exception {
		ContributorConstants.setGuestExpertie(value);
		try {
			WebAction.clickUsingJs(clickExpertise);
			WebAction.selectDropDown(enterExpertise, value, expDropDownValues, expertiseDropDownValues,
					"'" + value + "' is not present in expertise dropdown");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	/**
	 * To select Booker contacts in Adding guest information from contributor page
	 **/
	@FindBy(xpath = "//span[text()='Search for Contacts to add...']")
	WebElement clickAutoSearch;
	@FindBy(xpath = "//span[text()='Search for Contacts to add...']/preceding-sibling::span/input")
	WebElement enteringAdditionalContactField;
	@FindBy(xpath = "//div[@class='rc-virtual-list-holder-inner']//div[contains(@class,'ant-select-item ant-select-item-option')]")
	WebElement searchSuggestionListBox;
	
	@FindBy(xpath = "//div[contains(@class,'rc-virtual-list-holder')]")
	WebElement check;
	
	@FindBy(xpath = "//div[@class='ant-select-item ant-select-item-option']//span")
	WebElement bookerText;
	@FindBy(xpath = "//div[@class='ant-select-item-option-content']/span")
	List<WebElement> suggestionListBox;
	@FindBy(xpath = "//span[@class='styles__alt__d_e5C']/parent::div")
	List<WebElement> bookerProfileContactCard;
	public void additionalContacts(String bookerName) throws Exception {
		boolean isPresent = WebAction.isDisplayed(clickAutoSearch);
		if (isPresent) {
			Waits.waitForElement(enteringAdditionalContactField, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys_WithTimeGap(enteringAdditionalContactField, bookerName);
			
			//Waits.waitForElement(check, WAIT_CONDITIONS.VISIBLE);
			//Waits.waitForAllElements(check, WAIT_CONDITIONS.VISIBLE);
			//	Thread.sleep(500);
			
			int size = suggestionListBox.size();
			for (int i = 0; i < size; i++) {
			String text = WebAction.getText(suggestionListBox.get(i)).trim();
			if(text.equalsIgnoreCase("(Booker)")) {
			System.out.println("Research Scholar -->" + WebAction.getText(bookerProfileContactCard.get(i)));
			WebAction.clickUsingJs(bookerProfileContactCard.get(i));
			//Thread.sleep(5000);
			break;
				}
			}
		}
	}


	/**
	 * Putting Guest Job Title & Company Name in Constant 
	 **/

	public void verifyCreatedGuestHeader() {
		try {
			String jobTitle = listOfDetails.get(1).getText().trim();
			String companyName = listOfDetails.get(2).getText().trim();
			ContributorConstants.setGuestJobTitle(jobTitle);
			ContributorConstants.setGuestCompanyName(companyName);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Search newly created guest name
	 * 
	 * @throws Exception
	 * 
	 */
	public void searchCreatedGuest() throws Exception {
		boolean isPresent = WebAction.isDisplayed(searchField);
		try {
			String guestFullName = "Display12 Name12";// ContributorConstants.getGuestName();
			if (isPresent) {
				Thread.sleep(1000);
				WebAction.sendKeys_WithTimeGap(searchField, guestFullName);
				Thread.sleep(500);
			} else
				throw new Exception("Failed to display the search field");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Guest Contact card
	 * 
	 * @throws Exception
	 * 
	 */
	public void verifyGuestName() throws Exception {
		String guestName = ContributorConstants.getGuestDisplayName();
		int size = cardNames.size();
		if (size != 0) {
			Thread.sleep(500);
			Waits.waitForAllElements(cardNames, WAIT_CONDITIONS.VISIBLE);
			for (WebElement ele : cardNames) {
				Waits.waitForElement(ele, WAIT_CONDITIONS.VISIBLE);
				String cardName = WebAction.getText(ele).trim();
				if (cardName.equalsIgnoreCase(guestName.trim())) {
					Assert.assertTrue(true, "Created Guest displayed in contributor page");
				} else {
					Assert.assertFalse(true, "Created Guest not showing in contributor page");
				}
			}
		}
	}

	/**
	 * Verify the Guest Cards are arranged as per Last Name under Characters.
	 * 
	 * @throws Exception
	 */
	public void verifyLastNameOfTheGuest() throws Exception {
		//String lastName = ContributorConstants.getGuestLastName();
		//String names = ContributorConstants.getGuestName();
		String guestLastNameValue = ContributorConstants.getGuestLastName().substring(0, 1);
		
		System.out.println("Last Name value is{{}}"+guestLastNameValue);
		WebDriver driver = DriverFactory.getCurrentDriver();
		WebAction.clickUsingJs(letterSelectorIcon);
		
	//	Thread.sleep(1000);
		
		Waits.waitForElement(resultsHeader, WAIT_CONDITIONS.VISIBLE);
		
		String xpath = letterSelector.replace("<<textValue>>", guestLastNameValue.toUpperCase());
		WebElement clickLetter = driver.findElement(By.xpath(xpath));
		Thread.sleep(1000);
		WebAction.click(clickLetter);
		
		
		String let = dataLetterHead.replace("<<letterValue>>", guestLastNameValue.toUpperCase());
		
		System.out.println("Value of letters are" +let);
		
		
		WebElement letters = driver.findElement(By.xpath(let));
		
		System.out.println(letters);
		
		List<WebElement> cardsCount = letters.findElements(By.xpath(contactCards));
		
		System.out.println("Contact Cards count are:: "+cardsCount.size());
		
		if (cardsCount.size() > 0) 
		{
			List<WebElement> nameCount = letters.findElements(By.xpath(contributorCardNames));
			
			System.out.println("Name count are in the contact cards are:::" +nameCount.size());
			
			for (int j = 0; j < nameCount.size(); j++) {
				String namesValues = WebAction.getText(nameCount.get(j));
				
				System.out.println("Checking the "+namesValues);
				String val = "Name14";
				
				if (namesValues.trim().contains(val.trim())) {
					System.out.println("Last Name are arranges with letter heads"+namesValues);
					Assert.assertTrue(true, "LastName are arranged with letter head");
					
					break;
				} else {}
					//Assert.assertEquals(true, "Last Name not matched with the letter head");
			}
		}
	}

	/**
	 * Verify Ascending order of Alphabets
	 * 
	 * @throws Exception
	 */
	public void cardsInAscendingOrder() throws Exception {
		boolean isPresent = WebAction.isDisplayed(alphaLetters);
		List<String> asce = new ArrayList<>();
		List<String> desc = new ArrayList<>();
		try {
			if (isPresent) {
				int ascList = listAlphaLetters.size();
				for (int i = 0; i < ascList; i++) {
					asce.add(listAlphaLetters.get(i).getText().toUpperCase());
				}
				WebAction.click(ascOrDescIcon);
				Thread.sleep(500);
				int descList = descAlphaLetters.size();
				for (int j = 0; j < descList; j++) {
					desc.add(descAlphaLetters.get(j).getText().toUpperCase());
				}
				for (int k = 0; k < ascList; k++) {
					String firstChar = asce.get(k);
					String lastChar = desc.get(ascList - 1 - k);
					if (firstChar.equalsIgnoreCase(lastChar)) {
						Assert.assertTrue(true, "Alphabets are arranged in Ascending/Descending order");
					} else
						Assert.assertFalse(true, "Alphabets are not arranged in Ascending/Descending order");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click enabled Alphabets from Letter selector option
	 * 
	 * @throws Exception
	 */
	public void clickEnabledAlphabets() throws Exception {
		String resultsValue = "", result = "", cardsTotalCount = "";
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			WebAction.clickUsingJs(letterSelectorIcon);
			List<WebElement> alp = alphaLetterSelectorButtons;
			for (WebElement random : alp) {
				boolean alphaEnabled = random.isEnabled();
				if (alphaEnabled) {
					WebElement value = random.findElement(By.xpath(".//span"));
					System.out.println("Clicking only enabled Alphabets---->" + value.getText());
					WebAction.clickUsingJs(random);
					Thread.sleep(5000);
					result = getResultCount.replace("<<Value>>", value.getText().toUpperCase());
					resultsValue = driver.findElement(By.xpath(result)).getText();
					System.out.println("Alphbetical Result Counts---->" + resultsValue);
					cardsTotalCount = guestCards.replace("<<letterValue>>", value.getText().toUpperCase());
					List<WebElement> getSize = driver.findElements(By.xpath(cardsTotalCount));
					if (getSize.size() == Integer.parseInt(resultsValue)) {
						System.out.println("Card Count is--->" + getSize.size()
								+ "Result of the Alphabets cards are --->" + resultsValue);
					} else
						System.out.println("Card Count and results count are mismatched");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Click & Enable Filter RH drawer
	 * 
	 * @throws Exception
	 */
	public void clickFilterIcon() throws Exception {
		boolean isIconPresent = WebAction.isDisplayed(filterIcon);
		try {
			if (isIconPresent) {
				WebAction.clickUsingJs(filterIcon);
				Waits.waitForElement(drawerName, WAIT_CONDITIONS.VISIBLE);
				String drawerTitle = WebAction.getText(drawerName);
				if (drawerTitle.length() > 0) {
					Assert.assertTrue(true, drawerTitle + "is displayed");
				} else
					Assert.assertFalse(true, "Not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify CardView is displayed
	 **/
	public void verifyCardViewInRHDrawer() {
		try {
			String verifyLabel = WebAction.getText(cardViewText);
			if (verifyLabel.length() > 0) {
				Assert.assertTrue(true, verifyLabel + "is present");
			} else
				Assert.assertFalse(true, verifyLabel + "is not present");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Job title is enabled by default
	 * 
	 * @throws Exception
	 */
	public void jobTitleEnable() throws Exception {
		boolean defValue = false;
		try {
			defValue = WebAction.isSelected(selectJobTitleByDefault);
			if (defValue) {
				Waits.waitForElement(jobTitle, WAIT_CONDITIONS.VISIBLE);
				System.out.println("Job title is enabled by-> " + defValue);
				WebAction.click(clickCloseIcon);
				Assert.assertTrue(true, "Job Title is selected by default");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Expertise filter in Card view
	 **/

	public void setExpertiseFilter() throws Exception {
		boolean isPresent = WebAction.isDisplayed(filterIcon);
		if (isPresent) {
			WebAction.clickUsingJs(filterIcon);
			Waits.waitForElement(cardViewIsDisplayed, WAIT_CONDITIONS.VISIBLE);
			WebAction.clickUsingJs(clickExpertiseFilter);
			Waits.waitForElement(clickCloseIcon, WAIT_CONDITIONS.VISIBLE);
			WebAction.clickUsingJs(clickCloseIcon);
		}
	}

	/**
	 * Verify the Job title present in Contact card
	 **/
	public void verfiyContactCardJobTitle() {
		boolean isCardPresent = WebAction.isDisplayed(guestNamesInContactCard);
		try {
			if (isCardPresent) {
				String getJobTitle = WebAction.getText(guestJobTitles).trim();
				if (getJobTitle.equalsIgnoreCase(ContributorConstants.getGuestJobTitle())) {
					System.out.println(getJobTitle + "From Contact Card..." + "From thread local"
							+ ContributorConstants.getGuestJobTitle());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Expertise tags are present in Contact card
	 **/
	public void verifyContactCardExpertiseTags() {
		boolean isCardPresent = WebAction.isDisplayed(guestNamesInContactCard);
		try {
			if (isCardPresent) {
				String expertiseValues = WebAction.getText(guestExpertise);
				String verifyExpertise = ContributorConstants.getGuestExpertise().trim();
				if (expertiseValues.equalsIgnoreCase(verifyExpertise)) {
					System.out.println(expertiseValues + "...Value matched..." + verifyExpertise);
					Assert.assertTrue(true, "Expertise tags shown in contact cards");
				} else
					Assert.assertFalse(true, "Not matched with expertise tags");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click Expertise drop down from filter section
	 **/

	public void selectValues(String tags) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		boolean isPresent = WebAction.isDisplayed(expertiseDropDown);
		if (isPresent) {
			String[] listOfTags = tags.split(",");
			int length = listOfTags.length;
			for (int i = 0; i < length; i++) {
				String individualtags = listOfTags[i];
				WebAction.clickUsingJs(clickExpertise);
				WebAction.selectDropDown(enterExpertise, individualtags, expDropDownValues, expertiseDropDownValues,
						"'" + individualtags + "' is not present in expertise dropdown");
			}
			String lastTags = "//ul[@class='styles__list__l7x6j styles__list__KTw8t']//li[" + length + "]";
			WebElement element = driver.findElement(By.xpath(lastTags));
			WebAction.keyPress(enterExpertise, "ESC");
			Thread.sleep(200);
			WebAction.scrollIntoView(element);

		}
	}

	/**
	 * Click "Apply or Clear" button under expertise filter
	 * 
	 * @throws Exception
	 */
	public void clickButton() throws Exception {
		boolean isPresent = WebAction.isEnabled(appylyButton);
		try {
			if (isPresent) {
				WebAction.click(appylyButton);
				Thread.sleep(500);
				int size = expertisedContactCards.size();
				System.out.println("Total no of Contact cards after applying fitler are:: " + size);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Clearing the expertise tags from the parking lots
	 **/

	public void clearedTheApplyExpertiseFitler() throws Exception {
		try {
			WebAction.clickUsingJs(filterIcon);
			Waits.waitForElement(drawerName, WAIT_CONDITIONS.VISIBLE);
			boolean isEnabled = WebAction.isEnabled(clearButton);
			if (isEnabled) {
				WebAction.click(clearButton);
				Thread.sleep(500);
				int size = expertisedContactCards.size();
				System.out.println("Total no of Contact cards after clearing the fitler are:: " + size);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify Profile RH drawer displayed for newly created guest from contributor
	 * page
	 **/
	@FindBy(xpath = "//div[@class='ant-col ant-col-xs-24 ant-col-sm-24 ant-col-md-12 ant-col-lg-8']")
	WebElement searchResultedGuestcontactCard;
	@FindBy(xpath = "//li[@class='styles__line1__IVhRc']")
	WebElement guestNameInTheCard;
	@FindBy(xpath = "//div[text()=' Profile']")
	WebElement profileRHDrawer;
	
	public void verifyProfileRHDrawer() throws Exception {
		try {
			boolean isPresent = WebAction.isDisplayed(searchResultedGuestcontactCard);
			String displayName = "Display12 Name12"; // ContributorConstants.getGuestDisplayName();
			String guestName = WebAction.getText(guestNameInTheCard).trim();
			if (displayName.equalsIgnoreCase(guestName)) {
				System.out.println("Verify the guest name"+guestName);
				Thread.sleep(500);
				WebAction.clickUsingJs(guestNameInTheCard);
			//	Thread.sleep(1000);
				Waits.waitForElement(profileRHDrawer, WAIT_CONDITIONS.VISIBLE);
				boolean isTrue = WebAction.isDisplayed(profileRHDrawer);
				String drawerTitle = WebAction.getText(profileRHDrawer);
				Assert.assertTrue(isTrue, "Profile RH Drawer displayed as"+drawerTitle);
			
				} else
				throw new Exception("Display Name not matched with created guest from contributor page");
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the basic info section for Profile RH drawer
	 **/
	@FindBy(xpath = "//ul[@class='styles__details__y1J4b']/li")
	WebElement headerRHPart;
	@FindBy(xpath = "//ul[@class='styles__details__y1J4b']/li")
	List<WebElement> headerRHPartlist;
	@FindBy(xpath = "//ul[@class='styles__details__y1J4b']/li[3]")
	WebElement lists;

	public void verfiyGuestBasicDetailsInRHDrawer() {
		//List<String> guestDetails = new ArrayList<String>();
		String xpath = "./span";
		boolean isPresent = WebAction.isDisplayed(profileRHDrawer);
		if (isPresent) {
			int size = headerRHPartlist.size();
			for (int i = 0; i < size; i++) {
				try {
					boolean value = headerRHPartlist.get(i).findElement(By.xpath(xpath)).isDisplayed() ? true : false;
					if (value)
						System.out.println("Contributor icon is present in the RH drawer");
					else {
						System.out.println("Failed to display the Contributor icon in the RH drawer");
					}
				} catch (NoSuchElementException e) {
				}
				String values = headerRHPartlist.get(i).getText().trim();
				// System.out.println("Basic profile RH Drawer head view are :" + values);
			}
			/*
			 * if (guestDetails.get(0).equalsIgnoreCase(ContributorConstants.
			 * getGuestDisplayName()) &&
			 * guestDetails.get(1).equalsIgnoreCase(ContributorConstants.getGuestJobTitle())
			 * &&
			 * guestDetails.get(2).equalsIgnoreCase(ContributorConstants.getGuestCompanyName
			 * ())) { System.out.
			 * println("Created Guest details are displayed successfully in Profile RH drawer"
			 * ); } else { System.out.println("Not matched in the RH drawer"); }
			 */
		}
	}

	/**
	 * Verify the contact info section in Profile RH drawer
	 **/
	@FindBy(xpath = "(//li[@aria-hidden='true'])[2]/preceding-sibling::li")
	List<WebElement> guestContactInformation;
	@FindBy(xpath = "//p")
	WebElement guestAlerts;
	@FindBy(xpath = "//table[@class='styles__list__wWs5e styles__stacked__YD_pJ']//tr")
	List<WebElement> tablesCount;

	public void verifyGuestContactDetailsInRHDrawer() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		HashMap<String, HashMap<String, String>> OuterHashMap = new HashMap<>();
		String AlertsText = WebAction.getText(guestAlerts);
		// String addedAlerts = ContributorConstants.getGuestAlerts();
		// System.out.println(AlertsText);
		// System.out.println(addedAlerts);
		// if(AlertsText.equalsIgnoreCase(addedAlerts)) {
		// System.out.println("Alerts got matched with the UI");
		// }
		try {
			int tabSize = guestContactInformation.size();
			System.out.println("No of tabs"+tabSize);
			for (int i = 1; i < tabSize-2; i++) {
				WebAction.clickUsingJs(guestContactInformation.get(i));
				String tabHeaderNames = guestContactInformation.get(i).getText().trim();
				System.out.println(tabHeaderNames+" "+i);
				Thread.sleep(500);
				int tableRows = tablesCount.size();
				HashMap<String, String> innerKeysValues = new HashMap<>();
				for (int j = 0; j < tableRows; j++) {
					for (int k = 1; k < 2; k++) {
						String labelAsKey = driver.findElement(
								By.xpath("//table[@class='styles__list__wWs5e styles__stacked__YD_pJ']//tr[" + (j + 1)
										+ "]//td[" + (k) + "]/div"))
								.getText();
						// System.out.println("Inside For loop:::" + labelAsKey);
						String labelAsValue = driver.findElement(
								By.xpath("//table[@class='styles__list__wWs5e styles__stacked__YD_pJ']//tr[" + (j + 1)
										+ "]//td[" + (k + 1) + "]//a"))
								.getText();
						// System.out.println("Inside For loop ---" + labelAsValue);
						innerKeysValues.put(labelAsKey, labelAsValue);
					}
				}
				OuterHashMap.put(tabHeaderNames, innerKeysValues);
				// System.out.println("Phone,Email,Other section tabss---->"+OuterHashMap);
			}
			/*
			 * if (OuterHashMap.get("Email").get("4 - Email").equalsIgnoreCase(AlertsText)
			 * && OuterHashMap.get("Email").get("3 - Email").equalsIgnoreCase(AlertsText) &&
			 * OuterHashMap.get("Email").get("1 - Email").equalsIgnoreCase(AlertsText) &&
			 * OuterHashMap.get("Email").get("2 - Email").equalsIgnoreCase(AlertsText)) {
			 * System.out.println("Email Verified Successfully"); } if
			 * (OuterHashMap.get("Phone").get("Office").equalsIgnoreCase(AlertsText) &&
			 * OuterHashMap.get("Phone").get("2 - Phone").equalsIgnoreCase(AlertsText) &&
			 * OuterHashMap.get("Phone").get("1 - Phone").equalsIgnoreCase(AlertsText) &&
			 * OuterHashMap.get("Phone").get("Mobile").equalsIgnoreCase(AlertsText)) {
			 * System.out.println("Phone No Verified Successfully"); } if
			 * (OuterHashMap.get("Other").get("LinkedIn").equalsIgnoreCase(AlertsText) &&
			 * OuterHashMap.get("Other").get("Video").equalsIgnoreCase(AlertsText) &&
			 * OuterHashMap.get("Other").get("Website").equalsIgnoreCase(AlertsText) &&
			 * OuterHashMap.get("Other").get("Twitter").equalsIgnoreCase(AlertsText)) {
			 * System.out.println("Other website links Verified Successfully"); }
			 */
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the Address details in Profile RH drawer
	 **/
	@FindBy(xpath = "(//li[@aria-hidden='true'])[2]/preceding-sibling::li[2]")
	WebElement guestAddressInformation;

	public void verifyGuestContactAddressDetailsInRHDrawer() throws Exception {

		WebDriver driver = DriverFactory.getCurrentDriver();
		HashMap<String, String> innerKeysValues = new HashMap();
		try {
			boolean isPresent = WebAction.isDisplayed(guestAddressInformation);
			if (isPresent) {
				int tableRows = tablesCount.size();
				WebAction.click(guestAddressInformation);
				for (int j = 0; j < tableRows; j++) {
					for (int k = 1; k < 2; k++) {
						String labelAsKey = driver.findElement(
								By.xpath("//table[@class='styles__list__wWs5e styles__stacked__YD_pJ']//tr[" + (j + 1)
										+ "]//td[" + (k) + "]/div"))
								.getText();
						// System.out.println("Inside For loop:::" + labelAsKey);
						String labelAsValue = driver.findElement(
								By.xpath("//table[@class='styles__list__wWs5e styles__stacked__YD_pJ']//tr[" + (j + 1)
										+ "]//td[" + (k + 1) + "]"))
								.getText();
						// System.out.println("Inside For loop ---" + labelAsValue);
						innerKeysValues.put(labelAsKey, labelAsValue);
					}
				}
				// System.out.println("Address Tab details---->" +innerKeysValues);
				/*
				 * if (innerKeysValues.get("Address").equalsIgnoreCase(companyOrgName) &&
				 * innerKeysValues.get("Apt, Suite, etc").equalsIgnoreCase(companyOrgName) &&
				 * innerKeysValues.get("City").equalsIgnoreCase(companyOrgName) &&
				 * innerKeysValues.get("State").equalsIgnoreCase(companyOrgName) &&
				 * innerKeysValues.get("Zip Code").equalsIgnoreCase(companyOrgName) &&
				 * innerKeysValues.get("Country").equalsIgnoreCase(companyOrgName)) {
				 * System.out.println("Address Details are Verified Successfully"); }
				 */
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * Verify the Booker details in Profile RH drawer
	 **/
	@FindBy(xpath = "//span[text()='Bookers']")
	WebElement bookersTab;
	@FindBy(xpath = "//div[@class='styles__container__OMuzD']")
	List<WebElement> bookersContainerList;
	@FindBy(xpath = "//div[@class='styles__content__qJpQI']//li")
	List<WebElement> bookersCardInformation;
	public void verifyGuestBookersDetailsInRHDrawer() throws Exception {
	List<String> bookersInfo = new ArrayList<String>();
		boolean isPresent = WebAction.isDisplayed(bookersTab);
		if(isPresent) {
			WebAction.click(bookersTab);
			int size = bookersContainerList.size();
			for(int i = 0 ; i< size; i++) {
				for(int j = 0 ; j<bookersCardInformation.size(); j++) {
					bookersInfo.add(WebAction.getText(bookersCardInformation.get(j)).trim());
				}
			}
			System.out.println("Bookers information are added successfully in "+bookersInfo);
		}
	}

	/**
	 * Click Profile button in Contributor RH drawer
	 **/
	@FindBy(xpath = "//button[span[text()='Profile']]")
	WebElement profileButton;
	@FindBy(xpath = "(//span[text()='Edit'])[1]")
	WebElement editButton;

	@FindBy(xpath = "//button[span[text()='Basic Info']]")
	WebElement profileBasicInfo;
	// @FindBy(xpath = "//div[@data-id='page-header']/div[position()=2]//li")
	// List<WebElement> listOfButtons;

	public void clickProfileButton() throws Exception {
		boolean isPresent = WebAction.isDisplayed(profileButton);
		try {
			if (isPresent) {
				WebAction.click(profileButton);
				System.out.println("After clicking Profile button in RH drawer");
				Waits.waitForElement(profileBasicInfo, WAIT_CONDITIONS.CLICKABLE);
				// Thread.sleep(4000);
				// Waits.waitForAllElements(listOfButtons, WAIT_CONDITIONS.VISIBLE);
				boolean viewPage = WebAction.isDisplayed(editButton);
				if (viewPage) {
					System.out.println("System images:" + viewPage);

					Waits.waitForElement(editButton, WAIT_CONDITIONS.CLICKABLE);
					// Thread.sleep(4000);
					WebAction.clickUsingJs(editButton);
				}
			} else {
				throw new Exception("Profile button is not displayed");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * De-select the contributor button
	 * 
	 * @throws Exception
	 */
	@FindBy(xpath = "//input[@id='BasicInfo_displayName']")
	WebElement clickDisplayName;
	@FindBy(xpath = "//button[@class='ant-btn ant-btn-round ant-btn-primary']/span[text()='Update']")
	WebElement clickUpdateButton;
	@FindBy(xpath = "//span[text()='Booking Info']")
	WebElement verifyBasicInfoButton;

	public void deselectContributorRadio() throws Exception {
		WebAction.clickUsingJs(clickDisplayName);
		boolean isPresent = WebAction.isEnabled(contributorRadio);
		try {
			if (isPresent) {
				// Thread.sleep(900);
				WebAction.click(contributorRadio);
				// Thread.sleep(1000);
				Waits.waitForElement(clickUpdateButton, WAIT_CONDITIONS.CLICKABLE);
				WebAction.clickUsingJs(clickUpdateButton);
				// Thread.sleep(900);
				Waits.waitForElement(verifyBasicInfoButton, WAIT_CONDITIONS.CLICKABLE);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * Verify the de-selected contributor not shown in contributors body
	 **/
	@FindBy(xpath = "//div[@class='ant-empty-description']")
	WebElement noContributorsText;
	@FindBy(xpath = "(//span[@class='styles__results__gDvVh'])[1]")
	WebElement resultsHeader;
	public void guestDetailsNotToDisplay() throws Exception {
		Waits.waitForElement(headerMenu, WAIT_CONDITIONS.VISIBLE);
		int count = 3;
		while (count > 0) {
			WebAction.clickUsingJs(headerMenu);
			count--;
		}
		// Thread.sleep(900);
		// WebAction.clickUsingJs(headerMenu);
		boolean isPresent = WebAction.isDisplayed(searchField);
		System.out.println("Is Present value" + isPresent);
		try {
			String guestFullName = "Display12 Name12";// ContributorConstants.getGuestName();
			if (isPresent) {
				// Thread.sleep(1000);
				WebAction.sendKeys_WithTimeGap(searchField, guestFullName);
				// Thread.sleep(500);
				String noData = WebAction.getText(noContributorsText);
				System.out.println("Element check--->" + noData);
				if (noData.length() > 0) {
					System.out.println("Successfully removed from the Contributor page");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
}

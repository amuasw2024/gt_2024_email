package nbcu.automation.ui.constants.gtreplatform;

import java.util.HashMap;

public class ContributorConstants {

	private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	public static String getDivision() {
		return (String) constantMap.get().get("Division");
	}
	
	public static void setDivision(String divisionName) {
		constantMap.get().put("Division", divisionName);
	}
		
	public static String getGuestName() {
		return (String) constantMap.get().get("ContGuestName");
	}
	
	public static void setGuestName(String guestName) {
		constantMap.get().put("ContGuestName", guestName);
	}
	
	public static void setGuestLastName(String guestLastName) {
		constantMap.get().put("GuestLastName", guestLastName);
	}
	
	public static String getGuestLastName() {
		return (String)constantMap.get().get("GuestLastName");
	}
	
	public static void setGuestDisplayName(String guestDisplayName) {
		constantMap.get().put("GuestDisplayName", guestDisplayName);
	}
	
	public static String getGuestDisplayName() {
		return (String)constantMap.get().get("GuestDisplayName");
	}
	
	public static void setGuestJobTitle(String guestJobTitle) {
		constantMap.get().put("GuestJobTitle", guestJobTitle);
	}
	
	public static String getGuestJobTitle() {
		return (String) constantMap.get().get("GuestJobTitle");
	}
	
	public static void setGuestCompanyName(String guestCompanyName) {
		constantMap.get().put("GuestCompanyName", guestCompanyName);
	}
	
	public static String getGuestCompanyName() {
		return (String) constantMap.get().get("GuestCompanyName");
	}
	
	public static void setGuestExpertie(String guestExpertise) {
		constantMap.get().put("GuestExpertiseTags", guestExpertise);
	}
	
	public static String getGuestExpertise() {
		return (String) constantMap.get().get("GuestExpertiseTags");
	}
	
	public static void setGuestAlerts(String guestAlerts) {
		constantMap.get().put("GuestAlerts", guestAlerts);
	}
	
	public static String getGuestAlerts() {
		return (String) constantMap.get().get("GuestAlerts");
	}
	
	
	
}

package nbcu.automation.ui.stepdefs.ncx;

import io.cucumber.java.en.Given;
import nbcu.automation.ui.pages.ncx.LoginPage;

public class LoginPageSteps {

	LoginPage loginPage = new LoginPage();

	@Given("user opens ncx application")
	public void openNcxApplication() throws Exception {
		loginPage.openApplication();
	}

	@Given("user logins into ncx application")
	public void loginNcxApplication() throws Exception {
		loginPage.loginIntoApplication();
	}
}

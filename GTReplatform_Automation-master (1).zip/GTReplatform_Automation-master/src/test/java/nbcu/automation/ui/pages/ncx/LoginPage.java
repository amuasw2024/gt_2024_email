package nbcu.automation.ui.pages.ncx;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.framework.Wrapper.ui.Waits;
import nbcu.framework.Wrapper.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.Wrapper.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.encryption.PasswordEncryption;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;

public class LoginPage {

	@FindBy(id = "username")
	WebElement userName;

	@FindBy(id = "password")
	WebElement password;

	@FindBy(id = "submitBtn")
	WebElement submitButton;

	public LoginPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To open GT replatform application
	 * 
	 * @throws Exception
	 */
	public void openApplication() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		String environment = "", applicationUrl = "";
		try {
			// Fetch the application url based on application and environment
			environment = ConfigFileReader.getProperty("Environment");
			switch (environment.toUpperCase()) {
			case "QA":
				applicationUrl = ConfigFileReader.getProperty("ncx-app-url_Qa");
				break;
			case "STAGE":
				applicationUrl = ConfigFileReader.getProperty("ncx-app-url_Stage");
				break;
			case "PROD":
				applicationUrl = ConfigFileReader.getProperty("ncx-app-url_Prod");
				break;
			}

			// Launch the application
			driver.get(applicationUrl);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify sign in page is displayed
	 * 
	 * @throws Exception
	 */
	public void verifySignInPageDisplayed() throws Exception {
		Waits.waitForElement(userName, WAIT_CONDITIONS.VISIBLE);
	}

	/**
	 * To login into application
	 * 
	 * @throws Exception
	 */
	public void loginIntoApplication() throws Exception {
		String userNameText = "", passwordText = "";
		try {

			userNameText = ConfigFileReader.getProperty("gt-admin-username");
			passwordText = ConfigFileReader.getProperty("gt-admin-password");

			WebAction.clear(userName);
			WebAction.sendKeys(userName, userNameText);
			String descryptedPassword = PasswordEncryption.decrypt(passwordText);
			WebAction.sendKeys(password, descryptedPassword);
			WebAction.click(submitButton);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}

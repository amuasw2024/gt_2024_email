package nbcu.automation.ui.constants.gtreplatform;

import java.util.HashMap;

public class AdminConstants {

	private static final ThreadLocal<HashMap<String, Object>> constantMap = new ThreadLocal<HashMap<String, Object>>() {
		@Override
		protected HashMap<String, Object> initialValue() {
			return new HashMap<>();
		}
	};

	public static String getDivision() {
		return (String) constantMap.get().get("Division");
	}

	public static void setDivision(String division) {
		constantMap.get().put("Division", division);
	}

	// Show tab constants
	public static String getShowName() {
		return (String) constantMap.get().get("Show Name");
	}

	public static void setShowName(String showName) {
		constantMap.get().put("Show Name", showName);
	}

	public static String getOmsName() {
		return (String) constantMap.get().get("OMS Name");
	}

	public static void setOmsName(String omsName) {
		constantMap.get().put("OMS Name", omsName);
	}

	public static String getExcludeFromReports() {
		return (String) constantMap.get().get("Exclude From Reports");
	}

	public static void setExcludeFromReports(String excludeFromReport) {
		constantMap.get().put("Exclude From Reports", excludeFromReport);
	}

	public static String getScheduleDays() {
		return (String) constantMap.get().get("Schedule Days");
	}

	public static void setScheduleDays(String days) {
		constantMap.get().put("Schedule Days", days);
	}

	public static String getScheduleStartTime() {
		return (String) constantMap.get().get("Schedule Start Time");
	}

	public static void setScheduleStartTime(String scheduleStartTime) {
		constantMap.get().put("Schedule Start Time", scheduleStartTime);
	}

	public static String getScheduleEndTime() {
		return (String) constantMap.get().get("Schedule End Time");
	}

	public static void setScheduleEndTime(String scheduleEndTime) {
		constantMap.get().put("Schedule End Time", scheduleEndTime);
	}

	// Alerts tab constants
	public static String getAlertTimeInterval() {
		return (String) constantMap.get().get("Alert Time Interval");
	}

	public static void setAlertTimeInterval(String alertTimeInterval) {
		constantMap.get().put("Alert Time Interval", alertTimeInterval);
	}

	public static String getAlertEmailList() {
		return (String) constantMap.get().get("Alert Email List");
	}

	public static void setAlertEmailList(String alertEmailList) {
		constantMap.get().put("Alert Email List", alertEmailList);
	}

	public static void endThreadLocal() {
		constantMap.remove();
	}

	// car services constants
	public static String getCarServicesName() {
		return (String) constantMap.get().get("Car Services Name");
	}

	public static void setCarServicesName(String carServicesName) {
		constantMap.get().put("Car Services Name", carServicesName);
	}

	public static String getCarServicesPhoneNumber() {
		return (String) constantMap.get().get("Car Services Phone Number");
	}

	public static void setCarServicesPhoneNumber(String carServicesPhoneNumber) {
		constantMap.get().put("Car Services Phone Number", carServicesPhoneNumber);
	}

	public static String getCarServicesCountry() {
		return (String) constantMap.get().get("Car Services Country");
	}

	public static void setCarServicesCountry(String carServicesCountry) {
		constantMap.get().put("Car Services Country", carServicesCountry);
	}

	public static String getCarServicesAddressLine1() {
		return (String) constantMap.get().get("Car Services Address Line1");
	}

	public static void setCarServicesAddressLine1(String carServicesAddressLine1) {
		constantMap.get().put("Car Services Address Line1", carServicesAddressLine1);
	}

	public static String getCarServicesCity() {
		return (String) constantMap.get().get("Car Services City");
	}

	public static void setCarServicesCity(String carServicesCity) {
		constantMap.get().put("Car Services City", carServicesCity);
	}

	public static String getCarServicesState() {
		return (String) constantMap.get().get("Car Services State");
	}

	public static void setCarServicesState(String carServicesState) {
		constantMap.get().put("Car Services State", carServicesState);
	}

	public static String getCarServicesZipCode() {
		return (String) constantMap.get().get("Car Services Zip Code");
	}

	public static void setCarServicesZipCode(String carServicesZipCode) {
		constantMap.get().put("Car Services Zip Code", carServicesZipCode);
	}
}
